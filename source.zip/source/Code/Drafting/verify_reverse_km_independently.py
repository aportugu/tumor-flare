"""Independent product-limit/log-log check of the drafting-only R summary.

Usage: python verify_reverse_km_independently.py ENDPOINT_AUDIT.csv R_OUTPUT_DIR
The calculation uses Python's standard library and no survival package.
"""
import csv
import json
import math
import sys
from pathlib import Path
from statistics import NormalDist

source = Path(sys.argv[1])
output = Path(sys.argv[2])
data = [r for r in csv.DictReader(source.open()) if r["scenario"] == "primary" and r["endpoint"] == "OS"]
reported = {r["group"]: r for r in csv.DictReader((output / "global_os_followup_reverse_km.csv").open())}
results = []
zscore = NormalDist().inv_cdf(.975)
def median(times, values):
    pairs = [(t, s) for t, s in zip(times, values) if s is not None and math.isfinite(s)]
    for index, (time, value) in enumerate(pairs):
        if value > .5 + 1e-8: continue
        if abs(value - .5) > 1e-8: return time
        later = [t for t, s in pairs[index+1:] if s < .5-1e-8]
        return (time + later[0])/2 if later else time
    return None
def product_limit(rows):
    valid = [r for r in rows if r["endpoint_eligible"] == "TRUE"]
    times = sorted({float(r["followup_days"]) for r in valid})
    survival = 1.0
    greenwood = 0.0
    probabilities, lower, upper = [], [], []
    for time in times:
        n = sum(float(r["followup_days"]) >= time for r in valid)
        d = sum(float(r["followup_days"]) == time and r["status"] == "0" for r in valid)
        survival *= 1-d/n
        if d and n>d: greenwood += d/(n*(n-d))
        if survival == 1: lo = hi = 1.0
        elif survival == 0: lo = hi = None
        else:
            eta = math.log(-math.log(survival))
            se = math.sqrt(greenwood)/abs(math.log(survival))
            lo = math.exp(-math.exp(eta+zscore*se))
            hi = math.exp(-math.exp(eta-zscore*se))
        probabilities.append(survival);lower.append(lo);upper.append(hi)
    return dict(total_courses=len(rows), available_global_os=len(valid), unavailable_global_os=len(rows)-len(valid),
                os_deaths=sum(r["status"]=="1" for r in valid), global_followup_ends=sum(r["status"]=="0" for r in valid),
                median_days=median(times,probabilities), lower_95_days=median(times,lower), upper_95_days=median(times,upper))
for group in ("Overall", "Documented flare", "No documented flare"):
    rows = data if group == "Overall" else [r for r in data if r["analysis_flare"] == ("TRUE" if group == "Documented flare" else "FALSE")]
    expected = product_limit(rows)
    comparisons = {}
    for key, value in expected.items():
        observed = reported[group][key]
        comparisons[key] = not observed if value is None else math.isclose(float(observed), value, rel_tol=0, abs_tol=1e-10)
    results.append(dict(group=group, independent_estimates=expected, checks=comparisons, status="PASS" if all(comparisons.values()) else "FAIL"))
report = dict(status="PASS" if all(r["status"]=="PASS" for r in results) else "FAIL",
              implementation="Independent Python product-limit calculation with log-log Greenwood bands; same-time OS deaths included in reverse-event risk set",
              numerical_tolerance_days=1e-10, groups=results)
(output / "independent_method_verification.json").write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if report["status"] != "PASS": raise SystemExit("Independent reverse-KM comparison failed")
