# Drafting-only descriptive global OS follow-up; existing analyses are read-only.
# Method: Schemper M, Smith TL. Control Clin Trials. 1996;17:343-346.
# DOI: 10.1016/0197-2456(96)00075-x; manuscript citation key Schemper1996.
# Usage: Rscript reverse_km_global_os_followup.R ENDPOINT_AUDIT.csv NEW_OUTPUT_DIR
args <- commandArgs(trailingOnly=TRUE)
if(length(args)!=2L)stop("Expected canonical endpoint audit and a new output directory")
input <- normalizePath(args[1],mustWork=TRUE)
output <- args[2]
if(dir.exists(output)&&length(list.files(output,all.files=TRUE,no..=TRUE)))
  stop("Output directory must be new or empty")
dir.create(output,recursive=TRUE,showWarnings=FALSE)
output <- normalizePath(output,mustWork=TRUE)
library_path <- Sys.getenv("TF_R_LIBRARY","")
if(nzchar(library_path)).libPaths(c(normalizePath(library_path,mustWork=TRUE),.libPaths()))
for(package in c("survival","jsonlite"))if(!requireNamespace(package,quietly=TRUE))stop("Missing dependency: ",package)
RNGkind("Mersenne-Twister","Inversion","Rejection")
options(digits=17)
months_in_days <- 30.4375

rkm_fit <- function(data,group) {
  valid <- !is.na(data$endpoint_eligible)&data$endpoint_eligible&
    is.finite(data$followup_days)&data$followup_days>0&!is.na(data$status)&data$status %in% 0:1
  available <- data[valid,,drop=FALSE]
  row <- data.frame(group=group,cohort="Primary known-flare-status comparative courses",
    total_courses=nrow(data),available_global_os=nrow(available),unavailable_global_os=sum(!valid),
    patient_clusters=length(unique(available$patient_cluster_id)),
    os_deaths=sum(available$status==1L),global_followup_ends=sum(available$status==0L),
    classification_unavailable=sum(is.na(data$analysis_flare)),
    median_days=NA_real_,lower_95_days=NA_real_,upper_95_days=NA_real_,
    median_months=NA_real_,lower_95_months=NA_real_,upper_95_months=NA_real_,
    median_state="Unavailable: no valid global OS records",lower_95_state="Unavailable",upper_95_state="Unavailable",
    confidence_method="95% pointwise log-log Greenwood confidence limits, inverted at survival 0.5",
    reverse_event="1 minus canonical OS status: global follow-up end is event; OS death is censored",
    time_origin="First administered BsAb step-up dose; canonical global OS duration",
    days_per_month=months_in_days,stringsAsFactors=FALSE)
  if(!nrow(available))return(list(summary=row,steps=data.frame()))
  fit <- survival::survfit(survival::Surv(followup_days,1L-status)~1,data=available,
    conf.type="log-log",conf.int=.95)
  statistics <- summary(fit)$table
  row$median_days <- unname(statistics["median"])
  row$lower_95_days <- unname(statistics["0.95LCL"])
  row$upper_95_days <- unname(statistics["0.95UCL"])
  for(field in c("median","lower_95","upper_95")) {
    row[[paste0(field,"_months")]] <- row[[paste0(field,"_days")]]/months_in_days
    row[[paste0(field,"_state")]] <- if(is.finite(row[[paste0(field,"_days")]]))"Estimated" else
      if(field=="median")"Unestimable: reverse KM curve does not reach 0.5"else"Unestimable: confidence limit does not reach 0.5"
  }
  steps <- data.frame(group=group,time_days=fit$time,time_months=fit$time/months_in_days,
    n_risk=fit$n.risk,reverse_events=fit$n.event,os_deaths_censored=fit$n.censor,
    reverse_survival=fit$surv,lower_95=fit$lower,upper_95=fit$upper)
  list(summary=row,steps=steps)
}

tests <- list()
check <- function(name,value)tests[[length(tests)+1L]]<<-data.frame(test=name,status=if(isTRUE(value))"PASS"else"FAIL")
fixture <- data.frame(course_id=paste0("S",1:5),patient_cluster_id=paste0("SP",1:5),
  analysis_flare=TRUE,followup_days=c(1,2,2,3,4),status=c(1L,0L,1L,0L,0L),endpoint_eligible=TRUE)
tied <- rkm_fit(fixture,"Synthetic")
step <- tied$steps[tied$steps$time_days==2,,drop=FALSE]
check("Tied follow-up end uses risk set including same-day death",step$n_risk==4&&step$reverse_events==1&&step$os_deaths_censored==1)
check("Manual tied reverse product-limit probability",abs(step$reverse_survival-.75)<1e-14)
check("Deaths are censored and follow-up ends are reverse events",tied$summary$os_deaths==2&&tied$summary$global_followup_ends==3)
check("Manual tied median and lower confidence limit",tied$summary$median_days==3&&tied$summary$lower_95_days==2)
check("Tied upper confidence limit explicitly unestimable",is.na(tied$summary$upper_95_days)&&startsWith(tied$summary$upper_95_state,"Unestimable"))
all_deaths <- fixture[1:3,];all_deaths$status<-1L
death_only <- rkm_fit(all_deaths,"Synthetic death only")$summary
check("All-death OS fixture has no reverse events and no median",death_only$global_followup_ends==0&&is.na(death_only$median_days)&&startsWith(death_only$median_state,"Unestimable"))
empty <- fixture[1,,drop=FALSE];empty$endpoint_eligible<-FALSE;empty$followup_days<-NA_real_;empty$status<-NA_integer_
unavailable <- rkm_fit(empty,"Synthetic unavailable")$summary
check("Unavailable global OS has explicit denominator and state",unavailable$total_courses==1&&unavailable$available_global_os==0&&unavailable$unavailable_global_os==1&&startsWith(unavailable$median_state,"Unavailable"))
half <- fixture[1:2,];half$followup_days<-c(1,2);half$status<-0L
check("Exact half-survival plateau uses standard KM midpoint median",rkm_fit(half,"Synthetic midpoint")$summary$median_days==1.5)
tests <- do.call(rbind,tests)
utils::write.csv(tests,file.path(output,"synthetic_verification.csv"),row.names=FALSE)
if(any(tests$status!="PASS"))stop("Focused synthetic reverse-KM verification failed")

input_hash <- unname(tools::md5sum(input))
source <- utils::read.csv(input,check.names=FALSE,stringsAsFactors=FALSE,na.strings="")
required <- c("scenario","endpoint","course_id","patient_cluster_id","analysis_flare",
  "endpoint_eligible","status","followup_days","endpoint_exclusion_reason")
if(!all(required %in% names(source)))stop("Canonical global OS audit schema is incomplete")
data <- source[source$scenario=="primary"&source$endpoint=="OS",required,drop=FALSE]
if(!nrow(data)||anyDuplicated(data$course_id))stop("Expected unique primary global OS course records")
if(!is.logical(data$analysis_flare)||!is.logical(data$endpoint_eligible))stop("Canonical classification and eligibility must be logical")
bad_eligible <- !is.na(data$endpoint_eligible)&data$endpoint_eligible&
  (!is.finite(data$followup_days)|data$followup_days<=0|is.na(data$status)|!data$status %in% 0:1)
if(any(bad_eligible))stop("A canonical eligible OS record has invalid duration/status; source review is required")
populations <- list(Overall=data,"Documented flare"=data[!is.na(data$analysis_flare)&data$analysis_flare,,drop=FALSE],
  "No documented flare"=data[!is.na(data$analysis_flare)&!data$analysis_flare,,drop=FALSE])
fits <- lapply(names(populations),function(group)rkm_fit(populations[[group]],group))
aggregate <- do.call(rbind,lapply(fits,`[[`,"summary"))
steps <- do.call(rbind,lapply(fits,`[[`,"steps"))
utils::write.csv(aggregate,file.path(output,"global_os_followup_reverse_km.csv"),row.names=FALSE,na="")
utils::write.csv(steps,file.path(output,"reverse_km_curve_steps.csv"),row.names=FALSE,na="")
excluded <- data[is.na(data$endpoint_eligible)|!data$endpoint_eligible,,drop=FALSE]
utils::write.csv(excluded,file.path(output,"global_os_unavailable_restricted.csv"),row.names=FALSE,na="")
if(input_hash!=unname(tools::md5sum(input)))stop("Canonical input changed during descriptive execution")
result <- list(analysis="Descriptive reverse Kaplan-Meier global OS follow-up",groups=aggregate,
  input_file=input,input_md5=input_hash,input_scenario="primary",input_endpoint="OS",
  event_definition="Canonical OS status 0 becomes a reverse-KM event; canonical OS death status 1 is censored at the valid death observation",
  duration_definition="Canonical global OS follow-up days from first administered step-up dose; months equal days divided by 30.4375",
  confidence_definition="Standard 95% log-log Greenwood confidence bands inverted at survival 0.5; undefined median or bound is explicitly unestimable",
  applicability="Course-level descriptive follow-up for the primary known-status comparative population; valid global OS records need no flare-onset date or complete model covariates. Local symptom, lesion and flare-specific assessments do not supply global follow-up. Standard Greenwood intervals do not account for repeated courses within a patient. Group-specific follow-up is not a survival effect or evidence of treatment benefit.",
  reference=list(citation_key="Schemper1996",doi="10.1016/0197-2456(96)00075-x",pmid="8889347"),
  checks=list(synthetic_passed=nrow(tests),canonical_input_unchanged=TRUE))
jsonlite::write_json(result,file.path(output,"global_os_followup_reverse_km.json"),dataframe="rows",
  auto_unbox=TRUE,pretty=TRUE,na="null",digits=NA)
writeLines(c("Drafting-only global OS follow-up; existing analytical/public artifacts are unchanged.",
  "No bootstrap or inferential model was added.",capture.output(sessionInfo())),file.path(output,"session_info.txt"))
cat("Reverse KM complete:",nrow(data),"primary courses;",nrow(tests),"focused checks passed.\n")
