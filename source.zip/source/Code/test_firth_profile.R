#!/usr/bin/env Rscript
args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))args[1]else "."
runtime<-Sys.getenv("TF_R_LIBRARY","")
if(nzchar(runtime)).libPaths(c(normalizePath(runtime,mustWork=TRUE),.libPaths()))
source(file.path(root,"Code/model_functions.R"))
checks<-0L
check<-function(value){stopifnot(isTRUE(value));checks<<-checks+1L}
close<-function(a,b) isTRUE(all.equal(unname(a),unname(b),tolerance=1e-9))
if(!identical(Sys.getenv("TF_TEST_COX_PH_ONLY",""),"1")) {
d<-data.frame(y=c(rep(0,20),rep(1,20)),v=c(rep(0,20),rep(1,20)))
f<-tf_ash_firth_fit(d,"y","v","v")
ref<-logistf::logistf(y~v,data=d,pl=TRUE,plconf=2,control=logistf::logistf.control(
  maxit=200,lconv=1e-7,gconv=1e-7,xconv=1e-7),plcontrol=logistf::logistpl.control(maxit=200,lconv=1e-7,xconv=1e-7))
check(f$converged&&f$inference_available)
check(close(f$coefficient,ref$coefficients["v"]))
check(close(f$log_ci_low,ref$ci.lower["v"]))
check(close(f$log_ci_high,ref$ci.upper["v"]))
check(close(f$p_value,ref$prob["v"]))
check(close(f$p_value,logistf::logistftest(ref,test=2)$prob))
check(close(f$p_value,pchisq(f$plr_statistic,1,lower.tail=FALSE)))
check(f$log_ci_low<f$coefficient&&f$coefficient<f$log_ci_high)
check(abs((f$coefficient-f$log_ci_low)-(f$log_ci_high-f$coefficient))>.5)
check(!f$retry_used&&f$attempts==1L)
retry<-tf_ash_firth_fit(d,"y","v","v",initial_maxit=1L,retry_maxit=200L)
check(retry$retry_used&&retry$attempts==2L&&retry$inference_available)
check(close(retry$coefficient,f$coefficient)&&close(retry$p_value,f$p_value))
failed<-tf_ash_firth_fit(d,"y","v","v",initial_maxit=1L,retry_maxit=1L)
check(!failed$converged&&!failed$inference_available&&is.na(failed$p_value))
no_y<-d;no_y$y<-0L
check(!tf_ash_firth_fit(no_y,"y","v","v")$inference_available)
no_x<-d;no_x$v<-0L
check(!tf_ash_firth_fit(no_x,"y","v","v")$inference_available)
d$course_id<-paste0("S",seq_len(nrow(d)));d$patient_cluster_id<-rep(paste0("P",1:20),each=2)
d$flare<-d$y;d$v[1]<-NA
m<-tf_ash_firth_profile(d,"y","v","v","Synthetic","Baseline","primary","synthetic",progress=FALSE)
check(m$table$n_courses==39&&m$table$n_patient_clusters==20&&m$table$excluded_missing==1)
check(!m$membership$included[1]&&all(m$membership$included[-1]))
check(m$membership$exclusion_reason[1]=="v")
check(m$table$inference_method=="Firth profile penalized likelihood")
check(!any(grepl("bootstrap|seed|draw",names(m$table))))
check(m$table$point_converged&&m$table$profile_converged&&m$table$plr_converged)
check(close(log(m$table$conf_low),m$table$log_ci_low))
# Adjusted reference and coefficient-specific restricted LR testing.
e<-data.frame(y=rep(c(0,0,1,1,0,1,1,1),10),v=rep(c(0,0,0,0,1,1,1,1),10),age=rep(seq(-2,2,length.out=8),10))
a<-tf_ash_firth_fit(e,"y",c("v","age"),"v")
b<-logistf::logistf(y~v+age,data=e,pl=TRUE,plconf=2,control=logistf::logistf.control(maxit=200,lconv=1e-7,gconv=1e-7,xconv=1e-7),plcontrol=logistf::logistpl.control(maxit=200,lconv=1e-7,xconv=1e-7))
check(a$inference_available&&close(a$coefficient,b$coefficients["v"]))
check(close(a$log_ci_low,b$ci.lower["v"])&&close(a$log_ci_high,b$ci.upper["v"]))
check(close(a$p_value,logistf::logistftest(b,test=2)$prob))
# A failed profile must never fall back to a model-based Wald interval or P value.
original<-tf_ash_firth_attempt
assign("tf_ash_firth_attempt",function(...){x<-original(...);x$profile_converged<-FALSE;
  x$inference_available<-FALSE;x$log_ci_low<-x$log_ci_high<-x$p_value<-NA_real_;x},envir=.GlobalEnv)
limited<-tf_ash_firth_fit(e,"y",c("v","age"),"v")
check(limited$converged&&!limited$inference_available&&is.na(limited$log_ci_low)&&is.na(limited$p_value))
assign("tf_ash_firth_attempt",original,envir=.GlobalEnv)
# Invalid inference outputs suppress CI and P immediately; iterations cannot fix them.
fixture<-data.frame(y=rep(0:1,each=20),v=rep(0:1,each=20))
base<-f$fit;restricted<-f$restricted_fit
invalid_cases<-list()
bad<-base;bad$method.ci[2]<-"Wald";invalid_cases$method<-bad
bad<-base;bad$prob["v"]<-1.1;invalid_cases$p_value<-bad
bad<-base;bad$ci.lower["v"]<-base$ci.upper["v"];bad$ci.upper["v"]<-base$ci.lower["v"];invalid_cases$order<-bad
bad<-base;bad$ci.upper["v"]<-1000;invalid_cases$overflow<-bad
bad<-base;bad$pl.iter<-matrix(0,1,3);invalid_cases$malformed_diagnostics<-bad
for(case in names(invalid_cases)) {
  assessed<-tf_ash_firth_assess(invalid_cases[[case]],restricted,"v",2L,200L)
  check(assessed$converged&&!assessed$inference_available&&!assessed$retry_eligible)
  calls<-0L
  assign("tf_ash_firth_attempt",function(...){calls<<-calls+1L;assessed},envir=.GlobalEnv)
  result<-tf_ash_firth_fit(fixture,"y","v","v")
  check(calls==1L&&result$attempts==1L&&!result$retry_used)
  check(close(result$coefficient,f$coefficient)&&is.na(result$log_ci_low)&&is.na(result$log_ci_high)&&is.na(result$p_value))
}
assign("tf_ash_firth_attempt",original,envir=.GlobalEnv)
structural<-tf_ash_firth_assess(NULL,NULL,"v",2L,200L,failure="Singular model matrix")
check(!structural$converged&&!structural$retry_eligible)
restricted_invalid<-tf_ash_firth_assess(base,NULL,"v",2L,200L,restricted_failure="Singular restricted matrix")
check(restricted_invalid$converged&&!restricted_invalid$inference_available&&!restricted_invalid$retry_eligible)
# A finite, correctly formed profile that has not reached tolerance is retryable.
nonconverged<-base;nonconverged$pl.conv[1,"upper, beta"]<-1e-3
check(tf_ash_firth_assess(nonconverged,restricted,"v",2L,200L)$retry_eligible)
nonconverged<-base;nonconverged$pl.iter[2,"Upper"]<-200L
check(tf_ash_firth_assess(nonconverged,restricted,"v",2L,200L)$retry_eligible)
# Invalid output must block retry even if an iteration failure occurs concurrently.
bad<-base;bad$prob["v"]<-1.1;bad$pl.iter[2,"Upper"]<-200L
check(!tf_ash_firth_assess(bad,restricted,"v",2L,200L)$retry_eligible)
# The diagnostic output contract includes the explicitly named Firth export.
source(file.path(root,"Code/summary_functions.R"))
output<-tempfile("firth-diagnostics-export-");dir.create(output)
tf_export_firth_diagnostics(m$diagnostics,output)
check(file.exists(file.path(output,"firth_diagnostics.csv")))
exported<-read.csv(file.path(output,"firth_diagnostics.csv"),stringsAsFactors=FALSE)
check(isTRUE(all.equal(exported,m$diagnostics,check.attributes=FALSE,tolerance=1e-12)))
unlink(output,recursive=TRUE)
cat(checks,"Firth profile, penalized LR, separation, missingness, convergence-only retry and named diagnostic export checks passed\n")
}

# The existing model-test entry point also exercises Cox PH inference/export.
# TF_TEST_COX_PH_ONLY=1 runs this section without fitting any Firth model.
source(file.path(root,"Code/analysis_functions.R"))
source(file.path(root,"Code/survival_functions.R"))
source(file.path(root,"Code/summary_functions.R"))
ph_start<-checks
i<-seq_len(80L)
z<-data.frame(course_id=paste0("C",i),patient_cluster_id=rep(paste0("P",1:40),each=2),
  tstart=0,tstop=3+(i*7 %% 29)+i/100,event=as.integer(i %% 5 != 0),
  flare_td=as.integer(i %% 2 == 0),v=rep(seq(-2,2,length.out=10),8))
unadjusted<-tf_ash_fit_cox(z,character(),"primary","Unadjusted: all eligible",80L)
adjusted<-tf_ash_fit_cox(z,"v","primary","Adjusted: six baseline variables",80L)
for(fit in list(unadjusted,adjusted)) {
  direct<-survival::cox.zph(fit$fit,transform="km",terms=TRUE,global=TRUE)
  check(identical(fit$table$ph_status,"computed"))
  check(close(fit$table$ph_global_p,direct$table["GLOBAL","p"]))
  check(close(fit$table$ph_flare_p,direct$table["flare_td","p"]))
  check(close(fit$ph$ph_global_chisq,direct$table["GLOBAL","chisq"]))
  check(fit$ph$ph_global_df==direct$table["GLOBAL","df"])
  check(fit$ph$ph_finite_transformed_times_and_residuals&&!fit$ph$ph_test_patient_cluster_robust)
}
check(identical(unadjusted$ph$ph_global_p,unadjusted$ph$ph_flare_p))
check(identical(unadjusted$ph$ph_global_chisq,unadjusted$ph$ph_flare_chisq))
check(unadjusted$ph$ph_global_df==1L&&unadjusted$ph$ph_flare_df==1L)
historical<-tf_ash_fit_cox(z,character(),"original_master_endpoints","Unadjusted: all eligible",80L)
check(historical$table$ph_status=="computed"&&close(historical$table$ph_global_p,unadjusted$table$ph_global_p))
direct<-survival::cox.zph(unadjusted$fit)
warned<-tf_ash_cox_ph(unadjusted$fit,function(...){warning("Synthetic PH warning");direct})
check(warned$ph_status=="computed_with_warnings"&&warned$ph_warning_count==1L)
check(grepl("Synthetic PH warning",warned$ph_diagnostic)&&close(warned$ph_global_p,unadjusted$table$ph_global_p))
bad<-direct;bad$y[1,1]<-NA_real_
invalid<-tf_ash_cox_ph(unadjusted$fit,function(...)bad)
check(invalid$ph_status=="failed"&&is.na(invalid$ph_global_p)&&is.na(invalid$ph_flare_p))
bad<-direct;bad$x<-rep("invalid",length(bad$x))
invalid<-tf_ash_cox_ph(unadjusted$fit,function(...)bad)
check(invalid$ph_status=="failed"&&nzchar(invalid$ph_diagnostic))
bad<-direct;bad$table["GLOBAL","p"]<-1.1
check(tf_ash_cox_ph(unadjusted$fit,function(...)bad)$ph_status=="failed")
check(tf_ash_cox_ph(NULL)$ph_status=="not_estimable")
original_ph<-tf_ash_cox_ph
assign("tf_ash_cox_ph",function(fit,...)original_ph(fit,function(...)stop("Synthetic PH failure")),envir=.GlobalEnv)
for(covariates in list(character(),"v")) {
  failed_ph<-tf_ash_fit_cox(z,covariates,"primary",if(length(covariates))"Adjusted: six baseline variables"else"Unadjusted: all eligible",80L)
  reference<-if(length(covariates))adjusted else unadjusted
  check(!is.null(failed_ph$fit)&&failed_ph$table$model_status=="Estimated (exploratory)")
  check(failed_ph$table$ph_status=="failed"&&grepl("Synthetic PH failure",failed_ph$table$ph_diagnostic))
  check(is.na(failed_ph$table$ph_global_p)&&is.na(failed_ph$table$ph_flare_p))
  check(close(unlist(failed_ph$table[c("estimate","conf_low","conf_high","p_value")]),
    unlist(reference$table[c("estimate","conf_low","conf_high","p_value")])))
}
assign("tf_ash_cox_ph",original_ph,envir=.GlobalEnv)
count_fields<-c("n_courses","n_patient_clusters","exposed_courses","unexposed_courses",
  "courses_with_unexposed_time","events","exposed_events","unexposed_events",
  "total_model_eligible_courses","excluded_missing")
diagnostics<-do.call(rbind,lapply(c("primary","strict","without_dominant_site","original_master_endpoints"),function(scenario)
  do.call(rbind,lapply(list(unadjusted,adjusted),function(fit)cbind(
    data.frame(scenario=scenario,endpoint="PFS",model=fit$table$model),
    fit$table[count_fields],as.data.frame(fit$ph,stringsAsFactors=FALSE))))))
diagnostics$estimate<-1;diagnostics$course_id<-"SYNTHETIC";diagnostics$patient_id<-"SYNTHETIC"
output<-tempfile("cox-ph-export-",tmpdir=root);dir.create(output)
projected<-tf_export_cox_ph_diagnostics(diagnostics,output)
check(nrow(projected)==6L&&!any(projected$scenario=="original_master_endpoints"))
check(!any(c("estimate","conf_low","conf_high","p_value","course_id","patient_id") %in% names(projected)))
check(file.exists(file.path(output,"cox_ph_diagnostics.csv")))
exported<-read.csv(file.path(output,"cox_ph_diagnostics.csv"),stringsAsFactors=FALSE,na.strings="")
check(isTRUE(all.equal(exported[names(exported)!="ph_diagnostic"],projected[names(projected)!="ph_diagnostic"],check.attributes=FALSE,tolerance=1e-12)))
duplicate<-rbind(diagnostics,diagnostics[1,])
check(inherits(try(tf_export_cox_ph_diagnostics(duplicate,output),silent=TRUE),"try-error"))
# The existing analytical exporter reaches the clinical PH export before its
# later outputs. Stub writes and stop afterward; no Firth fit is performed.
original_write<-tf_write;original_firth_export<-tf_export_firth_diagnostics
captured<-list()
assign("tf_write",function(data,out,name){captured[[name]]<<-data;invisible(NULL)},envir=.GlobalEnv)
assign("tf_export_firth_diagnostics",function(...)stop("Stopped after PH export"),envir=.GlobalEnv)
model_output<-setNames(rep(list(data.frame()),7),c("models","model_diagnostics","missingness",
  "survival","clinical","hospitalization","landmark_sensitivity"))
model_output$cox_ph_diagnostics<-diagnostics
export_call<-try(tf_export_models(NULL,model_output,output),silent=TRUE)
assign("tf_write",original_write,envir=.GlobalEnv)
assign("tf_export_firth_diagnostics",original_firth_export,envir=.GlobalEnv)
check(inherits(export_call,"try-error")&&grepl("Stopped after PH export",as.character(export_call)))
check("cox_ph_diagnostics" %in% names(captured)&&nrow(captured$cox_ph_diagnostics)==6L)
check(!any(c("estimate","course_id","patient_id") %in% names(captured$cox_ph_diagnostics)))
unlink(output,recursive=TRUE)
cat(checks-ph_start,"Cox PH direct-reference, warning/failure preservation, historical-helper and clinical-export checks passed\n")
