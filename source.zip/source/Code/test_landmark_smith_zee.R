#!/usr/bin/env Rscript
# Synthetic fixture. One event and the exposure switch both occur on day 4.
script <- grep("^--file=", commandArgs(), value = TRUE)
code <- dirname(normalizePath(sub("^--file=", "", script[1L]), mustWork = TRUE))
source(file.path(code, "survival_functions.R"))
source(file.path(code, "landmark_smith_zee.R"))
fixture <- data.frame(tstart = c(0, 0, 0, 4, 0, 3, 0, 0, 0, 0, 0),
                      tstop = c(4, 8, 4, 8, 3, 6, 5, 5, 7, 9, 10),
                      event = c(1, 0, 0, 1, 0, 1, 1, 1, 1, 0, 0),
                      flare_td = c(0, 0, 0, 1, 0, 1, 0, 0, 0, 1, 0),
                      baseline_x = c(0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 0))
fit <- survival::coxph(survival::Surv(tstart, tstop, event) ~ flare_td + baseline_x,
                       data = fixture, ties = "efron", x = TRUE, model = TRUE)
days <- 0:9
for (value in 0:1) {
  paths <- data.frame(tstart = c(0, 0, 4), tstop = c(10, 4, 10), event = 0,
                      flare_td = c(0, 0, 1), baseline_x = value, history = c(1, 2, 2))
  comparison <- survival::survfit(fit, newdata = paths, id = history)
  expected <- summary(comparison, times = days, extend = TRUE)
  actual <- tf_smith_zee_curves(fit, data.frame(baseline_x = value), days)
  steps <- tf_smith_zee_curves(fit, data.frame(baseline_x = value), c(0, 4, 9), fitted_steps = TRUE)
  for (history in unique(steps$history)) {
    path <- steps[steps$history == history, ]
    reference <- actual[actual$history == history & actual$day %in% path$day, ]
    stopifnot(all(path$day == reference$day), identical(path$survival, reference$survival),
              identical(path$lower95, reference$lower95), identical(path$upper95, reference$upper95),
              5 %in% path$day)
  }
  stopifnot(isTRUE(all.equal(actual$survival, expected$surv, tolerance = 1e-12)),
            isTRUE(all.equal(actual$lower95, expected$lower, tolerance = 1e-12)),
            isTRUE(all.equal(actual$upper95, expected$upper, tolerance = 1e-12)),
            length(unique(actual$survival[actual$day == 4])) == 1L,
            actual$survival[actual$day == 4][1] < actual$survival[actual$day == 3][1])
}
# Check the adjusted landmark result remains explicit when one group has no events.
landmark <- data.frame(course_id = paste0("course_", 1:4), patient_cluster_id = paste0("person_", 1:4),
                       flare_by_landmark = c(0, 0, 1, 1), followup_after_landmark_days = c(5, 9, 8, 10),
                       status = c(1, 0, 0, 0), baseline_x = c(0, 1, 0, 1))
invalid <- tf_adjust_landmark(landmark, "baseline_x", "PFS", 30)$table
stopifnot(invalid$model_status == "Not estimable", invalid$exposed_events == 0L,
          invalid$exposed_courses == 2L, is.na(invalid$estimate), grepl("No endpoint events", invalid$fit_reason))
cat("Synthetic survfit parity, day-4 tie behavior and invalid-landmark reporting passed.\n")
