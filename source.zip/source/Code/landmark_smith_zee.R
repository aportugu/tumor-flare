# Cox landmark models and standardized predictions under specified flare histories.
tf_adjust_landmark <- function(data, covariates, endpoint, day) {
  complete <- data[stats::complete.cases(data[covariates]), , drop = FALSE]
  unmatched <- edc_fit_exposure_cox(data, "flare_by_landmark")
  matched <- edc_fit_exposure_cox(complete, "flare_by_landmark")
  result <- matched$table
  result[c("estimate", "conf_low", "conf_high", "p_value")] <- NA_real_
  result$model_status <- "Not estimable"
  reason <- matched$table$diagnostic
  warnings <- character()
  fit <- NULL
  has_events_in_both_groups <- all(c(0L, 1L) %in% complete$flare_by_landmark[complete$status == 1L])
  if (has_events_in_both_groups && result$n_patient_clusters >= 2L) {
    formula <- stats::reformulate(c("flare_by_landmark", covariates),
                                  "survival::Surv(followup_after_landmark_days, status)")
    fit <- tryCatch(withCallingHandlers(
      survival::coxph(formula, data = complete, ties = "efron", cluster = patient_cluster_id,
                      robust = TRUE, x = TRUE, model = TRUE),
      warning = function(w) {
        warnings <<- c(warnings, conditionMessage(w))
        invokeRestart("muffleWarning")
      }), error = function(e) { reason <<- conditionMessage(e); NULL })
    if (!is.null(fit)) {
      beta <- stats::coef(fit)
      se <- suppressWarnings(sqrt(stats::vcov(fit)["flare_by_landmark", "flare_by_landmark"]))
      log_hr <- unname(beta["flare_by_landmark"])
      limits <- exp(log_hr + c(-1, 1) * stats::qnorm(.975) * se)
      if (any(grepl("converg|infinite|singular|iteration|ran out", warnings, ignore.case = TRUE))) {
        reason <- paste(unique(warnings), collapse = " | ")
      } else if (any(!is.finite(beta))) {
        reason <- "Singular or nonfinite coefficient"
      } else if (!all(is.finite(c(exp(log_hr), se, limits))) || se <= 0 || any(limits <= 0)) {
        reason <- "Nonfinite estimate or interval, or nonpositive variance"
      } else {
        result$estimate <- exp(log_hr)
        result$conf_low <- limits[1L]
        result$conf_high <- limits[2L]
        result$p_value <- 2 * stats::pnorm(-abs(log_hr / se))
        result$model_status <- "Estimated (exploratory)"
        reason <- ""
      }
    }
  }
  result$excluded_missing <- nrow(data) - nrow(complete)
  result$endpoint <- endpoint
  result$landmark_day <- day
  result$fit_reason <- reason
  result$object_id <- paste("primary", endpoint, "landmark", day, "adjusted", sep = ":")
  ph <- if (result$model_status != "Not estimable") tryCatch(
    survival::cox.zph(fit, transform = "km"), error = function(e) conditionMessage(e)) else reason
  audit <- list(all_eligible = unmatched$table, complete_case = matched$table,
                adjusted = result, warnings = warnings,
                ph = if (inherits(ph, "cox.zph")) {
                  data.frame(term = rownames(ph$table), as.data.frame(ph$table), row.names = NULL)
                } else ph)
  columns <- c("endpoint", "landmark_day", "n_courses", "n_patient_clusters", "exposed_courses",
               "exposed_events", "events", "excluded_missing", "estimate", "conf_low",
               "conf_high", "p_value", "model_status", "fit_reason", "object_id")
  list(table = result[columns], audit = audit)
}

# Use the two counting-process exposure paths and survfit confidence interval
# defaults from the discontinuation analysis. All covariates are held fixed.
tf_smith_zee_curves <- function(fit, profile, days, switch_day = 4, fitted_steps = FALSE) {
  covariates <- setdiff(names(stats::coef(fit)), "flare_td")
  stopifnot(nrow(profile) == 1L, setequal(names(profile), covariates),
            !anyNA(profile), length(days) > 1L, !is.unsorted(days, strictly = TRUE),
            days[1L] == 0, switch_day %in% days, max(days) > switch_day)
  histories <- c("no_flare", "flare_day_4")
  horizon <- max(days)
  paths <- cbind(data.frame(history = histories[c(1L, 2L, 2L)], tstart = c(0, 0, switch_day),
                            tstop = c(horizon, switch_day, horizon), event = 0L, flare_td = c(0L, 0L, 1L)),
                 profile[rep(1L, 3L), covariates, drop = FALSE])
  predicted <- survival::survfit(fit, newdata = paths, id = history, conf.int = .95, conf.type = "log")
  stopifnot(identical(names(predicted$strata), histories))
  if (fitted_steps) {
    # Keep changes in the fitted curves and limits, as in the discontinuation export.
    values <- cbind(predicted$surv, predicted$lower, predicted$upper)
    by_history <- rep(seq_along(histories), times = predicted$strata)
    changed_days <- unlist(lapply(split(seq_len(nrow(values)), by_history), function(rows) {
      path <- values[rows, , drop = FALSE]
      previous <- rbind(c(1, 1, 1), path[-nrow(path), , drop = FALSE])
      predicted$time[rows][rowSums(path != previous) > 0]
    }), use.names = FALSE)
    changed_days <- changed_days[changed_days > 0 & changed_days < horizon]
    days <- sort(unique(c(days, changed_days)))
  }
  sampled <- summary(predicted, times = days, extend = TRUE)
  stopifnot(identical(unname(sampled$time), rep(days, 2L)),
            identical(as.character(sampled$strata), rep(histories, each = length(days))))
  data.frame(history = as.character(sampled$strata), day = sampled$time,
             survival = sampled$surv, lower95 = sampled$lower, upper95 = sampled$upper)
}
