#!/usr/bin/env python3
"""Independent aggregate-extraction tests using clearly synthetic inputs only.

Run with Python's standard library. The extractor is selected by a command-line
argument or is found beside this file. Temporary input fixtures are deleted
after the run. Reports contain aggregate results, test names, and file hashes.
No study records, clinical identifiers, clinical dates, or private paths are
included in this test source.
"""

import argparse
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile


PARTITIONS = (
    "Comparative analytic set", "Unavailable flare status", "Bridging excluded",
    "Subsequent BCMA-directed course excluded",
)
REVIEW = "Case-review subset"
OTHER = "Other courses"
TOTAL = "Total cohort"
FIELDS = (
    "course_id", "original_flare", "analysis_flare", "edc_received",
    "investigator_confidence", "comparative_eligible", "bridging_any",
    "keep_first_bcma", "synthetic_extra_narrative",
    "synthetic_extra_calendar", "synthetic_extra_location",
)
EXPECTED = {
    "additional_from_preliminary_false": 2, "additional_suspected": 2,
    "bridging_excluded": 1, "canonical_false": 4, "canonical_true": 5,
    "canonical_unavailable": 3, "clinical_bridging_excluded": 1,
    "clinical_subsequent_bcma_excluded": 1, "confidence_definite": 2,
    "confidence_possible": 2, "confidence_probable": 1, "courses_total": 12,
    "preliminary_false": 5, "preliminary_suspected": 4,
    "preliminary_suspected_retained": 3, "preliminary_true": 4,
    "preliminary_unavailable": 3, "primary_comparative_controls": 4,
    "primary_comparative_population": 7, "primary_comparative_suspected": 3,
    "removed_after_secondary_review": 1, "returned_suspected_edc": 5,
    "strict_clinical_suspected": 3, "strict_comparative_suspected": 1,
    "subsequent_bcma_excluded": 1, "targeted_candidate_courses": 6,
    "treatment_eligible": 10,
    "treatment_eligible_with_unavailable_canonical_status": 3,
}
PRIVATE_HEADERS = re.compile(
    r"(^|_)(course_id|patient_id|patient_cluster_id|case_id|source_course_key|"
    r"narrative|calendar_date|start_date|source_path)($|_)", re.I,
)
CALENDAR_VALUE = re.compile(r"\b(?:19|20)\d{2}[-/]\d{1,2}[-/]\d{1,2}\b")


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_csv(path):
    with path.open(newline="", encoding="utf-8") as handle:
        return list(csv.DictReader(handle))


def write_csv(path, rows, columns):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        writer.writerows(rows)


def fixtures():
    specifications = (
        ("TRUE", "TRUE", "TRUE", "Definite", "FALSE", "FALSE", "FALSE"),
        ("TRUE", "TRUE", "TRUE", "Probable", "FALSE", "TRUE", "TRUE"),
        ("TRUE", "TRUE", "TRUE", "Possible", "TRUE", "FALSE", "TRUE"),
        ("TRUE", "FALSE", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("FALSE", "TRUE", "TRUE", "Definite", "TRUE", "FALSE", "TRUE"),
        ("FALSE", "TRUE", "TRUE", "Possible", "TRUE", "FALSE", "TRUE"),
        ("FALSE", "FALSE", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("FALSE", "FALSE", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("FALSE", "FALSE", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("", "", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("", "", "FALSE", "", "TRUE", "FALSE", "TRUE"),
        ("", "", "FALSE", "", "TRUE", "FALSE", "TRUE"),
    )
    rows = []
    invented_calendar = "-".join(("1900", "01", "01"))
    invented_location = "/" + "synthetic-private-location"
    for index, values in enumerate(specifications, 1):
        row = dict(zip(FIELDS, (
            f"SYNTHETIC_PRIVATE_KEY_{index:03d}", *values,
            "SYNTHETIC_PRIVATE_NARRATIVE", invented_calendar, invented_location,
        )))
        rows.append(row)
    correction = {
        "course_id": rows[3]["course_id"], "field": "analysis_flare",
        "action": "set", "value": "FALSE",
        "supporting_source": "SYNTHETIC_PRIVATE_DOCUMENT",
        "clarification_pointer": "SYNTHETIC_PRIVATE_POINTER",
        "controlled_rule_pointer": "", "reason": "SYNTHETIC_PRIVATE_NARRATIVE",
    }
    register = {
        "course_id": rows[3]["course_id"], "field": "analysis_flare",
        "canonical_value": "FALSE", "source": "Verified site clarification",
        "source_state": "Recorded", "is_final_record": "TRUE",
        "changed": "TRUE", "original_master_value": "TRUE",
        "clarification_pointer": "SYNTHETIC_PRIVATE_POINTER",
        "controlled_rule_pointer": "", "reason": "SYNTHETIC_PRIVATE_NARRATIVE",
    }
    return rows, correction, register


def test_cases():
    rows, correction, register = fixtures()
    cases = []

    def add(name, records=None, evidence=None, schema="corrections", accept=False):
        cases.append((name, deepcopy(rows if records is None else records),
                      deepcopy([correction] if evidence is None else evidence),
                      schema, accept))

    add("valid_mixed_fixture", accept=True)
    add("row_order_invariance", records=list(reversed(rows)), accept=True)
    add("equivalent_final_register", evidence=[register], schema="register", accept=True)
    for name, index in (("retained_positive_without_return", 0),
                        ("added_positive_without_return", 4)):
        changed = deepcopy(rows)
        changed[index]["edc_received"] = "FALSE"
        add(name, records=changed)
    add("clearance_without_evidence", evidence=[])
    for name, field, value in (
        ("wrong_field", "field", "analysis_response"),
        ("invalidate_not_set", "action", "invalidate"),
        ("wrong_assignment", "value", "TRUE"),
        ("empty_source", "supporting_source", ""),
        ("empty_pointer", "clarification_pointer", ""),
    ):
        changed = deepcopy(correction)
        changed[field] = value
        add("witness_" + name, evidence=[changed])
    for name, field, value in (
        ("unverified_register_source", "source", "Master"),
        ("nonfinal_register_only", "is_final_record", "FALSE"),
        ("unchanged_register_witness", "changed", "FALSE"),
        ("blank_register_witness", "source_state", "Blank"),
        ("mismatched_prior_state_register", "original_master_value", "FALSE"),
    ):
        changed = deepcopy(register)
        changed[field] = value
        add(name, evidence=[changed], schema="register")
    changed = deepcopy(correction)
    changed["value"] = "TRUE"
    add("last_correction_supersedes_clearance", evidence=[correction, changed])
    add("duplicate_final_register", evidence=[register, register], schema="register")
    add("duplicate_consistent_corrections_count_once",
        evidence=[correction, correction], accept=True)
    add("duplicate_canonical_record", records=rows + [deepcopy(rows[0])])
    changed = deepcopy(rows)
    changed[1]["edc_received"] = "not_a_boolean"
    add("invalid_logical_token", records=changed)
    changed = [{key: value for key, value in row.items()
                if key != "investigator_confidence"} for row in rows]
    add("missing_confidence_column", records=changed)
    changed = deepcopy(rows)
    changed[0]["investigator_confidence"] = ""
    add("returned_missing_confidence", records=changed)
    changed = deepcopy(rows)
    changed[9]["analysis_flare"] = "FALSE"
    add("unknown_coerced_false_without_authority", records=changed)
    changed = deepcopy(rows)
    changed[9]["analysis_flare"] = "TRUE"
    changed[9]["investigator_confidence"] = "Possible"
    add("unknown_coerced_true_without_return", records=changed)
    changed[9]["edc_received"] = "TRUE"
    add("unknown_authoritatively_positive_history_preserved",
        records=changed, accept=True)
    changed = deepcopy(rows)
    changed[1]["comparative_eligible"] = "TRUE"
    add("overlapping_treatment_dispositions", records=changed)
    changed = deepcopy(rows)
    changed[0]["keep_first_bcma"] = "TRUE"
    add("incomplete_treatment_disposition", records=changed)
    changed = deepcopy(rows)
    changed[3]["edc_received"] = "TRUE"
    add("returned_negative_not_suspected_case_schema", records=changed)
    add("empty_canonical", records=[])
    return cases


def inspect_outputs(output, stdout, stderr):
    texts = [stdout, stderr]
    private_columns = []
    for path in output.iterdir() if output.exists() else ():
        if path.is_file():
            texts.append(path.read_text(encoding="utf-8"))
        if path.suffix == ".csv":
            with path.open() as handle:
                private_columns.extend(
                    key for key in csv.DictReader(handle).fieldnames
                    if PRIVATE_HEADERS.search(key)
                )
    return not private_columns and not any(
        "SYNTHETIC_PRIVATE_" in text or "synthetic-private-location" in text
        or CALENDAR_VALUE.search(text) for text in texts
    )


def verify_expected(output, report, special):
    expected = dict(EXPECTED)
    if special:
        expected.update({
            "additional_from_preliminary_unavailable": 1,
            "additional_suspected": 3, "canonical_true": 6,
            "canonical_unavailable": 2, "confidence_possible": 3,
            "primary_comparative_population": 8,
            "primary_comparative_suspected": 4, "returned_suspected_edc": 6,
            "targeted_candidate_courses": 7,
            "treatment_eligible_with_unavailable_canonical_status": 2,
        })
    if report.get("counts") != expected:
        return False
    expected_full = {
        "source_courses": 12, "case_review_subset": 7 if special else 6,
        "other_source_courses": 5 if special else 6,
    }
    if report.get("full_cohort", {}).get("counts") != expected_full:
        return False
    cells = {
        (PARTITIONS[0], REVIEW): 5 if special else 4,
        (PARTITIONS[0], OTHER): 3, (PARTITIONS[1], REVIEW): 0,
        (PARTITIONS[1], OTHER): 2 if special else 3,
        (PARTITIONS[2], REVIEW): 1, (PARTITIONS[2], OTHER): 0,
        (PARTITIONS[3], REVIEW): 1, (PARTITIONS[3], OTHER): 0,
    }
    matrix = read_csv(output / "full_cohort_review_matrix.csv")
    actual = {(row["cohort_partition"], row["review_destination"]): int(row["n"])
              for row in matrix}
    if len(matrix) != 8 or actual != cells:
        return False
    links = {
        (TOTAL, PARTITIONS[0]): 8 if special else 7,
        (TOTAL, PARTITIONS[1]): 2 if special else 3,
        (TOTAL, PARTITIONS[2]): 1, (TOTAL, PARTITIONS[3]): 1,
    }
    links.update({key: value for key, value in cells.items() if value})
    actual = {(row["source"], row["target"]): int(row["n"])
              for row in read_csv(output / "Figure_1_Full_Cohort_Links.csv")}
    return actual == links


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--extractor", type=Path,
                        default=Path(__file__).with_name("extract_review_transitions.py"))
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    if not args.extractor.is_file():
        parser.error("The selected extractor does not exist.")
    if args.output_dir.exists() and any(args.output_dir.iterdir()):
        parser.error("Use a new or empty output directory.")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    before = sha(args.extractor)
    results = []
    baseline = None
    with tempfile.TemporaryDirectory(prefix="synthetic-extraction-") as temporary:
        temporary = Path(temporary)
        for name, records, evidence, schema, expected_acceptance in test_cases():
            fixture = temporary / name
            fixture.mkdir()
            canonical, site = fixture / "canonical.csv", fixture / "site.csv"
            _, correction, register = fixtures()
            columns = tuple(records[0]) if records else FIELDS
            write_csv(canonical, records, columns)
            write_csv(site, evidence, tuple(register if schema == "register" else correction))
            input_hashes = (sha(canonical), sha(site))
            output = args.output_dir / name
            process = subprocess.run([
                sys.executable, str(args.extractor), "--canonical", str(canonical),
                "--corrections", str(site), "--evidence-schema", schema,
                "--output-dir", str(output),
            ], text=True, capture_output=True)
            validation = output / "ascertainment_validation.json"
            report = json.loads(validation.read_text()) if validation.exists() else {}
            if not report:
                try:
                    report = json.loads(process.stderr)
                except ValueError:
                    pass
            accepted = process.returncode == 0 and report.get("status") == "PASS"
            privacy = inspect_outputs(output, process.stdout, process.stderr)
            counts_match = not expected_acceptance or verify_expected(
                output, report,
                name == "unknown_authoritatively_positive_history_preserved",
            )
            atomic = expected_acceptance or not output.exists() or not list(output.glob("*.csv"))
            unchanged = input_hashes == (sha(canonical), sha(site))
            hashes = {path.name: sha(path) for path in sorted(output.glob("*.csv"))}
            if name == "valid_mixed_fixture":
                baseline = hashes
            ordering = True
            if name in ("row_order_invariance", "equivalent_final_register",
                        "duplicate_consistent_corrections_count_once"):
                ordering = hashes == baseline
            passed = accepted == expected_acceptance and all(
                (privacy, counts_match, atomic, unchanged, ordering)
            )
            results.append({
                "test": name, "expected_acceptance": expected_acceptance,
                "actual_acceptance": accepted, "exit_code": process.returncode,
                "error_code": report.get("error_code"),
                "exact_synthetic_count_matrix_and_link_checks": counts_match,
                "aggregate_export_and_diagnostic_privacy": privacy,
                "no_partial_csv_exports_on_failure": atomic,
                "synthetic_inputs_unchanged": unchanged,
                "ordering_and_evidence_equivalence": ordering,
                "aggregate_csv_sha256": hashes,
                "status": "PASS" if passed else "FAIL",
            })
    source_unchanged = sha(args.extractor) == before
    passed = source_unchanged and all(row["status"] == "PASS" for row in results)
    report = {
        "status": "PASS" if passed else "FAIL", "synthetic_only": True,
        "extractor_sha256": before, "test_count": len(results),
        "passed_tests": sum(row["status"] == "PASS" for row in results),
        "extractor_unchanged": source_unchanged, "results": results,
    }
    (args.output_dir / "independent_extraction_tests.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8",
    )
    print(json.dumps({key: report[key] for key in
                      ("status", "synthetic_only", "test_count", "passed_tests",
                       "extractor_sha256")}, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
