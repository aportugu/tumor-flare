#!/usr/bin/env Rscript
# Focused synthetic checks; no clinical records are read.
suppressPackageStartupMessages({library(dplyr); library(readr)})
args <- commandArgs(trailingOnly = TRUE)
renderer <- if (length(args)) args[1] else "Publication/build_figures_Figure1_Total_Cohort_Sankey.R"
output <- if (length(args) > 1L) args[2] else "figure1_full_cohort_sankey_synthetic_checks.csv"
needed <- c("confidence_levels", "disposition_levels", "reviewed_label", "as_flag",
            "validate_disposition_links", "derive_disposition_links",
            "initial_labels", "withdrawn_label", "validate_initial_links",
            "source_label", "cohort_categories", "cohort_terminals", "validate_full_links")
for (expr in parse(renderer)) {
  if (is.call(expr) && identical(as.character(expr[[1]]), "<-") && as.character(expr[[2]]) %in% needed) eval(expr)
}
cases <- tibble(confidence = rep(confidence_levels, each = 2),
  comparative_included = c(TRUE, FALSE, TRUE, FALSE, TRUE, FALSE),
  bridging = c(FALSE, TRUE, FALSE, FALSE, FALSE, TRUE))
stages <- c("Clinical returned series" = 6, "Primary suspected flare" = 3,
            "Clinical bridging cases" = 2, "Clinical later BCMA cases" = 1,
            "Definite/Probable-only flare" = 2)
stage_count <- function(k) unname(stages[k])
links <- derive_disposition_links(cases, stage_count)
results <- list()
check <- function(name, value) {
  if (!isTRUE(value)) stop(name)
  results[[length(results) + 1L]] <<- tibble(test = name, status = "PASS")
}
rejects <- function(expr) inherits(tryCatch(force(expr), error = identity), "error")
check("Synthetic exact dispositions", identical(as.numeric(vapply(disposition_levels, function(k) sum(links$n[links$target == k]), numeric(1))), c(3, 2, 1)))
check("Synthetic confidence totals", all(vapply(confidence_levels, function(k) sum(links$n[links$source == reviewed_label & links$target == k]), numeric(1)) == 2))
check("Strict eligible courses", sum(links$n[links$source %in% c("Definite", "Probable") & links$target == disposition_levels[1]]) == 2)
check("Zero-count bands omitted", nrow(links) == 9 && all(links$n > 0))
check("Duplicate links rejected", rejects(validate_disposition_links(bind_rows(links, links[1, ]), stage_count)))
bad <- cases; bad$bridging[1] <- TRUE
check("Overlapping inclusion and bridging rejected", rejects(derive_disposition_links(bad, stage_count)))
bad <- cases; bad$comparative_included[1] <- NA
check("Unknown eligibility never inferred", rejects(derive_disposition_links(bad, stage_count)))
bad <- cases; bad$confidence[1] <- "Unknown"
check("Unsupported confidence rejected", rejects(derive_disposition_links(bad, stage_count)))
wrong_strict <- function(k) if (k == "Definite/Probable-only flare") 3 else stage_count(k)
check("Strict total discrepancy rejected", rejects(validate_disposition_links(links, wrong_strict)))
wrong_total <- function(k) if (k == "Clinical returned series") 7 else stage_count(k)
check("Clinical total discrepancy rejected", rejects(validate_disposition_links(links, wrong_total)))
initial <- tibble(source = c(initial_labels[1], initial_labels[1], initial_labels[2]),
  target = c(reviewed_label, withdrawn_label, reviewed_label), n = c(3, 1, 3))
check("Synthetic review totals", sum(validate_initial_links(initial, links)$n) == 7)
check("Review inflow equals clinical series", sum(initial$n[initial$target == reviewed_label]) == 6)
check("Duplicate review links rejected", rejects(validate_initial_links(bind_rows(initial, initial[1, ]), links)))
bad <- initial; bad$source[1] <- "Unsupported review stage"
check("Unsupported review stage rejected", rejects(validate_initial_links(bad, links)))
bad <- initial; bad$n[1] <- 4
check("Review and clinical totals mismatch rejected", rejects(validate_initial_links(bad, links)))
bad <- initial; bad$target[3] <- withdrawn_label
check("Additional cases cannot become preliminary removals", rejects(validate_initial_links(bad, links)))
bad <- initial; bad$n[1] <- 0
check("Zero review bands rejected", rejects(validate_initial_links(bad, links)))
full_stages <- c(stages, "Master courses" = 30, "Supported agents" = 30,
  "First eligible BCMA / all GPRC5D courses" = 26, "Nonbridging eligible courses" = 14,
  "Primary known-status courses" = 10, "Excluded: flare status unavailable" = 4)
full_stage_count <- function(k) unname(full_stages[k])
full <- bind_rows(tibble(source = source_label, target = cohort_categories, n = c(10, 4, 12, 4)),
  tibble(source = rep(cohort_categories, each = 2), target = rep(cohort_terminals, 4), n = c(7, 3, 4, 0, 9, 3, 3, 1))) %>% filter(n > 0)
check("Full source count conserved", sum(validate_full_links(full, initial, full_stage_count)$n[full$source == source_label]) == 30)
check("Full source terminal counts conserved", sum(full$n[full$target %in% cohort_terminals]) == 30)
check("Expanded subset equals case-review source count", sum(full$n[full$target == cohort_terminals[2]]) == sum(initial$n))
check("Zero full-cohort links omitted", nrow(full) == 11 && all(full$n > 0))
check("Duplicate full-cohort links rejected", rejects(validate_full_links(bind_rows(full, full[1, ]), initial, full_stage_count)))
bad <- full; bad$n[1] <- 11
check("Full-cohort stratum discrepancy rejected", rejects(validate_full_links(bad, initial, full_stage_count)))
bad <- initial; bad$n[1] <- 4
check("Full-cohort expanded subset discrepancy rejected", rejects(validate_full_links(full, bad, full_stage_count)))
write_csv(bind_rows(results), output)
cat(length(results), "synthetic checks passed\n")
