#!/usr/bin/env python3
"""Derive aggregate ascertainment data from canonical records and site evidence.

All input and output locations are command-line arguments. Record linkage keys
are used only in memory. Outputs contain finite category labels and aggregate
counts; no linkage keys, free text, source locations, or calendar dates are
exported. Run this extraction with restricted inputs in a secure environment;
only its aggregate outputs are needed by the portable figure renderer.
"""

import argparse
from collections import Counter, defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sys


CANONICAL_FIELDS = (
    "course_id", "original_flare", "analysis_flare", "edc_received",
    "investigator_confidence", "comparative_eligible", "bridging_any",
    "keep_first_bcma",
)
CONFIDENCE = ("Definite", "Probable", "Possible")
STATE_ORDER = {"TRUE": 0, "FALSE": 1, "Unavailable": 2}
PRELIMINARY = "Suspected after preliminary review"
ADDITIONAL = "Additional cases identified during secondary review"
SECONDARY = "Suspected after secondary site review"
REMOVED = "Removed after secondary site review"
DISPOSITIONS = (
    "Primary comparative flare courses", "Bridging excluded",
    "Subsequent BCMA-directed BsAb course excluded",
)
TOTAL_COHORT = "Total cohort"
COHORT_PARTITIONS = (
    "Comparative analytic set", "Unavailable flare status",
    "Bridging excluded", "Subsequent BCMA-directed course excluded",
)
REVIEW_SUBSET = "Case-review subset"
OTHER_COURSES = "Other courses"
UNKNOWN_VALUES = {"", "na", "n/a", "nan", "null", "none", "unknown", "unavailable"}


class ExtractionError(Exception):
    """An aggregate validation failure that never includes input record values."""

    def __init__(self, code, count=1):
        self.code = code
        self.count = count
        super().__init__(code)


def read_csv(path, required, role):
    with path.open(newline="", encoding="utf-8-sig") as handle:
        reader = csv.DictReader(handle)
        if reader.fieldnames is None or not set(required).issubset(reader.fieldnames):
            raise ExtractionError(role + "_missing_required_columns")
        if len(reader.fieldnames) != len(set(reader.fieldnames)):
            raise ExtractionError(role + "_duplicate_columns")
        rows = list(reader)
    if any(None in row or any(value is None for value in row.values()) for row in rows):
        raise ExtractionError(role + "_malformed_csv")
    return rows, set(reader.fieldnames)


def boolean(value, field, allow_unknown=False):
    value = value.strip().lower()
    if value in {"true", "1"}:
        return True
    if value in {"false", "0"}:
        return False
    if allow_unknown and value in UNKNOWN_VALUES:
        return None
    raise ExtractionError("invalid_" + field)


def state(value):
    return "Unavailable" if value is None else ("TRUE" if value else "FALSE")


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def require(condition, code, count=1):
    if not condition:
        raise ExtractionError(code, count)


def documented_negative_updates(path, canonical_keys, schema):
    """Use only final explicit negative corrections with documentary pointers.

    The controlled-corrections schema uses input order: the last correction for
    analysis_flare is final. The provenance-register schema explicitly selects
    is_final_record. Prior or unsupported corrections cannot supply evidence.
    Documentary pointer contents and free-text explanations are never exported.
    """
    base = ("course_id", "field")
    rows, fields = read_csv(path, base, "site_evidence")
    if schema == "auto":
        if {"action", "value", "supporting_source"}.issubset(fields):
            schema = "corrections"
        elif {"canonical_value", "source", "is_final_record"}.issubset(fields):
            schema = "register"
        else:
            raise ExtractionError("unrecognized_site_evidence_schema")
    required = (
        {"action", "value", "supporting_source"}
        if schema == "corrections"
        else {"canonical_value", "source", "source_state", "is_final_record"}
    )
    require(required.issubset(fields), "site_evidence_missing_schema_columns")
    pointer_fields = {"clarification_pointer", "controlled_rule_pointer"} & fields
    require(bool(pointer_fields), "site_evidence_missing_documentary_pointer_columns")

    final = {}
    selected_keys = []
    for row in rows:
        if row["field"].strip() != "analysis_flare":
            continue
        key = row["course_id"].strip()
        if schema == "register" and not boolean(row["is_final_record"], "is_final_record"):
            continue
        selected_keys.append(key)
        if schema == "register":
            require(key not in final, "duplicate_final_analysis_records")
        final[key] = row
    unknown_keys = set(selected_keys) - canonical_keys
    require(not unknown_keys, "site_evidence_linkage_keys_absent_from_canonical", len(unknown_keys))

    documented = set()
    for key, row in final.items():
        has_pointer = any(row.get(field, "").strip() for field in pointer_fields)
        if schema == "corrections":
            explicit_negative = (
                row["action"].strip().lower() == "set"
                and boolean(row["value"], "correction_value", allow_unknown=True) is False
            )
            has_source = bool(row["supporting_source"].strip())
        else:
            canonical_value = boolean(row["canonical_value"], "canonical_value", allow_unknown=True)
            if {"changed", "original_master_value"}.issubset(fields):
                original_value = boolean(row["original_master_value"], "original_master_value", allow_unknown=True)
                require(
                    boolean(row["changed"], "changed") == (original_value != canonical_value),
                    "site_evidence_change_indicator_inconsistent_with_its_values",
                )
            explicit_negative = (
                canonical_value is False
                and row["source_state"].strip().lower() == "recorded"
            )
            has_source = row["source"].strip().lower() in {
                "verified site clarification", "site clarification",
            }
            if explicit_negative and "changed" in fields:
                explicit_negative = boolean(row["changed"], "changed")
        if explicit_negative and has_source and has_pointer:
            documented.add(key)
    return documented, {
        "schema": schema,
        "final_analysis_corrections": len(final),
        "documented_explicit_negative_updates": len(documented),
    }


def build_aggregates(canonical_path, evidence_path, schema):
    raw, _ = read_csv(canonical_path, CANONICAL_FIELDS, "canonical")
    require(bool(raw), "empty_canonical_input")
    keys = [row["course_id"].strip() for row in raw]
    require(all(keys), "empty_canonical_linkage_key")
    require(len(set(keys)) == len(keys), "duplicate_canonical_linkage_keys")
    documented, evidence_summary = documented_negative_updates(evidence_path, set(keys), schema)

    records = []
    for row in raw:
        record = {"key": row["course_id"].strip()}
        for field in ("original_flare", "analysis_flare"):
            record[field] = boolean(row[field], field, allow_unknown=True)
        for field in ("edc_received", "comparative_eligible", "bridging_any", "keep_first_bcma"):
            record[field] = boolean(row[field], field)
        value = row["investigator_confidence"].strip()
        record["confidence"] = next((item for item in CONFIDENCE if item.lower() == value.lower()), None)
        record["documented_negative"] = record["key"] in documented
        records.append(record)

    counts = Counter()
    transitions = defaultdict(Counter)
    links = Counter()
    confidence_disposition = Counter()
    full_cohort_links = Counter()
    cohort_matrix = Counter()
    unresolved = Counter()
    for row in records:
        original, canonical = row["original_flare"], row["analysis_flare"]
        received = row["edc_received"]
        eligible, bridging, subsequent = (
            row["comparative_eligible"], row["bridging_any"], not row["keep_first_bcma"],
        )
        if sum((eligible, bridging, subsequent)) != 1:
            unresolved["treatment_eligibility_disposition_not_exclusive_and_complete"] += 1
        if received and canonical is not True:
            unresolved["returned_suspected_case_not_canonical_true"] += 1
        if canonical is True and not received:
            unresolved["canonical_suspected_case_without_returned_edc"] += 1
        if canonical is True and row["confidence"] is None:
            unresolved["returned_suspected_case_missing_finite_confidence"] += 1
        if original is True and canonical is not True:
            if canonical is not False or not row["documented_negative"]:
                unresolved["preliminary_suspected_course_without_return_or_documented_removal"] += 1
        if original is None and canonical is False and not row["documented_negative"]:
            unresolved["unavailable_preliminary_status_coerced_to_false_without_site_evidence"] += 1
        if row["documented_negative"] and canonical is not False:
            unresolved["final_negative_site_correction_conflicts_with_canonical_state"] += 1

        counts["courses_total"] += 1
        counts["preliminary_" + state(original).lower()] += 1
        counts["canonical_" + state(canonical).lower()] += 1
        counts["treatment_eligible"] += eligible
        counts["bridging_excluded"] += bridging
        counts["subsequent_bcma_excluded"] += subsequent
        counts["treatment_eligible_with_unavailable_canonical_status"] += eligible and canonical is None
        counts["primary_comparative_population"] += eligible and canonical is not None
        counts["primary_comparative_controls"] += eligible and canonical is False
        partition = (
            COHORT_PARTITIONS[0] if eligible and canonical is not None
            else COHORT_PARTITIONS[1] if eligible
            else COHORT_PARTITIONS[2] if bridging
            else COHORT_PARTITIONS[3]
        )
        candidate = original is True or canonical is True
        review_destination = REVIEW_SUBSET if candidate else OTHER_COURSES
        full_cohort_links[(TOTAL_COHORT, partition)] += 1
        full_cohort_links[(partition, review_destination)] += 1
        cohort_matrix[(partition, review_destination)] += 1

        if canonical is True:
            outcome = SECONDARY
        elif original is True and canonical is False:
            outcome = REMOVED
        elif original is None and canonical is False:
            outcome = "Status updated after documented secondary site review"
        elif canonical is None:
            outcome = "Canonical suspicion status unavailable"
        else:
            outcome = "No additional suspected-case EDC return in this reconciliation"
        cell = transitions[(state(original), state(canonical), outcome)]
        cell["n"] += 1
        cell["returned_suspected_edc_n"] += received
        cell["documented_removal_n"] += original is True and canonical is False and row["documented_negative"]
        cell["no_suspected_case_edc_return_n"] += not received
        cell["treatment_eligible_n"] += eligible
        cell["bridging_excluded_n"] += bridging
        cell["subsequent_bcma_excluded_n"] += subsequent

        if original is True:
            counts["preliminary_suspected"] += 1
            counts["targeted_candidate_courses"] += 1
            if canonical is True:
                counts["preliminary_suspected_retained"] += 1
                links[(PRELIMINARY, SECONDARY, "secondary_review")] += 1
            elif canonical is False and row["documented_negative"]:
                counts["removed_after_secondary_review"] += 1
                links[(PRELIMINARY, REMOVED, "secondary_review")] += 1
        elif canonical is True:
            counts["additional_suspected"] += 1
            counts["additional_from_preliminary_" + state(original).lower()] += 1
            counts["targeted_candidate_courses"] += 1
            links[(ADDITIONAL, SECONDARY, "secondary_review")] += 1
        if canonical is True:
            counts["returned_suspected_edc"] += 1
            destination = DISPOSITIONS[0] if eligible else (DISPOSITIONS[1] if bridging else DISPOSITIONS[2])
            confidence = row["confidence"]
            if confidence is not None:
                links[(SECONDARY, confidence, "confidence")] += 1
                links[(confidence, destination, "disposition")] += 1
                confidence_disposition[(confidence, destination)] += 1
                counts["confidence_" + confidence.lower()] += 1
                counts["strict_clinical_suspected"] += confidence in CONFIDENCE[:2]
                counts["strict_comparative_suspected"] += eligible and confidence in CONFIDENCE[:2]
            counts["primary_comparative_suspected"] += eligible
            counts["clinical_bridging_excluded"] += bridging
            counts["clinical_subsequent_bcma_excluded"] += subsequent
    if unresolved:
        error = ExtractionError("unresolved_source_validation", sum(unresolved.values()))
        error.issues = dict(sorted(unresolved.items()))
        raise error

    require(counts["preliminary_suspected"] == counts["preliminary_suspected_retained"] + counts["removed_after_secondary_review"], "preliminary_suspected_courses_not_conserved")
    require(counts["returned_suspected_edc"] == counts["preliminary_suspected_retained"] + counts["additional_suspected"], "returned_suspected_courses_not_conserved")
    require(counts["targeted_candidate_courses"] == counts["returned_suspected_edc"] + counts["removed_after_secondary_review"], "targeted_candidates_not_conserved")
    require(counts["primary_comparative_population"] == counts["primary_comparative_suspected"] + counts["primary_comparative_controls"], "comparative_population_not_conserved")
    require(counts["courses_total"] == counts["treatment_eligible"] + counts["bridging_excluded"] + counts["subsequent_bcma_excluded"], "treatment_eligibility_universe_not_conserved")
    require(sum(cohort_matrix[(partition, REVIEW_SUBSET)] for partition in COHORT_PARTITIONS) == counts["targeted_candidate_courses"], "full_cohort_review_subset_not_conserved")
    require(sum(cohort_matrix.values()) == counts["courses_total"], "full_cohort_matrix_not_conserved")

    transition_rows = [
        {"original_state": key[0], "canonical_state": key[1], "reconciliation_outcome": key[2], **dict(cell)}
        for key, cell in sorted(transitions.items(), key=lambda item: (STATE_ORDER[item[0][0]], STATE_ORDER[item[0][1]], item[0][2]))
    ]
    source_order = {name: index for index, name in enumerate((PRELIMINARY, ADDITIONAL, SECONDARY, *CONFIDENCE))}
    target_order = {name: index for index, name in enumerate((SECONDARY, REMOVED, *CONFIDENCE, *DISPOSITIONS))}
    link_rows = [
        {"source": source, "target": target, "n": n, "link_type": kind}
        for (source, target, kind), n in sorted(links.items(), key=lambda item: (source_order[item[0][0]], target_order[item[0][1]]))
    ]
    disposition_rows = [
        {"confidence": confidence, "disposition": destination, "n": confidence_disposition[(confidence, destination)]}
        for confidence in CONFIDENCE for destination in DISPOSITIONS
    ]
    full_cohort_rows = [
        {"source": source, "target": target, "n": full_cohort_links[(source, target)]}
        for source, target in (
            *((TOTAL_COHORT, partition) for partition in COHORT_PARTITIONS),
            *((partition, destination) for partition in COHORT_PARTITIONS for destination in (REVIEW_SUBSET, OTHER_COURSES)),
        )
        if full_cohort_links[(source, target)]
    ]
    cohort_matrix_rows = [
        {"cohort_partition": partition, "review_destination": destination, "n": cohort_matrix[(partition, destination)]}
        for partition in COHORT_PARTITIONS for destination in (REVIEW_SUBSET, OTHER_COURSES)
    ]
    return transition_rows, link_rows, disposition_rows, full_cohort_rows, cohort_matrix_rows, dict(sorted(counts.items())), evidence_summary


def write_csv(path, rows, fields):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--canonical", type=Path, required=True, help="Canonical course-record CSV; read only")
    parser.add_argument("--corrections", type=Path, required=True, help="Verified corrections or final reconciliation-register CSV; read only")
    parser.add_argument("--evidence-schema", choices=("auto", "corrections", "register"), default="auto")
    parser.add_argument("--output-dir", type=Path, required=True, help="New aggregate-output directory")
    args = parser.parse_args(argv)
    require(args.canonical.is_file() and args.corrections.is_file(), "missing_input_file")
    protected = {args.canonical.resolve(), args.corrections.resolve()}
    output_names = (
        "ascertainment_transitions.csv", "targeted_reconciliation_links.csv",
        "confidence_disposition_counts.csv", "ascertainment_counts.csv",
        "Figure_1_Initial_Review_Links.csv", "Figure_1B_Disposition_Links.csv",
        "Figure_1_Full_Cohort_Links.csv", "full_cohort_review_matrix.csv",
        "ascertainment_validation.json",
    )
    require(all((args.output_dir / name).resolve() not in protected for name in output_names), "output_would_overwrite_input")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    report = {
        "status": "FAIL",
        "input_sha256": {"canonical": sha256(args.canonical), "site_evidence": sha256(args.corrections)},
        "aggregate_only": True,
        "source_files_modified": False,
    }
    try:
        transitions, links, dispositions, full_cohort_links, cohort_matrix, counts, evidence_summary = build_aggregates(args.canonical, args.corrections, args.evidence_schema)
        write_csv(args.output_dir / output_names[0], transitions, (
            "original_state", "canonical_state", "reconciliation_outcome", "n",
            "returned_suspected_edc_n", "documented_removal_n", "no_suspected_case_edc_return_n",
            "treatment_eligible_n", "bridging_excluded_n", "subsequent_bcma_excluded_n",
        ))
        write_csv(args.output_dir / output_names[1], links, ("source", "target", "n", "link_type"))
        write_csv(args.output_dir / output_names[2], dispositions, ("confidence", "disposition", "n"))
        write_csv(args.output_dir / output_names[3], [{"metric": key, "n": value} for key, value in counts.items()], ("metric", "n"))
        renderer_fields = ("source", "target", "n")
        renderer_rows = lambda subset: [{field: row[field] for field in renderer_fields} for row in subset]
        write_csv(args.output_dir / output_names[4], renderer_rows([row for row in links if row["link_type"] == "secondary_review"]), renderer_fields)
        write_csv(args.output_dir / output_names[5], renderer_rows([row for row in links if row["link_type"] != "secondary_review"]), renderer_fields)
        write_csv(args.output_dir / output_names[6], full_cohort_links, renderer_fields)
        write_csv(args.output_dir / output_names[7], cohort_matrix, ("cohort_partition", "review_destination", "n"))
        full_cohort_counts = {
            "source_courses": counts["courses_total"],
            "case_review_subset": sum(row["n"] for row in cohort_matrix if row["review_destination"] == REVIEW_SUBSET),
            "other_source_courses": sum(row["n"] for row in cohort_matrix if row["review_destination"] == OTHER_COURSES),
        }
        report.update({
            "status": "PASS", "counts": counts, "site_evidence": evidence_summary,
            "full_cohort": {"counts": full_cohort_counts, "partitions_and_review_subset_conserve_courses": True},
            "checks": {
                "preliminary_suspected_courses_have_return_or_documented_removal": True,
                "additional_suspected_courses_have_returned_edc": True,
                "unavailable_preliminary_states_preserved_or_authoritatively_updated": True,
                "no_return_is_not_interpreted_as_negative_site_adjudication": True,
                "confidence_uses_finite_investigator_assessment_categories": True,
                "treatment_exclusions_exclusive_and_complete": True,
                "targeted_and_comparative_counts_conserve_courses": True,
                "full_cohort_partitions_and_review_subset_conserve_courses": True,
            },
            "interpretation": [
                "EDC receipt denotes membership in the returned suspected-case row set.",
                "Removal is supported by an explicit final site correction with a documentary pointer; it does not imply a returned negative EDC.",
                "No suspected-case EDC return does not establish the extent of secondary site review or diagnostic exclusion.",
                "Confidence is investigator assessment and is not a validated adjudication.",
                "The targeted candidate set overlaps the full course universe and must not be drawn as a second disjoint branch from that universe.",
            ],
            "output_sha256": {name: sha256(args.output_dir / name) for name in output_names[:-1]},
        })
    except ExtractionError as error:
        report["error_code"] = error.code
        report["error_count"] = error.count
        if hasattr(error, "issues"):
            report["issues"] = error.issues
    (args.output_dir / output_names[-1]).write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": report["status"], "aggregate_counts": report.get("counts", {}), "error_code": report.get("error_code"), "error_count": report.get("error_count")}, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    try:
        sys.exit(main())
    except ExtractionError as error:
        print(json.dumps({"status": "FAIL", "error_code": error.code, "error_count": error.count}), file=sys.stderr)
        sys.exit(1)
