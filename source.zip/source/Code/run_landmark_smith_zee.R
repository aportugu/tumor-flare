#!/usr/bin/env Rscript
# Usage: Rscript Code/run_landmark_smith_zee.R CONTROLLED_DATA FROZEN_AGGREGATES OUTPUT
# Keep the private landmark verification JSON outside publication directories.
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 3L) stop("Expected controlled data, frozen aggregate, and output directories")
data_dir <- normalizePath(args[1L], mustWork = TRUE)
frozen <- normalizePath(args[2L], mustWork = TRUE)
output <- args[3L]
script <- grep("^--file=", commandArgs(), value = TRUE)
code <- dirname(normalizePath(sub("^--file=", "", script[1L]), mustWork = TRUE))
for (file in c("analysis_functions.R", "survival_functions.R", "reconciliation_functions.R",
               "model_functions.R", "landmark_smith_zee.R")) source(file.path(code, file))
read_controlled <- function(name) tf_read_controlled_csv(file.path(data_dir, name))
read_csv <- function(name, dir = frozen) utils::read.csv(file.path(dir, name), check.names = FALSE, na.strings = "")
master_source <- file.path(data_dir, "master_source_records.csv")
analysis <- tf_reconcile(read_controlled("master_courses.csv"), read_controlled("edc_cases.csv"),
                         read_csv("verified_corrections.csv", data_dir),
                         if (file.exists(master_source)) read_csv(basename(master_source), data_dir) else NULL)
scenario_path <- file.path(data_dir, "survival_scenario_rules.csv")
if (file.exists(scenario_path)) analysis$survival_scenario_rules <- read_csv(basename(scenario_path), data_dir)
analysis$excluded_site_keys <- names(sort(table(analysis$cases$site_key), decreasing = TRUE))[1L]
cohort <- analysis$cohorts$primary
covariates <- tf_ash_covariates
model_data <- tf_ash_model_data(cohort)[c("course_id", covariates)]
input <- cohort[c("course_id", "patient_cluster_id", "start_date", "pd_date", "death_date",
                  "last_contact_date", "analysis_flare", "onset_date")]
exclude <- cohort$course_id[cohort$pfs_excluded]
models <- read_csv("survival_models.csv")
landmark_frozen_path <- file.path(frozen, "Table_S4_Landmark_Models.csv")
landmark_frozen <- if (file.exists(landmark_frozen_path)) read_csv(basename(landmark_frozen_path)) else NULL
validate <- function(actual, expected, fields) {
  stopifnot(nrow(actual) == 1L, nrow(expected) == 1L)
  for (field in fields) if (!isTRUE(all.equal(actual[[field]], expected[[field]], tolerance = 1e-10))) {
    stop("Frozen-result parity failed for ", field)
  }
}
counts <- c("n_courses", "n_patient_clusters", "exposed_courses", "exposed_events", "events")
inference <- c("estimate", "conf_low", "conf_high", "p_value")
comparison <- tf_ash_survival(analysis, list(primary = cohort, strict = analysis$cohorts$strict,
  without_dominant_site = cohort[!cohort$site_key %in% analysis$excluded_site_keys, ]), NULL)$table
for (i in seq_len(nrow(models))) {
  row <- models[i, ]
  if (row$scenario == "original_master_endpoints") next
  validate(comparison[comparison$scenario == row$scenario & comparison$endpoint == row$endpoint &
                        comparison$model == row$model, ], row, c(counts, inference, "excluded_missing"))
}
endpoints <- c("PFS", "OS")
fits <- setNames(vector("list", 2L), endpoints)
landmarks <- list()
audit <- setNames(vector("list", 2L), endpoints)
months <- c(3, 6, 9, 12)
support <- matrix(NA_integer_, 2L, length(months), dimnames = list(endpoints, as.character(months)))
for (endpoint in endpoints) {
  current <- edc_time_dependent_cox(input, endpoint, exclude)
  intervals <- merge(current$intervals, model_data, by = "course_id", sort = FALSE)
  adjusted <- tf_ash_fit_cox(intervals, covariates, "primary", "Adjusted: six baseline variables",
                             length(unique(intervals$course_id)))
  expected <- models[models$endpoint == endpoint & models$scenario == "primary" &
                       startsWith(models$model, "Adjusted"), ]
  validate(adjusted$table, expected, c(counts, inference, "excluded_missing"))
  complete <- intervals[stats::complete.cases(intervals[covariates]), ]
  profiles <- complete[!duplicated(complete$course_id), covariates, drop = FALSE]
  stopifnot(nrow(profiles) == adjusted$table$n_courses)
  fits[[endpoint]] <- adjusted$fit
  support[endpoint, ] <- vapply(months * 30.4375, function(day) {
    length(unique(complete$course_id[complete$flare_td == 1L & complete$tstart < day & complete$tstop >= day]))
  }, integer(1))
  for (landmark in edc_landmark_analysis(input, endpoint, pfs_exclude_course_ids = exclude)$results) {
    day <- landmark$table$landmark_day
    if (!is.null(landmark_frozen)) {
      expected <- landmark_frozen[landmark_frozen$endpoint == endpoint & landmark_frozen$landmark_day == day, ]
      validate(landmark$table, expected, counts)
      hr <- with(landmark$table, sprintf("%.2f (%.2f–%.2f)", estimate, conf_low, conf_high))
      stopifnot(hr == expected$hr_95ci, round(landmark$table$p_value, 4L) == expected$p_value)
    }
    eligible <- merge(landmark$data, model_data, by = "course_id", sort = FALSE)
    result <- tf_adjust_landmark(eligible, covariates, endpoint, day)
    landmarks[[length(landmarks) + 1L]] <- result$table
    audit[[endpoint]][[paste0("day", day)]] <- result$audit
  }
}
dir.create(output, recursive = TRUE, showWarnings = FALSE)
write_csv <- function(x, name) utils::write.csv(x, file.path(output, name), row.names = FALSE, na = "")
write_csv(do.call(rbind, landmarks), "Adjusted_Landmark_Models.csv")
jsonlite::write_json(list(frozen_time_dependent_parity = TRUE, frozen_landmark_parity = !is.null(landmark_frozen),
                          support = lapply(endpoints, function(e) as.list(support[e, ])) |> setNames(endpoints),
                          landmarks = audit), file.path(output, "private_landmark_verification.json"),
                     dataframe = "rows", auto_unbox = TRUE, pretty = TRUE, na = "null", digits = 15)
valid_months <- months[apply(support >= 5L, 2L, all)]
if (!length(valid_months)) stop("Observed exposed risk sets do not support an approved common horizon")
horizon <- max(valid_months) * 30.4375
stopifnot(read_csv("Figure_2_Timing_Summaries.csv")$median[1L] == 4)
weekly_days <- seq(0, horizon, by = 7)
# Report on a uniform two-day grid with the existing weekly checkpoints.
# Exact event-time curve coordinates stay in the controlled analysis.
days <- sort(unique(c(seq(0, horizon, by = 2), weekly_days, 4, horizon)))
# Fixed baseline profile in clinically interpretable units. This same profile is
# used for both endpoints and both exposure histories.
profile <- data.frame(age10 = 6.9, ecog2 = 0L, female = 0L, prior_lines = 6L, hrca = 1L, true_emd = 0L)
predictions <- lapply(endpoints, function(endpoint) {
  fit <- fits[[endpoint]]
  stopifnot(!is.null(fit$naive.var))  # Patient-cluster robust fit.
  predicted <- tf_smith_zee_curves(fit, profile, days)
  fields <- c("survival", "lower95", "upper95")
  before <- predicted[predicted$day <= 4 & predicted$history == "no_flare", fields]
  switched <- predicted[predicted$day <= 4 & predicted$history == "flare_day_4", fields]
  stopifnot(all(as.matrix(before) == as.matrix(switched)), all(predicted$survival[predicted$day == 0] == 1),
            all(with(predicted, 0 <= lower95 & lower95 <= survival & survival <= upper95 & upper95 <= 1)),
            all(vapply(split(predicted$survival, predicted$history), function(x) all(diff(x) <= 0), TRUE)))
  data.frame(endpoint, predicted)
})
write_csv(do.call(rbind, predictions), "Figure_S1_Smith_Zee_Predictions.csv")
jsonlite::write_json(list(switch_day = 4, display_months = max(valid_months), days_per_month = 30.4375,
  time_grid = "Two-day display grid plus weekly checkpoints",
  method = "survival::survfit.coxph", confidence_level = .95, confidence_type = "log",
  baseline_profile = as.list(profile), R = as.character(getRversion()),
  survival = as.character(utils::packageVersion("survival"))),
  file.path(output, "Figure_S1_Methods.json"), auto_unbox = TRUE, pretty = TRUE)
