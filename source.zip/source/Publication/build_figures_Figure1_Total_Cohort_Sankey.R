#!/usr/bin/env Rscript
# Publication figures from the canonical, reconciled tumor-flare analysis.
# This file uses relative paths and contains no patient identifiers or dates.
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
})
args <- commandArgs(trailingOnly = TRUE)
renderer_path <- sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1])
renderer_path <- gsub("~+~", " ", renderer_path, fixed = TRUE)
source(file.path(dirname(normalizePath(renderer_path)), "calculate_flare_frequency.R"))
input_dir <- if (length(args) >= 1L) args[1] else "analysis"
output_dir <- if (length(args) >= 2L) args[2] else "publication"
framework_only <- "--framework-only" %in% args
figure1_only <- "--figure1-only" %in% args
dir.create(file.path(output_dir, "Figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Display_data"), recursive = TRUE, showWarnings = FALSE)
font_family <- "Helvetica"
# Text remains >= 8 pt when the 10-inch figure is placed at 6.5 inches.
figure1_text <- c(major = 4.85, detail = 4.35)
colours <- c("Yes" = "#1B5678", "No" = "#D6DCE0", "Unknown" = "#BB9153", "Not applicable" = "#A9A6B8")
theme_paper <- function(size = 10) {
  theme_classic(base_size = size, base_family = font_family) +
    theme(plot.title = element_text(face = "bold", size = size + 1, hjust = 0),
          plot.subtitle = element_text(size = size - 1, lineheight = 1.1),
          axis.title = element_text(size = size), axis.text = element_text(colour = "#222222"),
          legend.position = "bottom", legend.title = element_blank(),
          plot.margin = margin(8, 10, 8, 8))
}
read_input <- function(name, required = character()) {
  path <- file.path(input_dir, paste0(name, ".csv"))
  if (!file.exists(path)) stop("Missing canonical output: ", path)
  x <- read_csv(path, show_col_types = FALSE, progress = FALSE)
  x <- x %>% mutate(across(where(is.character), ~gsub("\u2265", ">=", gsub("\u2013|\u2014|\u2212", "-", .x))))
  missing <- setdiff(required, names(x))
  if (length(missing)) stop(name, " lacks required columns: ", paste(missing, collapse = ", "))

  x
}
save_display_data <- function(x, name) {
  stopifnot(!any(grepl("(^|_)(course_id|patient_id|mrn|source_reference|narrative|calendar_date|start_date)$", names(x))))
  write_csv(x, file.path(output_dir, "Display_data", paste0(name, ".csv")), na = "")
}
# Use a font-embedding PDF device on each platform.
embedded_pdf <- function(filename, width, height, family, bg, ...) {
  if (Sys.info()[["sysname"]] == "Darwin") {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = family, bg = bg)
  } else {
    grDevices::cairo_pdf(filename = filename, width = width,
                        height = height, family = family, bg = bg)
  }
}
save_figure <- function(p, name, width, height) {
  pdf_path <- file.path(output_dir, "Figures", paste0(name, ".pdf"))
  png_path <- file.path(output_dir, "Figures", paste0(name, ".png"))
  ggsave(pdf_path, p, device = embedded_pdf, width = width, height = height,
         units = "in", family = font_family, bg = "white")
  ggsave(png_path, p, device = ragg::agg_png, width = width, height = height,
         units = "in", dpi = 320, bg = "white")
}
panel_title <- function(letter, title) paste0(letter, "  ", title)
box_layer <- function(x, y, w, h, label, fill = "#EEF2F4", size = 3.4) {
  list(annotate("rect", xmin = x - w/2, xmax = x + w/2, ymin = y - h/2,
                ymax = y + h/2, fill = fill, colour = "#34424B", linewidth = 0.45),
       annotate("text", x = x, y = y, label = label, family = font_family,
                size = size, lineheight = 1.1))
}
arrow_layer <- function(x, y, xend, yend, colour = "#34424B") {
  annotate("segment", x = x, y = y, xend = xend, yend = yend, colour = colour,
           linewidth = .55, arrow = grid::arrow(length = grid::unit(2.5, "mm")))
}

confidence_levels <- c("Definite", "Probable", "Possible")
disposition_levels <- c("Primary comparative flare courses", "Bridging excluded",
                        "Subsequent BCMA-directed BsAb course excluded")
reviewed_label <- "Tumor flare after secondary review"
confidence_colours <- c(Definite = "#1B5678", Probable = "#5B8C85", Possible = "#BB9153")
validate_disposition_links <- function(links, stage_count) {
  if (!all(c("source", "target", "n") %in% names(links)) ||
      anyDuplicated(paste(links$source, links$target)) ||
      any(!is.finite(links$n) | links$n <= 0 | links$n != round(links$n))) stop("Invalid disposition links")
  start <- links %>% filter(source == reviewed_label)
  end <- links %>% filter(source %in% confidence_levels)
  if (!setequal(start$target, confidence_levels) || !all(end$target %in% disposition_levels) ||
      nrow(start) + nrow(end) != nrow(links)) stop("Unexpected Sankey node")
  if (sum(start$n) != stage_count("Clinical series after secondary review") || sum(end$n) != sum(start$n)) stop("Sankey total does not conserve courses")
  for (level in confidence_levels) {
    if (sum(start$n[start$target == level]) != sum(end$n[end$source == level])) stop("Confidence flow does not conserve courses")
  }
  expected <- c(stage_count("Comparative flare courses"), stage_count("Clinical bridging cases"), stage_count("Clinical later BCMA cases"))
  if (!identical(as.numeric(vapply(disposition_levels, function(k) sum(end$n[end$target == k]), numeric(1))), as.numeric(expected))) stop("Disposition totals conflict with canonical flow")
  strict <- sum(end$n[end$source %in% c("Definite", "Probable") & end$target == disposition_levels[1]])
  if (strict != stage_count("Definite/Probable-only flare")) stop("Strict eligible count conflicts with canonical flow")
  links
}
# Review pathways use aggregate counts from the completed clinical review.
initial_labels <- c("Candidates after preliminary review", "Additional cases identified during secondary review")
withdrawn_label <- "Withdrawn from secondary review"
validate_initial_links <- function(links, disposition_links) {
  if (!all(c("source", "target", "n") %in% names(links)) ||
      anyDuplicated(paste(links$source, links$target)) ||
      any(!is.finite(links$n) | links$n <= 0 | links$n != round(links$n))) stop("Invalid initial-review links")
  if (!all(links$source %in% initial_labels) || !all(links$target %in% c(reviewed_label, withdrawn_label))) stop("Unexpected initial-review node")
  if (any(links$source == initial_labels[2] & links$target == withdrawn_label)) stop("Additional courses cannot be removed preliminary candidates")
  if (sum(links$n[links$target == reviewed_label]) != sum(disposition_links$n[disposition_links$source == reviewed_label])) stop("Initial review and clinical-series counts disagree")
  links
}

merged_case_sankey <- function(initial_links, disposition_links) {
  links <- bind_rows(initial_links, disposition_links)
  total <- sum(initial_links$n)
  unit_width <- 7.4 / total
  count_source <- function(k) sum(links$n[links$source == k])
  count_target <- function(k) sum(links$n[links$target == k])
  make_nodes <- function(labels, counts, y, stage, height = .16) {
    widths <- counts * unit_width
    gap <- .13
    left <- 4.85 - (sum(widths) + gap * (length(labels) - 1)) / 2
    xmin <- left + c(0, head(cumsum(widths + gap), -1))
    tibble(node = labels, stage = stage, n = counts, xmin = xmin,
      xmax = xmin + widths, ymin = y - height/2, ymax = y + height/2,
      x = xmin + widths/2, y = y)
  }
  nodes <- bind_rows(
    make_nodes(initial_labels, vapply(initial_labels, count_source, numeric(1)), 8.4, 1),
    make_nodes(c(reviewed_label, withdrawn_label), vapply(c(reviewed_label, withdrawn_label), count_target, numeric(1)), 6.85, 2),
    make_nodes(confidence_levels, vapply(confidence_levels, count_target, numeric(1)), 4.95, 3, .85),
    make_nodes(disposition_levels, vapply(disposition_levels, count_target, numeric(1)), 2.68, 4))
  offsets_out <- offsets_in <- setNames(rep(0, nrow(nodes)), nodes$node)
  polygons <- geometry <- list()
  for (i in seq_len(nrow(links))) {
    link <- links[i, ]
    src <- nodes[nodes$node == link$source, ]
    dst <- nodes[nodes$node == link$target, ]
    width <- link$n * unit_width
    x0 <- src$xmin + offsets_out[[link$source]]
    x1 <- dst$xmin + offsets_in[[link$target]]
    offsets_out[[link$source]] <- offsets_out[[link$source]] + width
    offsets_in[[link$target]] <- offsets_in[[link$target]] + width
    t <- seq(0, 1, length.out = 81)
    smooth <- 3*t^2 - 2*t^3
    left <- x0 + (x1 - x0)*smooth
    y <- src$ymin + (dst$ymax - src$ymin)*t
    category <- if (link$source %in% initial_labels) {
      if (link$target == withdrawn_label) "Withdrawn" else "Initial review"
    } else if (link$source == reviewed_label) link$target else link$source
    polygons[[i]] <- tibble(link_index = i, x = c(left, rev(left + width)),
      y = c(y, rev(y)), category = category, n = link$n)
    geometry[[i]] <- tibble(source = link$source, target = link$target, n = link$n,
      source_left = x0, source_right = x0 + width, target_left = x1,
      target_right = x1 + width, source_y = src$ymin, target_y = dst$ymax,
      unit_width = unit_width)
  }
  geometry <- bind_rows(geometry)
  stopifnot(all(abs((nodes$xmax - nodes$xmin)/unit_width - nodes$n) < 1e-10),
    all(abs((geometry$source_right - geometry$source_left)/unit_width - geometry$n) < 1e-10),
    all(abs((geometry$target_right - geometry$target_left)/unit_width - geometry$n) < 1e-10))
  for (node in nodes$node) {
    z <- nodes[nodes$node == node, ]
    if (node %in% links$source) stopifnot(abs(sum(links$n[links$source == node]) - z$n) < 1e-10)
    if (node %in% links$target) stopifnot(abs(sum(links$n[links$target == node]) - z$n) < 1e-10)
  }
  save_display_data(links, "Figure_1_Review_Links")
  save_display_data(nodes %>% select(node, stage, n, xmin, xmax, ymin, ymax), "Figure_1_Review_Node_Geometry")
  save_display_data(geometry, "Figure_1_Review_Link_Geometry")
  p <- ggplot() +
    geom_polygon(data = bind_rows(polygons) %>% arrange(desc(n), link_index),
      aes(x, y, group = link_index, fill = category), alpha = .66, colour = "white", linewidth = .15) +
    scale_fill_manual(values = c(confidence_colours, "Initial review" = "#8E9EAB", Withdrawn = "#B68F88"), guide = "none") +
    geom_rect(data = nodes, aes(xmin = xmin, xmax = xmax, ymin = ymin, ymax = ymax),
      fill = "white", colour = "#34424B", linewidth = .45)
  mid <- nodes %>% filter(stage == 3)
  p <- p + geom_text(data = mid, aes(x, y, label = paste0(node, "\n", n)),
    family = font_family, size = figure1_text[["major"]], lineheight = 1.08)
  source <- nodes %>% filter(stage == 1)
  review <- nodes %>% filter(stage == 2)
  terminals <- nodes %>% filter(stage == 4)
  p <- p +
    annotate("text", x = source$x[1], y = 8.91, label = paste0("Candidates after preliminary review\n", source$n[1]), family = font_family, size = figure1_text[["major"]], lineheight = 1.08) +
    annotate("text", x = source$x[2], y = 9.11, label = paste0("Added during\nsecondary review\n", source$n[2]), hjust = .5, family = font_family, size = figure1_text[["detail"]], lineheight = 1.08) +
    annotate("text", x = review$x[1], y = 7.38, label = paste0("Tumor flare after secondary review\n", review$n[1]), family = font_family, size = figure1_text[["major"]], lineheight = 1.08) +
    annotate("segment", x = review$x[2], xend = 9.12, y = review$ymin[2] - .03, yend = 6.82, colour = "#34424B", linewidth = .35) +
    annotate("text", x = 9.25, y = 6.12, label = paste0("Withdrawn from\nreview\n", review$n[2]), family = font_family, size = figure1_text[["detail"]], lineheight = 1.08) +
    annotate("text", x = terminals$x[1], y = 1.93, label = paste0("Primary comparative\nflare courses\n", terminals$n[1]), family = font_family, size = figure1_text[["major"]], lineheight = 1.08) +
    annotate("text", x = terminals$x[2], y = 1.96, label = paste0("Bridging\nexcluded\n", terminals$n[2]), family = font_family, size = figure1_text[["major"]], lineheight = 1.08) +
    annotate("segment", x = terminals$x[3], xend = 9.13, y = terminals$ymin[3] - .03, yend = 1.72, colour = "#34424B", linewidth = .35) +
    annotate("text", x = 9.0, y = 1.04, label = paste0("Later BCMA course\nexcluded\n", terminals$n[3]), family = font_family, size = figure1_text[["detail"]], lineheight = 1.08)
  band_labels <- geometry %>% filter(source %in% initial_labels | source %in% confidence_levels) %>%
    mutate(t = ifelse(source %in% initial_labels, .16, .12),
      x = (source_left + source_right)/2 + ((target_left + target_right - source_left - source_right)/2)*(3*t^2 - 2*t^3),
      y = source_y + (target_y - source_y)*t)
  p <- p + geom_text(data = band_labels, aes(x, y, label = n), family = font_family, size = figure1_text[["detail"]], colour = "#172129")
  list(plot = p, nodes = nodes, geometry = geometry)
}

flow <- read_input("flow", c("stage", "courses"))
count_stage <- function(stage) {
  value <- flow$courses[flow$stage == stage]
  if (length(value) != 1L) stop("Missing or duplicated cohort stage: ", stage)
  value
}
overall_frequency <- read_input("Flare_Frequency_Total_Cohort", c("population", "flare_cases", "total_courses", "percent", "lower_95_percent", "upper_95_percent", "ci_method"))
calculated_frequency <- frequency_from_flow(as.data.frame(flow))
if (nrow(overall_frequency) != 1L ||
    !identical(overall_frequency$population, calculated_frequency$population) ||
    !identical(overall_frequency$ci_method, calculated_frequency$ci_method) ||
    !isTRUE(all.equal(as.numeric(overall_frequency[1, 2:6]), as.numeric(calculated_frequency[1, 2:6]), tolerance = 1e-12))) {
  stop("Registered overall flare frequency conflicts with cohort-flow counts or exact binomial calculation")
}
disposition_links <- validate_disposition_links(read_input("Figure_1B_Disposition_Links", c("source", "target", "n")), count_stage)
initial_links <- validate_initial_links(read_input("Figure_1_Initial_Review_Links", c("source", "target", "n")), disposition_links)
sankey <- merged_case_sankey(initial_links, disposition_links)
unknown <- count_stage("Excluded: flare status unavailable")
later <- count_stage("Included bispecific antibodies") - count_stage("First eligible BCMA / all GPRC5D courses")
bridging <- count_stage("First eligible BCMA / all GPRC5D courses") - count_stage("Nonbridging eligible courses")
source_label <- "Total cohort"
cohort_categories <- c("Comparative analytic set", "Unavailable flare status", "Bridging excluded", "Subsequent BCMA-directed course excluded")
cohort_terminals <- c("Other courses", "Case-review subset")
validate_full_links <- function(links, review_links, count_stage) {
  if (!all(c("source", "target", "n") %in% names(links)) || anyDuplicated(paste(links$source, links$target)) ||
      any(!is.finite(links$n) | links$n <= 0 | links$n != round(links$n))) stop("Invalid full-cohort links")
  a <- links %>% filter(source == source_label)
  b <- links %>% filter(source %in% cohort_categories)
  if (nrow(a) + nrow(b) != nrow(links) || !setequal(a$target, cohort_categories) || !all(b$target %in% cohort_terminals)) stop("Unexpected full-cohort stage")
  if (sum(a$n) != count_stage("Total cohort") || sum(b$n) != sum(a$n)) stop("Total cohort is not conserved")
  expected <- c(count_stage("Primary known-status courses"), count_stage("Excluded: flare status unavailable"),
    count_stage("First eligible BCMA / all GPRC5D courses") - count_stage("Nonbridging eligible courses"),
    count_stage("Included bispecific antibodies") - count_stage("First eligible BCMA / all GPRC5D courses"))
  if (!identical(as.numeric(vapply(cohort_categories, function(k) sum(a$n[a$target == k]), numeric(1))), as.numeric(expected))) stop("Cohort strata differ from canonical selection")
  for (k in cohort_categories) if (sum(a$n[a$target == k]) != sum(b$n[b$source == k])) stop("Cohort stratum is not conserved")
  if (sum(b$n[b$target == cohort_terminals[2]]) != sum(review_links$n)) stop("Expanded review subset differs from full-cohort flow")
  links %>% arrange(match(source, c(source_label, cohort_categories)),
                    match(target, c(cohort_categories, cohort_terminals)))
}
full_cohort_sankey <- function(links) {
  total <- sum(links$n[links$source == source_label])
  unit_width <- 7.4 / total
  make_nodes <- function(labels, counts, y, stage, height = .16) {
    widths <- counts*unit_width
    gap <- .13
    left <- 4.85 - (sum(widths) + gap*(length(labels) - 1))/2
    xmin <- left + c(0, head(cumsum(widths + gap), -1))
    tibble(node = labels, stage = stage, n = counts, xmin = xmin, xmax = xmin + widths,
      ymin = y - height/2, ymax = y + height/2, x = xmin + widths/2, y = y)
  }
  count_target <- function(k) sum(links$n[links$target == k])
  nodes <- bind_rows(make_nodes(source_label, total, 13.3, 1),
    make_nodes(cohort_categories, vapply(cohort_categories, count_target, numeric(1)), 11.7, 2, 1.05),
    make_nodes(cohort_terminals, vapply(cohort_terminals, count_target, numeric(1)), 10.2, 3))
  offsets_in <- offsets_out <- setNames(rep(0, nrow(nodes)), nodes$node)
  polygons <- geometry <- list()
  for (i in seq_len(nrow(links))) {
    z <- links[i, ];src <- nodes[nodes$node == z$source, ];dst <- nodes[nodes$node == z$target, ]
    width <- z$n*unit_width
    x0 <- src$xmin + offsets_out[[z$source]];x1 <- dst$xmin + offsets_in[[z$target]]
    offsets_out[[z$source]] <- offsets_out[[z$source]] + width
    offsets_in[[z$target]] <- offsets_in[[z$target]] + width
    t <- seq(0,1,length.out = 81);smooth <- 3*t^2 - 2*t^3
    x <- x0 + (x1-x0)*smooth;y <- src$ymin + (dst$ymax-src$ymin)*t
    kind <- if (z$source == source_label) "Source" else if (z$target == cohort_terminals[2]) "Review" else "Other"
    polygons[[i]] <- tibble(link_index=i,x=c(x,rev(x+width)),y=c(y,rev(y)),kind=kind,n=z$n)
    geometry[[i]] <- tibble(source=z$source,target=z$target,n=z$n,source_left=x0,source_right=x0+width,
      target_left=x1,target_right=x1+width,unit_width=unit_width)
  }
  geometry <- bind_rows(geometry)
  stopifnot(all(abs((nodes$xmax-nodes$xmin)/unit_width-nodes$n) < 1e-8),
    all(abs((geometry$source_right-geometry$source_left)/unit_width-geometry$n) < 1e-8),
    all(abs((geometry$target_right-geometry$target_left)/unit_width-geometry$n) < 1e-8))
  save_display_data(links,"Figure_1_Full_Cohort_Links")
  save_display_data(nodes %>% select(node,stage,n,xmin,xmax,ymin,ymax),"Figure_1_Full_Cohort_Node_Geometry")
  save_display_data(geometry,"Figure_1_Full_Cohort_Link_Geometry")
  list(nodes=nodes,ribbons=bind_rows(polygons) %>% arrange(desc(n),link_index),geometry=geometry)
}
full_links <- validate_full_links(read_input("Figure_1_Full_Cohort_Links",c("source","target","n")),initial_links,count_stage)
full <- full_cohort_sankey(full_links)
g <- full$nodes %>% filter(stage == 2)
t <- full$nodes %>% filter(stage == 3)
p <- sankey$plot +
  geom_polygon(data=full$ribbons %>% filter(kind=="Source"),aes(x,y,group=link_index),fill="#9DADB9",alpha=.7,colour="white",linewidth=.15) +
  geom_polygon(data=full$ribbons %>% filter(kind=="Other"),aes(x,y,group=link_index),fill="#C5CDD3",alpha=.7,colour="white",linewidth=.15) +
  geom_polygon(data=full$ribbons %>% filter(kind=="Review"),aes(x,y,group=link_index),fill="#647C8C",alpha=.8,colour="white",linewidth=.15) +
  geom_rect(data=full$nodes,aes(xmin=xmin,xmax=xmax,ymin=ymin,ymax=ymax),fill="white",colour="#34424B",linewidth=.45) +
  annotate("text",x=4.85,y=13.85,label=paste0("Total cohort\n",format(full$nodes$n[1],big.mark=",")),family=font_family,size=figure1_text[["major"]],lineheight=1.08) +
  annotate("text",x=g$x[1],y=g$y[1],label=paste0("Comparative analytic set\n",format(g$n[1],big.mark=",")),family=font_family,size=figure1_text[["major"]],lineheight=1.08) +
  annotate("text",x=g$x[2],y=g$y[2],label=paste0("Status\nunavailable\n",g$n[2]),family=font_family,size=figure1_text[["detail"]],lineheight=1.03) +
  annotate("text",x=g$x[3],y=g$y[3],label=paste0("Bridging\n",g$n[3]),family=font_family,size=figure1_text[["detail"]],lineheight=1.03) +
  annotate("segment",x=g$x[4],xend=8.95,y=g$y[4],yend=g$y[4],colour="#34424B",linewidth=.35) +
  annotate("text",x=9.56,y=11.7,label=paste0("Later BCMA\ncourses\n",g$n[4]),family=font_family,size=figure1_text[["detail"]],lineheight=1.03) +
  annotate("text",x=t$x[1],y=10.73,label=paste0("Other courses\n",format(t$n[1],big.mark=",")),family=font_family,size=figure1_text[["major"]],lineheight=1.08) +
  annotate("segment",x=t$x[2],xend=9.1,y=t$ymin[2]-.02,yend=10.65,colour="#34424B",linewidth=.35) +
  annotate("text",x=9.53,y=9.92,label=paste0("Case-review\nsubset\n",t$n[2]),family=font_family,size=figure1_text[["detail"]],lineheight=1.05) +
  annotate("segment",x=t$x[2],xend=4.85,y=t$ymin[2]-.02,yend=9.76,linetype="dotted",colour="#647C8C",linewidth=.45) +
  annotate("segment",x=4.85,xend=4.85,y=9.76,yend=9.67,linetype="dotted",colour="#647C8C",linewidth=.45) +
  annotate("segment",x=1.085,xend=8.615,y=9.67,yend=9.67,linetype="dotted",colour="#647C8C",linewidth=.45) +
  annotate("segment",x=1.085,xend=1.085,y=9.67,yend=9.57,linetype="dotted",colour="#647C8C",linewidth=.45) +
  annotate("segment",x=8.615,xend=8.615,y=9.67,yend=9.57,linetype="dotted",colour="#647C8C",linewidth=.45) +
  annotate("text",x=4.85,y=5.80,label="Investigator confidence",family=font_family,size=figure1_text[["major"]]) +
  coord_cartesian(xlim=c(.8,10.1),ylim=c(.45,14.15),expand=FALSE,clip="off") +
  theme_void(base_family=font_family) + theme(plot.margin=margin(8,12,4,10))
save_figure(p,"Figure_1_Total_Cohort_Sankey",10,7.8)
save_display_data(flow %>% mutate(stage = case_when(
  stage == "Total cohort" ~ "Total cohort",
  stage == "Included bispecific antibodies" ~ "Included bispecific antibodies",
  stage == "Comparative flare courses" ~ "Comparative flare courses",
  stage == "Primary comparison" ~ "Comparison courses without flare",
  stage == "Clinical series after secondary review" ~ "Clinical series after secondary review",
  stage == "Primary known-status courses" ~ "Comparative analytic set",
  stage == "Definite/Probable-only flare" ~ "Definite/Probable comparative flare courses",
  TRUE ~ stage)),"Figure_1_Assembly")
save_display_data(initial_links,"Figure_1_Initial_Review_Links")
save_display_data(disposition_links,"Figure_1B_Disposition_Links")
save_display_data(overall_frequency,"Figure_1_Proportions")
cat("Full-cohort and expanded case-review Sankeys built from registered aggregates.\n")
