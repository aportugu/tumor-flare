#!/usr/bin/env Rscript
# Three unadjusted Firth models with profile intervals and penalized LR tests.
# Restricted course records are required for fitting; presentation uses aggregates.
immune_model_input <- function(courses) {
  fields <- c('course_id', 'patient_cluster_id', 'comparative_eligible',
              'analysis_flare', 'crs_1', 'icans_1', 'toci_treatment')
  if (!all(fields %in% names(courses))) stop('Missing canonical immune model columns')
  d <- courses[courses$comparative_eligible %in% c(TRUE, 'TRUE', 1) &
               !is.na(courses$analysis_flare), fields, drop=FALSE]
  if (anyDuplicated(d$course_id) || anyNA(d$patient_cluster_id) || any(!nzchar(d$patient_cluster_id)))
    stop('Unique course IDs and documented patient clusters are required')
  d$flare <- as.integer(d$analysis_flare)
  for (field in c('flare','crs_1','icans_1','toci_treatment')) {
    if (any(!is.na(d[[field]]) & !d[[field]] %in% c(0,1))) stop('Outcome and flare fields must be binary')
  }
  if (anyNA(d$flare)) stop('Comparative flare status must be known')
  d
}

fit_immune_models <- function(d, config, output_dir) {
  dir.create(output_dir, recursive=TRUE, showWarnings=FALSE)
  fits <- list(); rows <- list()
  for (spec in config$models) {
    fit <- tf_ash_firth_profile(d, spec$field, 'flare', 'flare', spec$label,
      'Post-treatment immune associations', 'primary', spec$model_id,
      cache_dir=file.path(output_dir,'model_cache'), progress=TRUE)
    fits[[spec$model_id]] <- fit
    z <- d[!is.na(d[[spec$field]]),,drop=FALSE]
    rr <- fit$table
    inference_fields <- c('log_odds','log_ci_low','log_ci_high','conf_low','conf_high','p_value',
      'full_loglik','restricted_loglik','plr_statistic','plr_df','inference_method',
      'point_converged','profile_converged','plr_converged','profile_lower_iterations',
      'profile_upper_iterations','plr_iterations','point_max_convergence_error',
      'profile_lower_loglik_error','profile_lower_beta_error','profile_upper_loglik_error',
      'profile_upper_beta_error','restricted_max_convergence_error','fit_maxit','retry_used',
      'attempts','model_status','diagnostic')
    if(!all(inference_fields %in% names(rr))) stop('Incomplete shared Firth profile output schema')
    rows[[spec$model_id]] <- cbind(data.frame(field=spec$field, characteristic=spec$label,
      model_id=spec$model_id, flare_events=sum(z[[spec$field]][z$flare==1]),
      flare_evaluable=sum(z$flare==1), comparison_events=sum(z[[spec$field]][z$flare==0]),
      comparison_evaluable=sum(z$flare==0), n_courses=nrow(z),
      n_patient_clusters=length(unique(z$patient_cluster_id)), odds_ratio=rr$estimate,
      method=config$method,inference_schema=config$inference_schema),rr[inference_fields])
  }
  result <- do.call(rbind, rows); rownames(result) <- NULL
  options(digits=17)
  write.csv(result,file.path(output_dir,'Table_S3_Immune_Associations.csv'),row.names=FALSE,na='')
  saveRDS(fits,file.path(output_dir,'immune_models_restricted.rds'))
  write.csv(do.call(rbind,lapply(fits,`[[`,'diagnostics')),
    file.path(output_dir,'model_diagnostics.csv'),row.names=FALSE)
  write.csv(do.call(rbind,lapply(fits,`[[`,'membership')),
    file.path(output_dir,'model_membership_restricted.csv'),row.names=FALSE)
  writeLines(c('Three immune models; Firth profile penalized-likelihood intervals and penalized likelihood-ratio P values.',
    'All eligible treatment courses are included and treated as independent; no adjustment for repeated courses within patients.',capture.output(sessionInfo())),
    file.path(output_dir,'session_info.txt'))
  result
}

immune_main <- function(args) {
  if (length(args)<2) stop('Usage: calculate_table_s3_immune.R canonical_courses_restricted.csv output_directory [code_root] [selection.json]')
  script <- gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE)
  publication <- dirname(normalizePath(script,mustWork=TRUE))
  code_root <- if(length(args)>=3) args[3] else file.path(publication,'..','Code')
  selection <- if(length(args)>=4) args[4] else file.path(publication,'clinical_presentation_selection.json')
  runtime <- Sys.getenv('TF_R_LIBRARY','')
  if(nzchar(runtime)) .libPaths(c(.libPaths(),normalizePath(runtime,mustWork=TRUE)))
  for(package in c('logistf','jsonlite')) if(!requireNamespace(package,quietly=TRUE)) stop('Missing dependency: ',package)
  source(file.path(code_root,'model_functions.R'))
  config <- jsonlite::read_json(selection,simplifyVector=FALSE)$display_registration_updates$table_s3_immune
  if(is.null(config)||config$inference_schema!='tumor-flare-firth-profile-inference-v1'||
     config$method!='Firth profile penalized likelihood'||config$confidence_level!=.95||
     isTRUE(config$patient_clustering_accounted_for)) stop('Invalid immune model profile configuration')
  courses <- read.csv(args[1],check.names=FALSE,stringsAsFactors=FALSE,na.strings=c('','NA'))
  result <- fit_immune_models(immune_model_input(courses),config,args[2])
  print(result[,c('characteristic','n_courses','n_patient_clusters','odds_ratio','conf_low','conf_high','p_value','profile_converged','plr_converged')],row.names=FALSE)
}
if(sys.nframe()==0L) immune_main(commandArgs(trailingOnly=TRUE))
