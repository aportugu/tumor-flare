#!/usr/bin/env Rscript
# Usage: Rscript Publication/plot_smith_zee.R AGGREGATE_PREDICTIONS_CSV OUTPUT_DIRECTORY
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Expected the aggregate prediction CSV and an output directory")
curves <- utils::read.csv(args[1L], stringsAsFactors = FALSE)
required <- c("endpoint", "history", "day", "survival", "lower95", "upper95")
histories <- c("no_flare", "flare_day_4")
endpoints <- c("PFS", "OS")
stopifnot(identical(names(curves), required), setequal(curves$history, histories),
          setequal(curves$endpoint, endpoints), !anyDuplicated(curves[c("endpoint", "history", "day")]),
          all(with(curves, 0 <= lower95 & lower95 <= survival & survival <= upper95 & upper95 <= 1)))
curves <- curves[order(curves$endpoint, curves$history, curves$day), ]
days <- sort(unique(curves$day))
stopifnot(days[1L] == 0, 4 %in% days, max(days) > 4)
for (endpoint in endpoints) {
  paths <- split(curves[curves$endpoint == endpoint, ], curves$history[curves$endpoint == endpoint])
  stopifnot(length(paths) == 2L, identical(paths[[1L]]$day, paths[[2L]]$day),
            all(vapply(paths, function(path) {
              path$day[1L] == 0 && max(path$day) == max(days) && 4 %in% path$day &&
                all(diff(path$survival) <= 0) && path$survival[1L] == 1
            }, logical(1))))
}

# Adapt the discontinuation presentation's grid drawing: build each step from
# the exported model coordinates, mark the switch, and draw the shared path only once.
width <- 6.5
height <- width * 3.8 / 9
maximum <- max(days) / 30.4375
switch <- 4 / 30.4375
month_ticks <- seq(0, maximum, by = if (maximum >= 6) 3 else 1)
survival_ticks <- seq(0, 1, by = .25)
navy <- "#173D55"
red <- "#A3464A"
ink <- "#253440"
muted <- "#566571"
inches <- function(x) grid::unit(x, "inches")
native <- function(x) grid::unit(x, "native")
gp <- grid::gpar
label <- function(text, x, y, size = 9, bold = FALSE, just = "centre", rot = 0,
                  color = ink) {
  grid::grid.text(text, x, y, just = just, rot = rot,
                  gp = gp(fontfamily = "Helvetica", fontsize = size,
                          fontface = if (bold) "bold" else "plain", col = color))
}
step_x <- function(x) native(c(x[1L], rep(x[-1L], each = 2L)))
step_y <- function(y) c(rep(head(y, -1L), each = 2L), tail(y, 1L))
line <- function(path, color, type = 1L) {
  grid::grid.lines(step_x(path$day / 30.4375), native(step_y(path$survival)),
                   gp = gp(col = color, lwd = 1.7, lty = type,
                           linejoin = "mitre", lineend = "butt"))
}
band <- function(path, color) {
  x <- step_x(path$day / 30.4375)
  y <- c(step_y(path$lower95), rev(step_y(path$upper95)))
  grid::grid.polygon(grid::unit.c(x, rev(x)), native(y),
                     gp = gp(fill = grDevices::adjustcolor(color, alpha.f = .16), col = NA))
}

draw <- function() {
  left <- c(.73, 3.73)
  plot_width <- 2.56
  bottom <- .64
  top <- height - .45
  headings <- c("A  Progression-free survival", "B  Overall survival")
  grid::grid.newpage()
  grid::grid.rect(gp = gp(fill = "white", col = NA))
  for (i in seq_along(endpoints)) {
    endpoint <- endpoints[i]
    no_flare <- curves[curves$endpoint == endpoint & curves$history == histories[1L], ]
    flare <- curves[curves$endpoint == endpoint & curves$history == histories[2L], ]
    shared <- no_flare[no_flare$day <= 4, ]
    flare <- flare[flare$day >= 4, ]
    label(headings[i], inches(left[i]), inches(height - .15), size = 11, bold = TRUE,
          just = "left")
    grid::pushViewport(grid::viewport(x = inches(left[i]), y = inches(bottom),
      width = inches(plot_width), height = inches(top - bottom),
      just = c("left", "bottom"), xscale = c(0, maximum), yscale = c(0, 1)))
    grid::grid.segments(native(0), native(survival_ticks), native(maximum), native(survival_ticks),
                        gp = gp(col = "#DFE4E8", lwd = .75))
    band(no_flare, navy)
    band(flare, red)
    grid::grid.segments(native(switch), native(0), native(switch), native(1),
                        gp = gp(col = muted, lwd = .95, lty = 3))
    line(shared, navy)
    line(no_flare[no_flare$day >= 4, ], navy, 2L)
    line(flare, red)
    grid::grid.segments(native(c(0, 0)), native(c(0, 0)), native(c(maximum, 0)),
                        native(c(0, 1)), gp = gp(col = muted, lwd = .8))
    grid::grid.segments(native(month_ticks), inches(0), native(month_ticks), inches(-.045),
                        gp = gp(col = muted, lwd = .8))
    label(sprintf("%d%%", 100 * survival_ticks), inches(-.085), native(survival_ticks), just = "right")
    label(month_ticks, native(month_ticks), inches(-.16))
    label("Day 4", native(switch) + inches(.075), native(.085), just = "left", color = muted)
    grid::popViewport()
  }
  label("Model-based survival probability", inches(.13), inches((top + bottom) / 2),
        size = 10, rot = 90)
  label("Months since first step-up dose", inches(width / 2), inches(.29), size = 10)
  legend_x <- c(1.07, 3.67)
  grid::grid.segments(inches(legend_x), inches(.12), inches(legend_x + .34), inches(.12),
                      gp = gp(col = c(navy, red), lty = c(2, 1), lwd = 1.7))
  label(c("No flare throughout follow-up", "Flare beginning on day 4"),
        inches(legend_x + .43), inches(.12), just = "left")
}

dir.create(args[2L], recursive = TRUE, showWarnings = FALSE)
stem <- file.path(normalizePath(args[2L]), "Figure_S1_Smith_Zee_Survival")
pdf <- paste0(stem, ".pdf")
if (capabilities("aqua")) {
  grDevices::quartz(type = "pdf", file = pdf, width = width, height = height, bg = "white")
} else {
  grDevices::cairo_pdf(filename = pdf, width = width, height = height, bg = "white")
}
draw()
invisible(grDevices::dev.off())
poppler <- Sys.which("pdftocairo")
if (!nzchar(poppler)) stop("Install Poppler (pdftocairo) to export the outlined SVG and 600 dpi PNG")
convert <- function(options, output) {
  status <- system2(poppler, c(options, shQuote(pdf), shQuote(output)))
  if (status != 0L) stop("Figure S1 conversion failed: ", output)
}
convert("-svg", paste0(stem, ".svg"))
convert(c("-png", "-singlefile", "-r", "600"), stem)
