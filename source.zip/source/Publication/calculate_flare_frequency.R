#!/usr/bin/env Rscript
# Exact course-based frequency from aggregate cohort-flow counts.
validate_frequency_count <- function(value, name, positive = FALSE) {
  if (!is.numeric(value) || length(value) != 1L || !is.finite(value) ||
      value != floor(value) || value < (if (positive) 1 else 0)) {
    stop(name, " must be one finite ", if (positive) "positive" else "nonnegative", " integer")
  }
  value
}

flare_frequency <- function(flare_cases, total_courses, population = "Total cohort") {
  flare_cases <- validate_frequency_count(flare_cases, "flare_cases")
  total_courses <- validate_frequency_count(total_courses, "total_courses", positive = TRUE)
  if (flare_cases > total_courses) stop("flare_cases cannot exceed total_courses")
  if (!is.character(population) || length(population) != 1L || is.na(population) || !nzchar(population)) {
    stop("population must be one nonempty label")
  }
  interval <- stats::binom.test(flare_cases, total_courses, conf.level = 0.95)$conf.int
  data.frame(population = population, flare_cases = flare_cases, total_courses = total_courses,
    percent = 100 * flare_cases / total_courses,
    lower_95_percent = 100 * interval[1], upper_95_percent = 100 * interval[2],
    ci_method = "Clopper-Pearson exact binomial (95%)", stringsAsFactors = FALSE)
}

frequency_from_flow <- function(flow) {
  if (!is.data.frame(flow) || !all(c("stage", "courses") %in% names(flow))) {
    stop("flow requires stage and courses columns")
  }
  stage_count <- function(stage) {
    value <- flow$courses[!is.na(flow$stage) & flow$stage == stage]
    if (length(value) != 1L) stop("Missing or duplicated cohort stage: ", stage)
    value
  }
  flare_frequency(stage_count("Clinical series after secondary review"), stage_count("Total cohort"))
}

frequency_main <- function(args) {
  if (length(args) != 2L) stop("Usage: calculate_flare_frequency.R flow.csv output.csv")
  flow <- read.csv(args[1], stringsAsFactors = FALSE, check.names = FALSE)
  output <- frequency_from_flow(flow)
  dir.create(dirname(args[2]), recursive = TRUE, showWarnings = FALSE)
  write.csv(output, args[2], row.names = FALSE, na = "")
}

if (sys.nframe() == 0L) frequency_main(commandArgs(trailingOnly = TRUE))
