#!/usr/bin/env python3
"""Render an aggregate-only HTML supplement from a presentation manifest.

The manifest is supplied separately from the code archive. It contains published
aggregate tables, captions, and figure images, never individual clinical rows.
"""
import argparse
import base64
import html
import json
import re
from pathlib import Path


def escape(text):
    return html.escape(str(text), quote=True)


def text_lines(text):
    return '<br>'.join(escape(line) for line in str(text).split('\n'))


def section_start(section_id, title, level=1):
    return f'<div id="{escape(section_id)}" class="section level{level}"><h{level}>{escape(title)}</h{level}>'


def paragraph(text, css=''):
    return f'<p class="{escape(css)}">{text_lines(text)}</p>'


def code_disclosure(label, code_files, code_root):
    fragments = []
    root = Path(code_root).resolve()
    for relative in code_files:
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError(f'Invalid executable code path: {relative}')
        fragments.append(f'# {relative}\n' + path.read_text(encoding='utf-8'))
    return ('<details class="code-disclosure"><summary>' + escape(label) +
            '</summary><pre><code>' + escape('\n\n'.join(fragments)) + '</code></pre></details>')


def render_table(panel):
    headers = panel['headers']
    output = ['<div class="publication-table table-scroll"><table class="publication-grid"><thead><tr>']
    output.extend(f'<th scope="col">{text_lines(x)}</th>' for x in headers)
    output.append('</tr></thead><tbody>')
    for row in panel['rows']:
        if row.get('kind') == 'group':
            output.append(f'<tr class="characteristic-group"><th scope="row" colspan="{len(headers)}">{text_lines(row["cells"][0])}</th></tr>')
        else:
            output.append('<tr>')
            for i, cell in enumerate(row['cells']):
                css = ' class="category"' if i == 0 and row.get('kind') == 'category' else ''
                output.append(f'<td{css}>{text_lines(cell)}</td>')
            output.append('</tr>')
    output.append('</tbody></table></div>')
    return ''.join(output)


def validate_manifest(manifest):
    if manifest.get('schema') != 'tumor-flare-aggregate-publication-v1':
        raise ValueError('Unsupported publication schema')
    if len(manifest.get('tables', [])) != 7 or len(manifest.get('figures', [])) != 6:
        raise ValueError('Expected Tables 1–2/S1–S5 and Figures 1–5/S1')
    for display in manifest['tables']:
        for panel in display['panels']:
            for row in panel['rows']:
                if row.get('kind') != 'group' and len(row['cells']) != len(panel['headers']):
                    raise ValueError(f'Inconsistent table width: {display["label"]}')
    # Clinical case contracts and individual case labels are never accepted.
    reader_data = json.dumps({k: v for k, v in manifest.items() if k != 'aggregate_inputs'}, ensure_ascii=False)
    if re.search(r'\bTF\d{1,3}\b|"(?:case_id|case_label|patient_id)"', reader_data):
        raise ValueError('Individual clinical data are not publication inputs')
    for item in manifest.get('aggregate_inputs', []):
        if any(re.search(r'^(case_id|case_label|patient_id)$', x) for x in item.get('columns', [])):
            raise ValueError('Individual-record columns cannot be exported')


def build(manifest, code_root, archive_link):
    validate_manifest(manifest)
    parts = [section_start('reproducibility-overview', '1 Reproducibility overview'),
             paragraph(manifest['overview']),
             '<p><a href="' + escape(archive_link) + '">' + escape(manifest['download_label']) + '</a></p></div>',
             section_start('shared-analysis-code', '2 Shared analysis code'),
             paragraph(manifest['shared_introduction'])]
    for i, item in enumerate(manifest['shared_sections'], 1):
        parts += [section_start(f'display-2-{i}', f'2.{i} {item["title"]}', 2),
                  code_disclosure(f'Show code used for {item["title"].lower()}', item['code_files'], code_root), '</div>']
    parts += ['</div>', section_start('tables', '3 Tables')]
    for i, item in enumerate(manifest['tables'], 1):
        parts.append(section_start(f'display-3-{i}', f'3.{i} {item["label"]} {item["title"]}', 2))
        for j, panel in enumerate(item['panels'], 1):
            if panel.get('title'):
                parts.append(section_start(f'display-3-{i}-{j}', f'3.{i}.{j} {panel["title"]}', 3))
            parts.append(render_table(panel))
            for note in panel.get('notes', []):
                parts.append(paragraph(note, 'publication-note'))
            if panel.get('title'):
                parts.append('</div>')
        parts += [paragraph(item['caption'], 'publication-note'),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div>']
    parts += ['</div>', section_start('figures', '4 Figures')]
    for i, item in enumerate(manifest['figures'], 1):
        parts.append(section_start(f'display-4-{i}', f'4.{i} {item["label"]} {item["title"]}', 2))
        source = item['image_data_url']
        if not source.startswith('data:image/png;base64,'):
            raise ValueError('Publication figures must use embedded PNG data')
        base64.b64decode(source.split(',', 1)[1], validate=True)
        parts += ['<div class="publication-figure"><img src="' + escape(source) + '" alt="' + escape(item['title']) + '">',
                  paragraph(item['caption'], 'publication-legend'),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div></div>']
    parts += ['</div>', section_start('computational-environment', '5 Computational environment'),
              render_table({'headers': ['Software', 'Version'], 'rows': [{'cells': row} for row in manifest['environment']]}), '</div>']
    encoded_manifest = json.dumps(manifest, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    parts.append('<script type="application/json" id="publication-manifest">' + encoded_manifest + '</script>')
    template = (Path(code_root) / 'Publication/reproducibility_layout.html').read_text(encoding='utf-8')
    return template.replace('{{TITLE}}', escape(manifest['title'])).replace('{{CONTENT}}', ''.join(parts))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--code-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--archive-link', default='analysiscode.zip')
    args = parser.parse_args()
    args.output.write_text(build(json.loads(args.manifest.read_text()), args.code_root, args.archive_link), encoding='utf-8')


if __name__ == '__main__':
    main()
