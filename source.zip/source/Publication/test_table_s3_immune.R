#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[1] else '.'
runtime <- Sys.getenv('TF_R_LIBRARY','')
if(nzchar(runtime)) .libPaths(c(normalizePath(runtime,mustWork=TRUE),.libPaths()))
script <- gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE)
source(file.path(dirname(normalizePath(script)),'calculate_table_s3_immune.R'))
source(file.path(root,'Code/model_functions.R'))
checks <- 0L
check <- function(value) { stopifnot(value); checks <<- checks+1L }
reject <- function(fun) { check(inherits(tryCatch(fun(),error=identity),'error')) }
d <- data.frame(course_id=paste0('synthetic-course-',1:6),
  patient_cluster_id=c('a','a','b','c','d','e'),comparative_eligible=c(TRUE,TRUE,TRUE,TRUE,FALSE,TRUE),
  analysis_flare=c(1,0,0,1,1,NA),crs_1=c(1,0,1,0,1,0),icans_1=c(0,1,0,1,0,0),toci_treatment=c(1,NA,0,1,0,0))
z <- immune_model_input(d)
check(nrow(z)==4L && length(unique(z$patient_cluster_id))==3L)
check(is.na(z$toci_treatment[2]))
bad <- d; bad$course_id[2]<-bad$course_id[1]; reject(function()immune_model_input(bad))
bad <- d; bad$crs_1[1]<-2; reject(function()immune_model_input(bad))
bad <- d; bad$patient_cluster_id[1]<-''; reject(function()immune_model_input(bad))
fixture <- data.frame(course_id=paste0('synthetic-',1:50),patient_cluster_id=rep(1:25,each=2),
  x=c(rep(0,40),rep(1,10)),y=c(rep(0,30),rep(1,10),rep(0,3),rep(1,7)))
fixture$flare <- fixture$x
fit <- tf_ash_firth_profile(fixture,'y','x','x','Synthetic immune association','Synthetic','primary','synthetic_profile',progress=FALSE)
r <- fit$table
check(r$point_converged && r$profile_converged && r$plr_converged)
check(isTRUE(all.equal(r$estimate,((7+.5)/(3+.5))/((10+.5)/(30+.5)),tolerance=1e-7)))
reference <- logistf::logistf(y~x,data=fixture,pl=TRUE,
  control=logistf::logistf.control(maxit=200,lconv=1e-7,gconv=1e-7,xconv=1e-7),
  plcontrol=logistf::logistpl.control(maxit=200,lconv=1e-7,xconv=1e-7))
check(isTRUE(all.equal(r$conf_low,unname(exp(reference$ci.lower['x'])),tolerance=1e-7)))
check(isTRUE(all.equal(r$conf_high,unname(exp(reference$ci.upper['x'])),tolerance=1e-7)))
check(isTRUE(all.equal(r$p_value,unname(reference$prob['x']),tolerance=1e-7)))
check(isTRUE(all.equal(r$p_value,pchisq(r$plr_statistic,1,lower.tail=FALSE),tolerance=1e-8)))
check(abs((r$log_odds-r$log_ci_low)-(r$log_ci_high-r$log_odds))>1e-3)
check(!any(grepl('bootstrap|seed',names(r))))
regrouped <- fixture;regrouped$patient_cluster_id<-seq_len(nrow(fixture))
other <- tf_ash_firth_profile(regrouped,'y','x','x','Synthetic immune association','Synthetic','primary','synthetic_independent',progress=FALSE)$table
check(isTRUE(all.equal(r[,c('estimate','conf_low','conf_high','p_value')],other[,c('estimate','conf_low','conf_high','p_value')],tolerance=1e-10)))
# Explicit named diagnostic export and backward-compatible alias agree exactly.
input <- data.frame(course_id=fixture$course_id,patient_cluster_id=fixture$patient_cluster_id,
 comparative_eligible=TRUE,analysis_flare=fixture$x,crs_1=fixture$y,icans_1=1-fixture$y,toci_treatment=fixture$y)
config <- jsonlite::read_json(file.path(root,'Publication/clinical_presentation_selection.json'),simplifyVector=FALSE)$display_registration_updates$table_s3_immune
output <- tempfile('synthetic-immune-diagnostics-');dir.create(output)
result <- fit_immune_models(immune_model_input(input),config,output)
check(nrow(result)==3L)
check(file.exists(file.path(output,'firth_diagnostics.csv')))
check(identical(readBin(file.path(output,'firth_diagnostics.csv'),'raw',n=file.info(file.path(output,'firth_diagnostics.csv'))$size),
                readBin(file.path(output,'model_diagnostics.csv'),'raw',n=file.info(file.path(output,'model_diagnostics.csv'))$size)))
unlink(output,recursive=TRUE)
fixture$y<-0
failed<-tf_ash_firth_profile(fixture,'y','x','x','Synthetic failure','Synthetic','primary','synthetic_unavailable',progress=FALSE)$table
check(!failed$point_converged && all(is.na(failed[c('conf_low','conf_high','p_value')])))
cat(checks,'synthetic immune-input, independent-course profile, and penalized LR checks passed\n')
