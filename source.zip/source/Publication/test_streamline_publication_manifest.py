#!/usr/bin/env python3
"""Focused synthetic checks for aggregate clinical presentation selection."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("streamline", ROOT / "streamline_publication_manifest.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
SELECTION = json.loads((ROOT / "clinical_presentation_selection.json").read_text())
GROUPS = ("All", "Definite/Probable", "Possible")
TOTALS = (10, 6, 4)
COLUMNS = ["panel", "field", "characteristic", "category", "group", "n", "total_n", "evaluable_n", "denominator", "percent", "available_n", "median", "q1", "q3"]


def fixture():
    """Synthetic fields exercise missingness and formatting without clinical data."""
    rows, seen = [], set()
    for panel in SELECTION["clinical_panels"]:
        for section in panel["sections"]:
            for spec in section["fields"]:
                field = spec["field"]
                if field in seen:
                    continue
                seen.add(field)
                if spec["mode"] == "timing":
                    for group, total, available in zip(GROUPS, TOTALS, (8, 5, 3)):
                        rows.append({"panel": "A", "field": field, "characteristic": spec["label"], "category": "Median (IQR)", "group": group, "n": "", "total_n": str(total), "evaluable_n": str(available), "denominator": str(available), "percent": "", "available_n": str(available), "median": "2", "q1": "1", "q3": "3"})
                    continue
                if spec["mode"] == "selected_category":
                    values = {"Recorded date": (7, 4, 3), "Estimated date": (2, 1, 1), "Interval only": (1, 1, 0)} if field == "onset_days_availability" else {"Recorded date": (6, 4, 2), "Estimated date": (2, 1, 1), "Unavailable": (2, 1, 1)}
                elif spec["mode"] == "binary":
                    values = {"Yes": (4, 2, 2), "No": (2, 2, 0), "Blank": (1, 1, 0), "Unknown": (1, 1, 0), "Not applicable": (1, 0, 1), "Not reported": (1, 0, 1)}
                else:
                    values = {"Category A": (6, 4, 2), "Category B": (2, 1, 1), "Unknown": (1, 1, 0), "Not applicable": (1, 0, 1)}
                for category, counts in values.items():
                    for group, total, count in zip(GROUPS, TOTALS, counts):
                        rows.append({"panel": "synthetic", "field": field, "characteristic": spec["label"], "category": category, "group": group, "n": str(count), "total_n": str(total), "evaluable_n": str(total), "denominator": str(total), "percent": str(100 * count / total), "available_n": "", "median": "", "q1": "", "q3": ""})
    return {"aggregate_inputs": [MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)]}


class AggregateSelectionTests(unittest.TestCase):
    def setUp(self):
        self.full = fixture()
        self.panels, self.raw = MODULE.build_clinical_panels(self.full, SELECTION)

    def clinical_row(self, field):
        return next(row for panel in self.panels for row in panel["rows"] if row.get("field") == field and row["kind"] != "group")

    def test_denominators_come_from_inputs(self):
        self.assertEqual(self.panels[0]["headers"], ["Characteristic", "All cases (N = 10)", "Definite/Probable (N = 6)", "Possible (N = 4)"])

    def test_all_panels_have_identical_headers(self):
        self.assertTrue(all(panel["headers"] == self.panels[0]["headers"] for panel in self.panels))

    def test_binary_positive_count_keeps_group_denominator(self):
        self.assertTrue(self.clinical_row("overlap_infection")["cells"][1].startswith("4/10 (40.0%)"))

    def test_binary_no_state_is_not_displayed(self):
        self.assertNotIn("No:", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_blank_is_separate_cell_line(self):
        self.assertIn("\nBlank: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_unknown_is_separate_cell_line(self):
        self.assertIn("\nUnknown: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_not_applicable_is_separate_cell_line(self):
        self.assertIn("\nNot applicable: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_not_reported_is_separate_cell_line(self):
        self.assertIn("\nNot reported: 1/10 (10.0%)", self.clinical_row("later_local_after_cart")["cells"][1])

    def test_zero_missing_states_are_omitted_from_binary_cells(self):
        self.assertNotIn("Not reported:", self.clinical_row("later_local_after_cart")["cells"][2])

    def test_categorical_states_are_not_collapsed(self):
        rows = [row for row in self.panels[1]["rows"] if row.get("field") == "ctcae_pain_grade" and row["kind"] == "category"]
        self.assertEqual([row["cells"][0] for row in rows], ["Category A", "Category B", "Unknown", "Not applicable"])

    def test_categorical_zero_missing_states_remain_visible(self):
        row = next(row for row in self.panels[1]["rows"] if row.get("field") == "ctcae_pain_grade" and row["cells"][0] == "Not applicable")
        self.assertEqual(row["cells"][2], "0/6 (0.0%)")

    def test_timing_uses_available_denominator(self):
        self.assertEqual(self.clinical_row("onset_days")["cells"][1:], ["2 (1–3); n = 8", "2 (1–3); n = 5", "2 (1–3); n = 3"])

    def test_interval_has_no_midpoint(self):
        row = next(row for row in self.panels[0]["rows"] if row["cells"][0] == "Onset interval without a date")
        self.assertEqual(row["cells"][1], "1/10 (10.0%)")
        self.assertNotIn("midpoint", str(row))

    def test_absent_interval_category_is_not_displayed(self):
        full = fixture()
        rows = MODULE.input_rows(full["aggregate_inputs"][0])
        rows = [row for row in rows if not (row["field"] == "onset_days_availability" and row["category"] == "Interval only")]
        full["aggregate_inputs"][0] = MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)
        panels, selected = MODULE.build_clinical_panels(full, SELECTION)
        self.assertFalse(any(row["cells"][0] == "Onset interval without a date" for panel in panels for row in panel["rows"]))
        self.assertFalse(any(row["category"] == "Interval only" for row in MODULE.input_rows(selected)))

    def test_zero_interval_category_is_not_displayed(self):
        full = fixture()
        rows = MODULE.input_rows(full["aggregate_inputs"][0])
        for row in rows:
            if row["field"] == "onset_days_availability" and row["category"] == "Interval only":
                row["n"], row["percent"] = "0", "0"
        full["aggregate_inputs"][0] = MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)
        panels, _ = MODULE.build_clinical_panels(full, SELECTION)
        self.assertFalse(any(row["cells"][0] == "Onset interval without a date" for panel in panels for row in panel["rows"]))

    def test_recorded_dates_not_in_selected_uncertainty_rows(self):
        rows = MODULE.input_rows(self.raw)
        self.assertFalse(any(row["category"] == "Recorded date" for row in rows))

    def test_unavailable_resolution_not_changed_to_ongoing(self):
        row = self.clinical_row("resolution_days_availability")
        self.assertIn("Unavailable: 2/10 (20.0%)", row["cells"][1])
        self.assertNotIn("ongoing", str(row).lower())

    def test_selected_inputs_are_subset_of_original_rows(self):
        original = MODULE.input_rows(self.full["aggregate_inputs"][0])
        self.assertTrue(all(row in original for row in MODULE.input_rows(self.raw)))

    def test_repeated_field_selection_does_not_duplicate_inputs(self):
        rows = MODULE.input_rows(self.raw)
        keys = [(row["field"], row["category"], row["group"]) for row in rows]
        self.assertEqual(len(keys), len(set(keys)))

    def test_group_nonconservation_rejected(self):
        full = copy.deepcopy(self.full)
        i = COLUMNS.index("total_n")
        for row in full["aggregate_inputs"][0]["rows"]:
            if row[COLUMNS.index("group")] == "All":
                row[i] = "11"
        with self.assertRaisesRegex(ValueError, "do not conserve"):
            MODULE.build_clinical_panels(full, SELECTION)

    def test_inconsistent_group_denominator_rejected(self):
        self.full["aggregate_inputs"][0]["rows"][0][COLUMNS.index("total_n")] = "11"
        with self.assertRaisesRegex(ValueError, "inconsistent denominators"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_missing_selected_field_rejected(self):
        self.full["aggregate_inputs"][0]["rows"] = [row for row in self.full["aggregate_inputs"][0]["rows"] if row[COLUMNS.index("field")] != "overlap_crs"]
        with self.assertRaisesRegex(ValueError, "Missing clinical field"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_duplicate_aggregate_row_rejected(self):
        self.full["aggregate_inputs"][0]["rows"].append(self.full["aggregate_inputs"][0]["rows"][0])
        with self.assertRaisesRegex(ValueError, "Expected one aggregate row"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_rendered_csv_has_indented_categories_and_matching_widths(self):
        item = MODULE.table_input("synthetic.csv", self.panels[0])
        self.assertTrue(item["rows"][1][0].startswith("  "))
        self.assertTrue(all(len(row) == len(item["columns"]) for row in item["rows"]))

    def test_generic_selection_has_no_empirical_counts_or_estimates(self):
        forbidden = {"n", "count", "counts", "estimate", "conf_low", "conf_high", "median", "q1", "q3", "total_n"}
        def keys(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    yield key
                    yield from keys(child)
            elif isinstance(value, list):
                for child in value:
                    yield from keys(child)
        self.assertFalse(forbidden & set(keys(SELECTION)))

    def test_author_group_label_updated(self):
        table = {"label": "Table 2", "panels": [{"rows": [{"kind": "group", "cells": ["Best systemic BsAb response"]}, {"kind": "category", "cells": ["CR", "2/10 (20.0%)", "1/6 (16.7%)", "1/4 (25.0%)"]}]}]}
        updated = MODULE.apply_main_table_labels(copy.deepcopy(table), SELECTION)
        self.assertEqual(updated["panels"][0]["rows"][0]["cells"][0], "Best response to BsAb treatment")
        self.assertEqual(updated["panels"][0]["rows"][1], table["panels"][0]["rows"][1])

    def test_author_label_changes_do_not_touch_other_tables(self):
        table = {"label": "Table S1", "panels": [{"rows": [{"kind": "group", "cells": ["Best systemic BsAb response"]}]}]}
        self.assertEqual(MODULE.apply_main_table_labels(copy.deepcopy(table), SELECTION), table)


def selected_fixture():
    """Synthetic model populations test presentation without clinical records."""
    clinical_panels, clinical_input = MODULE.build_clinical_panels(fixture(), SELECTION)
    clinical_input["filename"] = "Table_S1_Selected_Aggregates.csv"
    model_columns = ["model_id", "n_courses", "n_patient_clusters", "candidates", "events", "candidate_events", "excluded_missing"]
    raw_models, visible = [], {}
    populations = {
        "primary_unadjusted": (100, 90, 10, 0, (70, 50, 30), (8, 5, 3)),
        "primary_adjusted": (80, 72, 8, 20, (56, 40, 24), (8, 4, 2)),
        "strict_adjusted": (75, 69, 5, 20, (53, 39, 23), (5, 3, 1)),
        "without_dominant_site_adjusted": (60, 55, 4, 10, (42, 30, 18), (3, 2, 1)),
    }
    for ids in SELECTION["logistic_models"].values():
        for model_id in ids:
            if "response_" in model_id:
                threshold_index = 1 if "_vgpr_" in model_id else 2 if "_cr_" in model_id else 0
                threshold = ("≥PR", "≥VGPR", "CR/sCR")[threshold_index]
                scenario = model_id.split("_response_")[0]
                adjustment = "unadjusted" if model_id.endswith("_unadjusted") else "adjusted"
                n, patients, flare, missing, events, flare_events = populations[scenario + "_" + adjustment]
                events, flare_events = events[threshold_index], flare_events[threshold_index]
                label = f"Response {threshold} ({adjustment})"
            else:
                n, patients, flare, missing, events, flare_events = 100, 90, 10, 0, 10, 10
                label = model_id
            raw = dict(zip(model_columns, map(str, (model_id, n, patients, flare, events, flare_events, missing))))
            raw_models.append(raw)
            visible[model_id] = {"kind": "row", "model_id": model_id,
                "cells": [label, f"{n} / {patients}", f"{flare} / {events}\nOutcomes in flare courses {flare_events}", str(missing), "1.25 (0.60–2.00)", "0.5000"]}
    logistic_panels = [{"title": title, "headers": ["Model", "Courses / patients", "Flare courses / total outcomes\nOutcomes in flare courses", "Excluded for missing data", "OR (95% CI)", "P value"],
        "rows": [copy.deepcopy(visible[model_id]) for model_id in ids]} for title, ids in SELECTION["logistic_models"].items()]
    logistic_panels[3]["notes"] = ["The adjusted ≥PR model includes 5 flare courses, all with at least a partial response. Sparse outcomes and complete separation limit inference; this does not establish a response benefit."]
    survival_columns = ["scenario", "endpoint", "model", "ph_global_p", "ph_flare_p"]
    survival_raw, survival_panels = [], []
    headers = ["Endpoint and model", "Courses / patients", "Exposed courses / exposed events", "Total events / excluded for missing data", "HR (95% CI)", "P value", "PH global / flare P"]
    for si, spec in enumerate(SELECTION["survival_panels"]):
        rows = []
        for ei, endpoint in enumerate(("PFS", "OS")):
            for model in spec["models"]:
                adjusted = model == "Adjusted: six baseline variables"
                global_p = f"{0.0111 + si * 0.02 + ei * 0.001:.4f}" if adjusted else ""
                flare_p = f"{0.0222 + si * 0.02 + ei * 0.001:.4f}" if adjusted else ""
                survival_raw.append(dict(zip(survival_columns, (spec["scenario"], endpoint, model, global_p, flare_p))))
                rows.append({"kind": "row", "object_id": f'{spec["scenario"]}:{endpoint}:{model}',
                    "cells": [endpoint + "\n" + model, "100 / 90", "10 / 5", "50 / 0", "1.20 (0.70–2.00)", "0.2000", f"{global_p} / {flare_p}" if adjusted else "Unavailable / Unavailable"]})
        survival_panels.append({"title": spec["title"], "headers": headers[:], "rows": rows})
    landmark = [{"kind": "row", "object_id": f"primary:{endpoint}:landmark:{day}",
        "cells": [f"{endpoint}\nDay {day} landmark", "80 / 72", "8 / 4", "40", "1.10 (0.60–2.00)", "0.3000", "Unavailable / Unavailable"]}
        for endpoint in ("PFS", "OS") for day in (30, 60)]
    landmark_headers = headers[:]
    landmark_headers[3] = "Total events"
    survival_panels.append({"title": "Primary landmark analyses", "headers": landmark_headers, "rows": landmark})
    simple_panel = {"title": "Synthetic", "headers": ["Characteristic", "N"], "rows": [{"kind": "row", "cells": ["Synthetic value", "10"]}]}
    tables = [{"label": label, "title": "Synthetic", "caption": "Synthetic fixture", "panels": [copy.deepcopy(simple_panel)], "code_files": []} for label in ("Table 1", "Table 2")]
    tables += [
        {"label": "Table S1", "title": "Clinical", "caption": "Synthetic clinical fixture", "panels": clinical_panels, "code_files": []},
        {"label": "Table S2", "title": "Comparative", "caption": "Synthetic comparative fixture", "panels": [copy.deepcopy(simple_panel), copy.deepcopy(simple_panel)], "code_files": []},
        {"label": "Table S3", "title": "Logistic", "caption": "Synthetic model fixture", "panels": logistic_panels, "code_files": []},
        {"label": "Table S4", "title": "Survival", "caption": "Synthetic survival fixture", "panels": survival_panels, "code_files": []},
    ]
    inputs = []
    for table in tables:
        table["aggregate_files"] = MODULE.panel_input_names(table)
        inputs += [MODULE.table_input(name, panel) for name, panel in zip(table["aggregate_files"], table["panels"])]
    inputs += [clinical_input, MODULE.input_object("models.csv", model_columns, raw_models),
        MODULE.input_object("survival_models.csv", survival_columns, survival_raw),
        {"filename": "Table_S4_Landmark_Models.csv", "columns": ["object_id"], "rows": [[row["object_id"]] for row in landmark]},
        {"filename": "synthetic_figure_input.csv", "columns": ["category", "n"], "rows": [["A", "10"]]},
    ]
    tables[2]["aggregate_files"].append(clinical_input["filename"])
    tables[4]["aggregate_files"].append("models.csv")
    tables[5]["aggregate_files"] += ["survival_models.csv", "Table_S4_Landmark_Models.csv"]
    config = SELECTION["display_registration_updates"]["figure3_statuses"]
    figure_columns = ["panel", "field", "label", "category", "n", "denominator"]
    for filename, panels in [("presentation.csv", ("A", "B")), ("anatomy_binary.csv", ("C",))]:
        figure_rows = [{"panel": panel, "field": field, "label": field, "category": category, "n": n, "denominator": 10}
                       for panel in panels for field in config["panels"][panel]
                       for category, n in [("Yes", 4), ("No", 5), ("Not applicable", 1)]]
        inputs.append(MODULE.input_object(filename, figure_columns, figure_rows))
    return {"schema": SELECTION["publication_schema"], "tables": tables, "aggregate_inputs": inputs,
        "figures": [{"label": label, "caption": "Synthetic figure", "aggregate_files": []} for label in ("Figure 1", "Figure 2", "Figure 3", "Figure 4", "Figure 5", "Figure S1")]}


class TableConsolidationTests(unittest.TestCase):
    def setUp(self):
        self.before = selected_fixture()
        self.after = MODULE.consolidate_manifest(self.before, SELECTION)

    def table(self, label):
        return next(table for table in self.after["tables"] if table["label"] == label)

    def raw_models(self):
        return MODULE.input_rows(next(item for item in self.before["aggregate_inputs"] if item["filename"] == "models.csv"))

    def mutate_model(self, model_id, field, value):
        item = next(item for item in self.before["aggregate_inputs"] if item["filename"] == "models.csv")
        rows = MODULE.input_rows(item)
        MODULE.require_one(rows, model_id=model_id)[field] = value
        item["rows"] = MODULE.input_object(item["filename"], item["columns"], rows)["rows"]

    def test_complete_synthetic_integrity_verification_passes(self):
        self.assertTrue(MODULE.verify_consolidation(self.before, self.after, SELECTION)["passed"])

    def test_seven_physical_supplementary_tables(self):
        self.assertEqual([len(self.table(label)["panels"]) for label in ("Table S1", "Table S2", "Table S3", "Table S4")], [1, 2, 2, 2])

    def test_three_clinical_domains_are_spanning_group_rows(self):
        groups = [row for row in self.table("Table S1")["panels"][0]["rows"] if row.get("group_type") == "clinical_domain"]
        self.assertEqual(len(groups), 3)
        self.assertTrue(all(row["kind"] == "group" and len(row["cells"]) == 1 for row in groups))

    def test_response_fractions_preserve_both_groups(self):
        self.assertEqual(MODULE.response_fractions(MODULE.require_one(self.raw_models(), model_id="primary_response_pr_adjusted")), ("8/8", "48/72"))

    def test_response_population_headings_use_synthetic_inputs(self):
        headings = [row["cells"][0] for row in self.table("Table S3")["panels"][1]["rows"] if row["kind"] == "group"]
        self.assertEqual(len(headings), 4)
        self.assertIn("80 courses / 72 patients; 20 excluded", headings[1])

    def test_relocated_sparse_note_names_the_strict_population(self):
        note = self.table("Table S3")["panels"][1]["notes"][0]
        self.assertTrue(note.startswith("The adjusted Definite/Probable ≥PR model"))
        self.assertIn("all with at least a partial response", note)

    def test_twenty_unique_logistic_ids_remain(self):
        rows = [row for panel in self.table("Table S3")["panels"] for row in panel["rows"] if row.get("model_id")]
        self.assertEqual(len(rows), 20)
        self.assertEqual(len({row["model_id"] for row in rows}), 20)

    def test_baseline_column_drops_only_redundant_values(self):
        panel = self.table("Table S3")["panels"][0]
        self.assertEqual(panel["headers"][2], "Flare courses, n")
        self.assertTrue(all(row["cells"][2] == "10" for row in panel["rows"]))

    def test_invalid_response_two_by_two_counts_rejected(self):
        self.mutate_model("primary_response_pr_adjusted", "candidate_events", "9")
        with self.assertRaisesRegex(ValueError, "valid 2×2"):
            MODULE.response_fractions(MODULE.require_one(self.raw_models(), model_id="primary_response_pr_adjusted"))

    def test_negative_comparison_events_rejected(self):
        self.mutate_model("primary_response_pr_adjusted", "events", "7")
        with self.assertRaisesRegex(ValueError, "valid 2×2"):
            MODULE.response_fractions(MODULE.require_one(self.raw_models(), model_id="primary_response_pr_adjusted"))

    def test_different_response_threshold_population_rejected(self):
        self.mutate_model("primary_response_pr_adjusted", "n_courses", "79")
        with self.assertRaisesRegex(ValueError, "different population"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_different_response_threshold_exclusions_rejected(self):
        self.mutate_model("primary_response_pr_adjusted", "excluded_missing", "19")
        with self.assertRaisesRegex(ValueError, "different population"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_nonredundant_baseline_outcome_cannot_be_dropped(self):
        self.mutate_model("primary_age10", "events", "9")
        with self.assertRaisesRegex(ValueError, "disagree"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_response_display_outcome_mismatch_rejected(self):
        self.before["tables"][4]["panels"][2]["rows"][0]["cells"][2] = "10 / 71\nOutcomes in flare courses 8"
        with self.assertRaisesRegex(ValueError, "display counts disagree"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_inconsistent_clinical_headers_rejected(self):
        self.before["tables"][2]["panels"][1]["headers"] = list(self.before["tables"][2]["panels"][1]["headers"])
        self.before["tables"][2]["panels"][1]["headers"][1] = "Different population"
        with self.assertRaisesRegex(ValueError, "different populations"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_second_consolidation_rejected(self):
        with self.assertRaisesRegex(ValueError, "already been consolidated"):
            MODULE.consolidate_manifest(self.after, SELECTION)

    def test_fourteen_survival_rows_remain_without_PH_cells(self):
        panels = self.table("Table S4")["panels"]
        self.assertEqual([sum(bool(row.get("object_id")) for row in panel["rows"]) for panel in panels], [10, 4])
        self.assertTrue(all(len(row["cells"]) == 6 for panel in panels for row in panel["rows"] if row.get("object_id")))

    def test_all_six_PH_pairs_appear_in_keyed_note(self):
        note = self.table("Table S4")["panels"][0]["notes"][0]
        raw = MODULE.input_rows(next(item for item in self.before["aggregate_inputs"] if item["filename"] == "survival_models.csv"))
        pairs = [f'{row["ph_global_p"]}/{row["ph_flare_p"]}' for row in raw if row["ph_global_p"]]
        self.assertEqual(len(pairs), 6)
        self.assertTrue(all(pair in note for pair in pairs))
        self.assertIn("unavailable for the other models", note)

    def test_PH_source_mismatch_rejected(self):
        self.before["tables"][5]["panels"][0]["rows"][2]["cells"][-1] = "0.9000 / 0.8000"
        with self.assertRaisesRegex(ValueError, "PH display disagrees"):
            MODULE.consolidate_manifest(self.before, SELECTION)

    def test_removed_PH_note_fails_verification(self):
        self.table("Table S4")["panels"][0]["notes"][0] = "Diagnostics omitted"
        with self.assertRaisesRegex(AssertionError, "PH pair retained"):
            MODULE.verify_consolidation(self.before, self.after, SELECTION)

    def test_changed_OR_fails_verification(self):
        row = next(row for row in self.table("Table S3")["panels"][1]["rows"] if row.get("model_id") == "primary_response_pr_adjusted")
        row["cells"][-2] = "9.99 (8.00–12.00)"
        with self.assertRaisesRegex(AssertionError, "OR and P unchanged"):
            MODULE.verify_consolidation(self.before, self.after, SELECTION)

    def test_changed_analytical_input_fails_verification(self):
        item = next(item for item in self.after["aggregate_inputs"] if item["filename"] == "synthetic_figure_input.csv")
        item["rows"][0][1] = "11"
        with self.assertRaisesRegex(AssertionError, "Analytical aggregate object unchanged"):
            MODULE.verify_consolidation(self.before, self.after, SELECTION)


class TimingDensityRegistrationTests(unittest.TestCase):
    def setUp(self):
        columns = ["measure", "day", "density", "denominator"]
        counts = {"Onset": 8, "Peak": 7, "Symptom resolution": 5}
        rows = []
        for measure, total in counts.items():
            for day in range(101):
                rows.append(dict(zip(columns, (measure, day, 0.1 / (1 + day), total))))
        self.densities = MODULE.input_object("Figure_2_Timing_Densities.csv", columns, rows)
        self.manifest = {"aggregate_inputs": [MODULE.input_object("Figure_2_Timing_Summaries.csv",
            ["measure", "n", "median", "q1", "q3"], [{"measure": measure, "n": total, "median": 3, "q1": 2, "q3": 6}
                for measure, total in counts.items()]),
            {"filename": "Figure_2_Timing_Distributions.csv", "columns": ["synthetic"], "rows": [["obsolete bins"]]}],
            "figures": [{"label": "Figure 2", "aggregate_files": ["Figure_2_Timing_Summaries.csv"], "caption": "Synthetic timing"},
                {"label": "Figure 1", "caption": "Unchanged synthetic figure"}], "tables": [{"label": "Synthetic"}]}

    def test_registration_preserves_summaries_and_retires_bins(self):
        registered = MODULE.register_figure2_densities(self.manifest, self.densities)
        self.assertEqual(registered["aggregate_inputs"][0], self.manifest["aggregate_inputs"][0])
        self.assertEqual(registered["tables"], self.manifest["tables"])
        self.assertEqual(registered["figures"][1], self.manifest["figures"][1])
        self.assertEqual(len(registered["aggregate_inputs"]), 2)
        self.assertEqual([item["filename"] for item in registered["aggregate_inputs"]],
                         ["Figure_2_Timing_Summaries.csv", "Figure_2_Timing_Densities.csv"])
        self.assertEqual(MODULE.register_figure2_densities(registered, self.densities), registered)
        method = registered["figures"][0]["density_method"]
        self.assertEqual(method["bandwidth_days"], 5)
        self.assertFalse(method["renormalized_within_display"])

    def test_tampered_available_denominator_rejected(self):
        self.densities["rows"][0][3] = 9
        with self.assertRaisesRegex(ValueError, "denominators disagree"):
            MODULE.register_figure2_densities(self.manifest, self.densities)

    def test_negative_density_rejected(self):
        self.densities["rows"][0][2] = -0.1
        with self.assertRaisesRegex(ValueError, "finite and nonnegative"):
            MODULE.register_figure2_densities(self.manifest, self.densities)

    def test_tampered_grid_rejected(self):
        self.densities["rows"][5][1] = 5.5
        with self.assertRaisesRegex(ValueError, "ordered daily grid"):
            MODULE.register_figure2_densities(self.manifest, self.densities)

    def test_individual_field_schema_rejected(self):
        self.densities["columns"].append("case_id")
        with self.assertRaisesRegex(ValueError, "aggregate density-grid schema"):
            MODULE.register_figure2_densities(self.manifest, self.densities)


class TotalCohortFrequencyTests(unittest.TestCase):
    def setUp(self):
        self.frequency = MODULE.input_object("Flare_Frequency_Total_Cohort.csv",
            ["population", "flare_cases", "total_courses", "percent", "lower_95_percent", "upper_95_percent", "ci_method"],
            [{"population":"Total cohort", "flare_cases":"2", "total_courses":"40", "percent":"5",
              "lower_95_percent":"0.5", "upper_95_percent":"18", "ci_method":"Clopper-Pearson exact binomial (95%)"}])
        self.manifest = {"aggregate_inputs":[
            MODULE.input_object("flow.csv", ["stage","courses"],
                [{"stage":"Total cohort","courses":"40"}, {"stage":"Clinical series after secondary review","courses":"2"}]),
            {"filename":"incidence.csv","columns":[],"rows":[]},
            {"filename":"other.csv","columns":["value"],"rows":[["unchanged"]]}],
            "figures":[{"label":"Figure 1","aggregate_files":["flow.csv","incidence.csv"],"code_files":[],"image_data_url":"unchanged"}]}
    def test_frequency_replacement_preserves_other_objects(self):
        result=MODULE.register_total_cohort_frequency(self.manifest,self.frequency)
        self.assertEqual(result["aggregate_inputs"][0],self.manifest["aggregate_inputs"][0])
        self.assertEqual(result["aggregate_inputs"][2],self.manifest["aggregate_inputs"][2])
        self.assertEqual(result["aggregate_inputs"][1],self.frequency)
        self.assertEqual(result["figures"][0]["image_data_url"],"unchanged")
        self.assertNotIn("incidence.csv",result["figures"][0]["aggregate_files"])
    def test_frequency_conflicting_flow_rejected(self):
        self.manifest["aggregate_inputs"][0]["rows"][1][1]="3"
        with self.assertRaises(ValueError): MODULE.register_total_cohort_frequency(self.manifest,self.frequency)
    def test_frequency_invalid_counts_rejected(self):
        for value in ("-1","2.5","nan","50"):
            bad=copy.deepcopy(self.frequency);bad["rows"][0][1]=value
            with self.assertRaises(ValueError): MODULE.register_total_cohort_frequency(self.manifest,bad)
    def test_frequency_individual_schema_rejected(self):
        self.frequency["columns"].append("case_id")
        with self.assertRaises(ValueError): MODULE.register_total_cohort_frequency(self.manifest,self.frequency)


class RAINFrameworkRegistrationTests(unittest.TestCase):
    def setUp(self):
        columns = ["stage", "element_id", "heading", "text"]
        self.content = MODULE.input_object("Figure_5_RAIN_Content.csv", columns,
            [{"stage": stage, "element_id": "heading", "heading": heading, "text": "Synthetic framework text"}
             for stage, heading in zip("RAIN", ("Recognize", "Assess", "Integrate", "Next steps"))])
        self.manifest = {"aggregate_inputs": [{"filename": "synthetic.csv", "columns": ["n"], "rows": [["5"]]}],
            "tables": [{"label": "Synthetic unchanged"}], "figures": [
                {"label": "Figure 5", "aggregate_files": [], "code_files": ["Publication/build_figures.R"], "caption": "Unchanged caption"},
                {"label": "Figure 1", "caption": "Unchanged other figure"}]}
        self.production = {"export_inches": [8.5, 7.45], "font_family": "Helvetica"}

    def test_registration_preserves_analytical_inputs_and_other_displays(self):
        result = MODULE.register_figure5_rain(self.manifest, self.content, self.production)
        self.assertEqual(result["aggregate_inputs"][:-1], self.manifest["aggregate_inputs"])
        self.assertEqual(result["tables"], self.manifest["tables"])
        self.assertEqual(result["figures"][1], self.manifest["figures"][1])
        self.assertEqual(result["figures"][0]["caption"], "Unchanged caption")
        self.assertEqual(self.manifest["figures"][0]["aggregate_files"], [])

    def test_registration_is_idempotent_and_not_validated(self):
        result = MODULE.register_figure5_rain(self.manifest, self.content, self.production)
        self.assertEqual(MODULE.register_figure5_rain(result, self.content, self.production), result)
        registration = result["figures"][0]["framework_registration"]
        self.assertFalse(registration["formal_consensus"])
        self.assertFalse(registration["diagnostic_validation"])

    def test_connections_preserve_forward_order_and_reassessment(self):
        result = MODULE.register_figure5_rain(self.manifest, self.content, self.production)
        links = result["figures"][0]["framework_registration"]["connections"]
        self.assertEqual([(link["source"], link["target"]) for link in links], [("R", "A"), ("A", "I"), ("I", "N"), ("N", "I")])
        self.assertEqual(links[-1]["label"], "Repeat assessment")

    def test_missing_stage_rejected(self):
        self.content["rows"].pop()
        with self.assertRaisesRegex(ValueError, "all four stages"):
            MODULE.register_figure5_rain(self.manifest, self.content, self.production)

    def test_duplicate_element_rejected(self):
        self.content["rows"].append(self.content["rows"][0])
        with self.assertRaisesRegex(ValueError, "uniquely identified"):
            MODULE.register_figure5_rain(self.manifest, self.content, self.production)

    def test_blank_element_rejected(self):
        self.content["rows"][0][2:] = ["", ""]
        with self.assertRaisesRegex(ValueError, "contain text"):
            MODULE.register_figure5_rain(self.manifest, self.content, self.production)

    def test_individual_field_schema_rejected(self):
        self.content["columns"].append("case_id")
        with self.assertRaisesRegex(ValueError, "stage, element_id"):
            MODULE.register_figure5_rain(self.manifest, self.content, self.production)

    def test_duplicate_registered_object_rejected(self):
        self.manifest["aggregate_inputs"] += [self.content, self.content]
        with self.assertRaisesRegex(ValueError, "more than once"):
            MODULE.register_figure5_rain(self.manifest, self.content, self.production)



class SupplementaryOrderTests(unittest.TestCase):
    def test_registered_order_is_idempotent_and_preserves_values(self):
        before = MODULE.consolidate_manifest(selected_fixture(), SELECTION)
        after = MODULE.apply_supplementary_table_order(before, SELECTION)
        self.assertEqual(MODULE.apply_supplementary_table_order(after, SELECTION), after)
        tables = {t["label"]: t for t in after["tables"]}
        self.assertEqual(tables["Table S2"]["content_id"], "baseline_response_associations")
        self.assertEqual(tables["Table S3"]["content_id"], "comparative_response_immune_toxicities")
        originals = {t["label"]: t for t in before["tables"]}
        self.assertEqual(tables["Table S2"]["panels"], originals["Table S3"]["panels"])
        self.assertEqual(tables["Table S3"]["panels"], originals["Table S2"]["panels"])
        self.assertEqual(after["figures"], before["figures"])
        self.assertTrue(MODULE.verify_consolidation(selected_fixture(), after, SELECTION)["passed"])
        inputs = {i["filename"]: i for i in after["aggregate_inputs"]}
        for t in after["tables"]:
            for name in t["aggregate_files"]:
                self.assertIn(name, inputs)

    def test_retired_onset_note_is_removed_without_other_note_changes(self):
        before = MODULE.consolidate_manifest(selected_fixture(), SELECTION)
        table = next(t for t in before["tables"] if t["label"] == "Table S4")
        original = list(table["panels"][0]["notes"])
        table["panels"][0]["notes"].append("Alternative onset sensitivity placeholder")
        after = MODULE.apply_supplementary_table_order(before, SELECTION)
        result = next(t for t in after["tables"] if t["label"] == "Table S4")
        self.assertEqual(result["panels"][0]["notes"], original)

    def test_inconsistent_registered_identity_is_rejected(self):
        before = MODULE.consolidate_manifest(selected_fixture(), SELECTION)
        after = MODULE.apply_supplementary_table_order(before, SELECTION)
        table = next(t for t in after["tables"] if t["label"] == "Table S2")
        table["content_id"] = "comparative_response_immune_toxicities"
        with self.assertRaises(ValueError):
            MODULE.apply_supplementary_table_order(after, SELECTION)


class Figure3StatusTests(unittest.TestCase):
    def rows(self, categories):
        return [{"panel": "A", "field": "x", "label": "Synthetic", "category": c, "n": n, "denominator": 10}
                for c, n in categories]

    def test_unknown_and_not_applicable_are_summed(self):
        result = MODULE.collapse_figure3_statuses(self.rows([("Yes", 4), ("No", 3), ("Unknown", 1), ("Not applicable", 2)]))
        self.assertEqual([(r["category"], r["n"], r["percent"]) for r in result], [("Yes", 4, 40), ("No", 3, 30), ("Unknown", 3, 30)])

    def test_only_not_applicable_becomes_unknown(self):
        result = MODULE.collapse_figure3_statuses(self.rows([("Yes", 4), ("No", 3), ("Not applicable", 3)]))
        self.assertEqual(result[-1]["category"], "Unknown")
        self.assertEqual(result[-1]["n"], 3)

    def test_already_combined_input_is_idempotent(self):
        result = MODULE.collapse_figure3_statuses(self.rows([("Yes", 4), ("No", 3), ("Unknown", 3)]))
        self.assertEqual(MODULE.collapse_figure3_statuses(result), result)

    def test_input_rows_are_not_modified(self):
        rows = self.rows([("Yes", 4), ("No", 3), ("Not applicable", 3)])
        before = copy.deepcopy(rows)
        MODULE.collapse_figure3_statuses(rows)
        self.assertEqual(rows, before)

    def test_nonconservation_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "conserve"):
            MODULE.collapse_figure3_statuses(self.rows([("Yes", 4), ("No", 3)]))

    def test_denominator_mismatch_is_rejected(self):
        rows = self.rows([("Yes", 4), ("No", 3), ("Unknown", 3)])
        rows[-1]["denominator"] = 11
        with self.assertRaisesRegex(ValueError, "Inconsistent"):
            MODULE.collapse_figure3_statuses(rows)

    def test_invalid_category_is_rejected(self):
        with self.assertRaisesRegex(ValueError, "Unexpected"):
            MODULE.collapse_figure3_statuses(self.rows([("Yes", 4), ("No", 3), ("Unrecognized", 3)]))

    def test_registration_preserves_shared_inputs_and_other_displays(self):
        manifest = selected_fixture()
        config = SELECTION["display_registration_updates"]["figure3_statuses"]
        result = MODULE.register_figure3_statuses(manifest, config)
        self.assertEqual(result["aggregate_inputs"][:-1], manifest["aggregate_inputs"])
        self.assertEqual(result["tables"], manifest["tables"])
        self.assertEqual([f for f in result["figures"] if f["label"] != "Figure 3"], [f for f in manifest["figures"] if f["label"] != "Figure 3"])
        self.assertEqual(MODULE.register_figure3_statuses(result, config), result)
        self.assertEqual(result["aggregate_inputs"][-1]["columns"], ["panel", "field", "label", "category", "n", "denominator", "percent"])
        self.assertEqual(next(f for f in result["figures"] if f["label"] == "Figure 3")["aggregate_files"], ["Figure_3_Statuses.csv"])

class ImmuneRegistrationTests(unittest.TestCase):
    def setUp(self):
        import math
        self.config = SELECTION['display_registration_updates']['table_s3_immune']
        rows=[]; displayed=[]
        beta,lower,upper,stat=.6,-.3,1.7,2.5
        for spec in self.config['models']:
            rows.append(dict(field=spec['field'],characteristic=spec['label'],model_id=spec['model_id'],
                flare_events=5,flare_evaluable=10,comparison_events=2,comparison_evaluable=12,
                n_courses=22,n_patient_clusters=20,log_odds=beta,log_ci_low=lower,log_ci_high=upper,
                odds_ratio=math.exp(beta),conf_low=math.exp(lower),conf_high=math.exp(upper),
                p_value=math.erfc(math.sqrt(stat/2)),full_loglik=-12,restricted_loglik=-13.25,
                plr_statistic=stat,plr_df=1,point_converged=True,profile_converged=True,plr_converged=True,
                inference_schema=self.config['inference_schema'],method=self.config['method']))
            displayed.append({'kind':'row','cells':[spec['label'],'5/10 (50.0%)','2/12 (16.7%)','0.2']})
        columns=list(rows[0])
        self.full={'tables':[{'label':'Table S3','title':'Comparative response and immune toxicities',
            'content_id':self.config['content_id'],'panels':[{'headers':['Synthetic'],'rows':[]},
            {'headers':['Characteristic','Flare','No flare','P value'],'rows':displayed}],
            'caption':'CRS, ICANS, and treatment tocilizumab use evaluable denominators and two-sided Fisher exact tests in the primary population. These exploratory comparisons do not account for repeated courses within patients or establish temporal order or causation. CR, complete response; MR, minimal response;',
            'aggregate_files':['Table_S3_Panel_B.csv'],'code_files':[]}],
            'figures':[{'label':'Synthetic figure'}],
            'aggregate_inputs':[MODULE.input_object(self.config['aggregate_filename'],columns,rows),
                {'filename':'Table_S3_Panel_B.csv','columns':[],'rows':[]}]}
    def mutate(self,key,value):
        raw=self.full['aggregate_inputs'][0];raw['rows'][0][raw['columns'].index(key)]=value
    def test_five_columns_and_matching_inference(self):
        result=MODULE.register_table_s3_immune(self.full,self.config)
        panel=result['tables'][0]['panels'][1]
        self.assertEqual(panel['headers'][-2:],['OR (95% CI)','P value'])
        self.assertEqual(panel['rows'][0]['cells'][-2:],['1.82 (0.74–5.47)','0.1138'])
    def test_idempotence(self):
        result=MODULE.register_table_s3_immune(self.full,self.config)
        self.assertEqual(MODULE.register_table_s3_immune(result,self.config),result)
    def test_panel_a_figures_and_source_preserved(self):
        before=copy.deepcopy(self.full);result=MODULE.register_table_s3_immune(self.full,self.config)
        self.assertEqual(self.full,before)
        self.assertEqual(result['tables'][0]['panels'][0],before['tables'][0]['panels'][0])
        self.assertEqual(result['figures'],before['figures'])
    def test_mismatched_p_rejected(self):
        self.mutate('p_value',.2)
        with self.assertRaisesRegex(ValueError,'penalized likelihood'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_unconverged_profile_rejected(self):
        self.mutate('profile_converged',False)
        with self.assertRaisesRegex(ValueError,'must converge'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_profile_bounds_must_match_log_bounds(self):
        self.mutate('conf_low',.7)
        with self.assertRaisesRegex(ValueError,'penalized likelihood'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_profile_allows_asymmetric_interval(self):
        result=MODULE.register_table_s3_immune(self.full,self.config)
        self.assertIn('0.74–5.47',result['tables'][0]['panels'][1]['rows'][0]['cells'][3])
    def test_wrong_profile_method_rejected(self):
        self.mutate('method','Wald')
        with self.assertRaisesRegex(ValueError,'method or schema'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_retired_seed_field_rejected(self):
        raw=self.full['aggregate_inputs'][0];raw['columns'].append('seed')
        for row in raw['rows']:row.append(81)
        with self.assertRaisesRegex(ValueError,'Retired bootstrap'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_likelihood_statistic_mismatch_rejected(self):
        self.mutate('restricted_loglik',-14)
        with self.assertRaisesRegex(ValueError,'penalized likelihood'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_counts_must_match_display(self):
        self.mutate('flare_events',4)
        with self.assertRaisesRegex(ValueError,'displayed counts'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_missing_registration_cannot_restore_fisher(self):
        self.full['aggregate_inputs']=self.full['aggregate_inputs'][1:]
        with self.assertRaisesRegex(ValueError,'restricted courses'):MODULE.register_table_s3_immune(self.full,self.config)
    def test_duplicate_model_rejected(self):
        self.full['aggregate_inputs'][0]['rows'].append(self.full['aggregate_inputs'][0]['rows'][0])
        with self.assertRaisesRegex(ValueError,'once each'):MODULE.register_table_s3_immune(self.full,self.config)


class FigureLayoutFontTests(unittest.TestCase):
    def setUp(self):
        self.fonts = SELECTION['display_registration_updates']['figure_layout_fonts']
        self.associations = SELECTION['display_registration_updates']['figure4_associations']
        self.before = {'figures': [dict(label=label, title='Synthetic title', caption='Synthetic caption',
            image_data_url='Synthetic image', aggregate_files=[], code_files=[])
            for label in ['Figure 1', 'Figure 2', 'Figure 3', 'Figure 4', 'Figure 5', 'Figure S1']],
            'tables': [{'label': 'Synthetic table', 'cells': ['1.23 (0.45–3.21)', '0.4567']}],
            'aggregate_inputs': [{'filename': 'synthetic.csv', 'columns': ['estimate'], 'rows': [['1.23456789']]}]}

    def registered(self):
        return MODULE.register_figure_layout_fonts(
            MODULE.register_figure4_associations(self.before, self.associations), self.fonts)

    def test_registration_changes_no_stats_or_other_figures(self):
        after = self.registered()
        self.assertEqual(after['tables'], self.before['tables'])
        self.assertEqual(after['aggregate_inputs'], self.before['aggregate_inputs'])
        for old, new in zip(self.before['figures'], after['figures']):
            self.assertEqual(new['image_data_url'], old['image_data_url'])
            if old['label'] not in ['Figure 3', 'Figure 4']:
                self.assertEqual(new, old)

    def test_fonts_match_at_the_same_physical_word_width(self):
        after = self.registered()
        productions = [f['production'] for f in after['figures'] if f['label'] in ['Figure 3', 'Figure 4']]
        self.assertEqual(productions[0]['word_font_roles'], productions[1]['word_font_roles'])
        self.assertAlmostEqual(productions[0]['word_font_roles']['label_pt'], 9.2 * 6.5 / 7.2)
        self.assertAlmostEqual(productions[0]['word_font_roles']['panel_title_pt'], 11 * 6.5 / 7.2)
        self.assertEqual([p['export_inches'] for p in productions], [[9.5, 10], [12, 11]])

    def test_exact_panel_sizes_and_only_requested_immune_models(self):
        figure = next(f for f in self.registered()['figures'] if f['label'] == 'Figure 4')
        panels = figure['association_registration']['panels']
        self.assertEqual([len(p['model_ids']) for p in panels], [6, 2, 3, 2])
        self.assertEqual(panels[1]['model_ids'], ['primary_immune_crs_unadjusted', 'primary_immune_icans_unadjusted'])
        self.assertEqual(panels[3]['model_ids'], ['primary_survival_pfs_adjusted', 'primary_survival_os_adjusted'])
        self.assertFalse(figure['association_registration']['model_refitting'])
        self.assertIn('Table_S3_Immune_Associations.csv', figure['aggregate_files'])

    def test_registration_is_idempotent(self):
        after = self.registered()
        again = MODULE.register_figure_layout_fonts(MODULE.register_figure4_associations(after, self.associations), self.fonts)
        self.assertEqual(again, after)

    def test_duplicate_model_id_rejected(self):
        config = copy.deepcopy(self.associations)
        config['panels'][1]['model_ids'][0] = config['panels'][0]['model_ids'][0]
        with self.assertRaisesRegex(ValueError, 'unique'):
            MODULE.register_figure4_associations(self.before, config)

    def test_typography_cannot_change_figure2(self):
        config = copy.deepcopy(self.fonts)
        config['figures'][0]['label'] = 'Figure 2'
        with self.assertRaisesRegex(ValueError, 'Only Figure 3 and Figure 4'):
            MODULE.register_figure_layout_fonts(self.before, config)


class CoxPHRegistrationTests(unittest.TestCase):
    def setUp(self):
        self.config = SELECTION['display_registration_updates']['cox_ph_diagnostics']
        rows = []
        for scenario in ['primary', 'strict', 'without_dominant_site']:
            for endpoint in ['PFS', 'OS']:
                for model in ['Unadjusted: all eligible', 'Unadjusted: adjusted subset', 'Adjusted: six baseline variables']:
                    adjusted = model.startswith('Adjusted')
                    flare_stat = 6 if scenario == 'strict' and model != 'Unadjusted: all eligible' else .2
                    global_stat = (25 if scenario == 'strict' else 20) if adjusted else flare_stat
                    global_df = 7 if adjusted else 1
                    rows.append(dict(scenario=scenario, endpoint=endpoint, model=model,
                        n_courses=20, n_patient_clusters=18, exposed_courses=4, unexposed_courses=16,
                        courses_with_unexposed_time=20, events=10, exposed_events=3, unexposed_events=7,
                        total_model_eligible_courses=20, excluded_missing=0,
                        ph_global_chisq=global_stat, ph_global_df=global_df,
                        ph_global_p=MODULE.ph_score_p_value(global_stat, global_df),
                        ph_flare_chisq=flare_stat, ph_flare_df=1,
                        ph_flare_p=MODULE.ph_score_p_value(flare_stat, 1),
                        ph_method='survival::cox.zph; model-based score diagnostic', ph_transform='km',
                        ph_status='computed', ph_warning_count=0, ph_diagnostic='',
                        ph_finite_transformed_times_and_residuals='TRUE', ph_test_patient_cluster_robust='FALSE'))
        self.diagnostics = MODULE.input_object('cox_ph_diagnostics.csv', list(MODULE.COX_PH_COLUMNS), rows)
        selected = [r for r in rows if r['scenario'] == 'primary' or r['model'].startswith('Adjusted')]
        selected = [dict(r, estimate='1.23456789', conf_low='.22', conf_high='5.67', p_value='.29')
                    for r in selected]
        self.before = {'tables': [{'label': 'Table S4', 'caption': 'Synthetic prior caption',
            'code_files': [], 'aggregate_files': ['survival_models.csv'],
            'panels': [{'headers': ['a','b','c','d','e','f'],
                'rows': [{'cells': ['Synthetic'] * 6, 'object_id': str(i)} for i in range(10)],
                'notes': ['PH global/flare P values for adjusted models: old. PH diagnostics were unavailable for the other models.',
                          'Synthetic endpoint availability note.']},
                {'headers': ['a','b','c','d','e','f'],
                 'rows': [{'cells': ['Synthetic'] * 6, 'object_id': str(i)} for i in range(4)]}]}],
            'aggregate_inputs': [MODULE.input_object('survival_models.csv', list(selected[0]), selected)],
            'shared_sections': [{'title': 'Time-dependent survival, follow-up, and sensitivity analyses',
                                 'code_files': ['Code/survival_functions.R']}]}

    def register(self):
        return MODULE.register_cox_ph_diagnostics(self.before, self.diagnostics, self.config)

    def mutate(self, key, value):
        self.diagnostics['rows'][0][self.diagnostics['columns'].index(key)] = value

    def test_all_18_diagnostics_without_association_or_individual_columns(self):
        result = self.register()
        sidecar = next(i for i in result['aggregate_inputs'] if i['filename'] == 'cox_ph_diagnostics.csv')
        self.assertEqual(len(sidecar['rows']), 18)
        self.assertFalse({'estimate','conf_low','conf_high','p_value','patient_id','course_id'} & set(sidecar['columns']))
        self.assertIn('cox_ph_diagnostics.csv', result['tables'][0]['aggregate_files'])

    def test_existing_14_rows_and_six_columns_and_associations_are_exact(self):
        result = self.register()
        for old, new in zip(self.before['tables'][0]['panels'], result['tables'][0]['panels']):
            self.assertEqual(new['headers'], old['headers'])
            self.assertEqual(new['rows'], old['rows'])
        self.assertEqual(result['aggregate_inputs'][0], self.before['aggregate_inputs'][0])
        self.assertEqual(result['tables'][0]['panels'][0]['notes'][-1], 'Synthetic endpoint availability note.')

    def test_notes_disclose_model_based_method_and_no_proof_from_nonsignificance(self):
        notes = ' '.join(self.register()['tables'][0]['panels'][0]['notes'])
        self.assertIn('model-based', notes)
        self.assertIn('patient-cluster robust variance', notes)
        self.assertIn('Non-significant tests do not establish proportional hazards', notes)
        self.assertIn('not evaluated for landmark', notes)
        self.assertNotIn('unavailable for the other models', notes)

    def test_registration_is_idempotent_and_input_is_not_mutated(self):
        old = copy.deepcopy(self.before)
        after = self.register()
        self.assertEqual(self.before, old)
        self.assertEqual(MODULE.register_cox_ph_diagnostics(after, self.diagnostics, self.config), after)

    def test_extra_association_field_is_rejected(self):
        self.diagnostics['columns'].append('estimate')
        for r in self.diagnostics['rows']:
            r.append(1.23)
        with self.assertRaisesRegex(ValueError, 'aggregate-only schema'):
            self.register()

    def test_duplicate_or_missing_population_is_rejected(self):
        self.diagnostics['rows'][0] = copy.deepcopy(self.diagnostics['rows'][1])
        with self.assertRaisesRegex(ValueError, '18 unique'):
            self.register()

    def test_cluster_robust_ph_claim_is_rejected(self):
        self.mutate('ph_test_patient_cluster_robust', 'TRUE')
        with self.assertRaisesRegex(ValueError, 'model-based KM'):
            self.register()

    def test_wrong_score_p_value_is_rejected(self):
        self.mutate('ph_global_p', .99)
        with self.assertRaisesRegex(ValueError, 'score statistic'):
            self.register()

    def test_unavailable_diagnostics_cannot_support_reported_values(self):
        self.mutate('ph_status', 'failed')
        with self.assertRaisesRegex(ValueError, 'availability'):
            self.register()


if __name__ == "__main__":
    unittest.main()
