#!/usr/bin/env python3
"""Focused synthetic checks for aggregate clinical presentation selection."""
import copy
import importlib.util
import json
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parent
SPEC = importlib.util.spec_from_file_location("streamline", ROOT / "streamline_publication_manifest.py")
MODULE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(MODULE)
SELECTION = json.loads((ROOT / "clinical_presentation_selection.json").read_text())
GROUPS = ("All", "Definite/Probable", "Possible")
TOTALS = (10, 6, 4)
COLUMNS = ["panel", "field", "characteristic", "category", "group", "n", "total_n", "evaluable_n", "denominator", "percent", "available_n", "median", "q1", "q3"]


def fixture():
    """Synthetic fields exercise missingness and formatting without clinical data."""
    rows, seen = [], set()
    for panel in SELECTION["clinical_panels"]:
        for section in panel["sections"]:
            for spec in section["fields"]:
                field = spec["field"]
                if field in seen:
                    continue
                seen.add(field)
                if spec["mode"] == "timing":
                    for group, total, available in zip(GROUPS, TOTALS, (8, 5, 3)):
                        rows.append({"panel": "A", "field": field, "characteristic": spec["label"], "category": "Median (IQR)", "group": group, "n": "", "total_n": str(total), "evaluable_n": str(available), "denominator": str(available), "percent": "", "available_n": str(available), "median": "2", "q1": "1", "q3": "3"})
                    continue
                if spec["mode"] == "selected_category":
                    values = {"Recorded date": (7, 4, 3), "Estimated date": (2, 1, 1), "Interval only": (1, 1, 0)} if field == "onset_days_availability" else {"Recorded date": (6, 4, 2), "Estimated date": (2, 1, 1), "Unavailable": (2, 1, 1)}
                elif spec["mode"] == "binary":
                    values = {"Yes": (4, 2, 2), "No": (2, 2, 0), "Blank": (1, 1, 0), "Unknown": (1, 1, 0), "Not applicable": (1, 0, 1), "Not reported": (1, 0, 1)}
                else:
                    values = {"Category A": (6, 4, 2), "Category B": (2, 1, 1), "Unknown": (1, 1, 0), "Not applicable": (1, 0, 1)}
                for category, counts in values.items():
                    for group, total, count in zip(GROUPS, TOTALS, counts):
                        rows.append({"panel": "synthetic", "field": field, "characteristic": spec["label"], "category": category, "group": group, "n": str(count), "total_n": str(total), "evaluable_n": str(total), "denominator": str(total), "percent": str(100 * count / total), "available_n": "", "median": "", "q1": "", "q3": ""})
    return {"aggregate_inputs": [MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)]}


class AggregateSelectionTests(unittest.TestCase):
    def setUp(self):
        self.full = fixture()
        self.panels, self.raw = MODULE.build_clinical_panels(self.full, SELECTION)

    def clinical_row(self, field):
        return next(row for panel in self.panels for row in panel["rows"] if row.get("field") == field and row["kind"] != "group")

    def test_denominators_come_from_inputs(self):
        self.assertEqual(self.panels[0]["headers"], ["Characteristic", "All cases (N = 10)", "Definite/Probable (N = 6)", "Possible (N = 4)"])

    def test_all_panels_have_identical_headers(self):
        self.assertTrue(all(panel["headers"] == self.panels[0]["headers"] for panel in self.panels))

    def test_binary_positive_count_keeps_group_denominator(self):
        self.assertTrue(self.clinical_row("overlap_infection")["cells"][1].startswith("4/10 (40.0%)"))

    def test_binary_no_state_is_not_displayed(self):
        self.assertNotIn("No:", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_blank_is_separate_cell_line(self):
        self.assertIn("\nBlank: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_unknown_is_separate_cell_line(self):
        self.assertIn("\nUnknown: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_not_applicable_is_separate_cell_line(self):
        self.assertIn("\nNot applicable: 1/10 (10.0%)", self.clinical_row("overlap_infection")["cells"][1])

    def test_nonzero_not_reported_is_separate_cell_line(self):
        self.assertIn("\nNot reported: 1/10 (10.0%)", self.clinical_row("later_local_after_cart")["cells"][1])

    def test_zero_missing_states_are_omitted_from_binary_cells(self):
        self.assertNotIn("Not reported:", self.clinical_row("later_local_after_cart")["cells"][2])

    def test_categorical_states_are_not_collapsed(self):
        rows = [row for row in self.panels[1]["rows"] if row.get("field") == "ctcae_pain_grade" and row["kind"] == "category"]
        self.assertEqual([row["cells"][0] for row in rows], ["Category A", "Category B", "Unknown", "Not applicable"])

    def test_categorical_zero_missing_states_remain_visible(self):
        row = next(row for row in self.panels[1]["rows"] if row.get("field") == "ctcae_pain_grade" and row["cells"][0] == "Not applicable")
        self.assertEqual(row["cells"][2], "0/6 (0.0%)")

    def test_timing_uses_available_denominator(self):
        self.assertEqual(self.clinical_row("onset_days")["cells"][1:], ["2 (1–3); n = 8", "2 (1–3); n = 5", "2 (1–3); n = 3"])

    def test_interval_has_no_midpoint(self):
        row = next(row for row in self.panels[0]["rows"] if row["cells"][0] == "Onset interval without a date")
        self.assertEqual(row["cells"][1], "1/10 (10.0%)")
        self.assertNotIn("midpoint", str(row))

    def test_absent_interval_category_is_not_displayed(self):
        full = fixture()
        rows = MODULE.input_rows(full["aggregate_inputs"][0])
        rows = [row for row in rows if not (row["field"] == "onset_days_availability" and row["category"] == "Interval only")]
        full["aggregate_inputs"][0] = MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)
        panels, selected = MODULE.build_clinical_panels(full, SELECTION)
        self.assertFalse(any(row["cells"][0] == "Onset interval without a date" for panel in panels for row in panel["rows"]))
        self.assertFalse(any(row["category"] == "Interval only" for row in MODULE.input_rows(selected)))

    def test_zero_interval_category_is_not_displayed(self):
        full = fixture()
        rows = MODULE.input_rows(full["aggregate_inputs"][0])
        for row in rows:
            if row["field"] == "onset_days_availability" and row["category"] == "Interval only":
                row["n"], row["percent"] = "0", "0"
        full["aggregate_inputs"][0] = MODULE.input_object("Table_S1_Aggregate.csv", COLUMNS, rows)
        panels, _ = MODULE.build_clinical_panels(full, SELECTION)
        self.assertFalse(any(row["cells"][0] == "Onset interval without a date" for panel in panels for row in panel["rows"]))

    def test_recorded_dates_not_in_selected_uncertainty_rows(self):
        rows = MODULE.input_rows(self.raw)
        self.assertFalse(any(row["category"] == "Recorded date" for row in rows))

    def test_unavailable_resolution_not_changed_to_ongoing(self):
        row = self.clinical_row("resolution_days_availability")
        self.assertIn("Unavailable: 2/10 (20.0%)", row["cells"][1])
        self.assertNotIn("ongoing", str(row).lower())

    def test_selected_inputs_are_subset_of_original_rows(self):
        original = MODULE.input_rows(self.full["aggregate_inputs"][0])
        self.assertTrue(all(row in original for row in MODULE.input_rows(self.raw)))

    def test_repeated_field_selection_does_not_duplicate_inputs(self):
        rows = MODULE.input_rows(self.raw)
        keys = [(row["field"], row["category"], row["group"]) for row in rows]
        self.assertEqual(len(keys), len(set(keys)))

    def test_group_nonconservation_rejected(self):
        full = copy.deepcopy(self.full)
        i = COLUMNS.index("total_n")
        for row in full["aggregate_inputs"][0]["rows"]:
            if row[COLUMNS.index("group")] == "All":
                row[i] = "11"
        with self.assertRaisesRegex(ValueError, "do not conserve"):
            MODULE.build_clinical_panels(full, SELECTION)

    def test_inconsistent_group_denominator_rejected(self):
        self.full["aggregate_inputs"][0]["rows"][0][COLUMNS.index("total_n")] = "11"
        with self.assertRaisesRegex(ValueError, "inconsistent denominators"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_missing_selected_field_rejected(self):
        self.full["aggregate_inputs"][0]["rows"] = [row for row in self.full["aggregate_inputs"][0]["rows"] if row[COLUMNS.index("field")] != "overlap_crs"]
        with self.assertRaisesRegex(ValueError, "Missing clinical field"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_duplicate_aggregate_row_rejected(self):
        self.full["aggregate_inputs"][0]["rows"].append(self.full["aggregate_inputs"][0]["rows"][0])
        with self.assertRaisesRegex(ValueError, "Expected one aggregate row"):
            MODULE.build_clinical_panels(self.full, SELECTION)

    def test_rendered_csv_has_indented_categories_and_matching_widths(self):
        item = MODULE.table_input("synthetic.csv", self.panels[0])
        self.assertTrue(item["rows"][1][0].startswith("  "))
        self.assertTrue(all(len(row) == len(item["columns"]) for row in item["rows"]))

    def test_generic_selection_has_no_empirical_counts_or_estimates(self):
        forbidden = {"n", "count", "counts", "estimate", "conf_low", "conf_high", "median", "q1", "q3", "total_n"}
        def keys(value):
            if isinstance(value, dict):
                for key, child in value.items():
                    yield key
                    yield from keys(child)
            elif isinstance(value, list):
                for child in value:
                    yield from keys(child)
        self.assertFalse(forbidden & set(keys(SELECTION)))

    def test_author_group_label_updated(self):
        table = {"label": "Table 2", "panels": [{"rows": [{"kind": "group", "cells": ["Best systemic BsAb response"]}, {"kind": "category", "cells": ["CR", "2/10 (20.0%)", "1/6 (16.7%)", "1/4 (25.0%)"]}]}]}
        updated = MODULE.apply_main_table_labels(copy.deepcopy(table), SELECTION)
        self.assertEqual(updated["panels"][0]["rows"][0]["cells"][0], "Best response to BsAb treatment")
        self.assertEqual(updated["panels"][0]["rows"][1], table["panels"][0]["rows"][1])

    def test_author_label_changes_do_not_touch_other_tables(self):
        table = {"label": "Table S1", "panels": [{"rows": [{"kind": "group", "cells": ["Best systemic BsAb response"]}]}]}
        self.assertEqual(MODULE.apply_main_table_labels(copy.deepcopy(table), SELECTION), table)


if __name__ == "__main__":
    unittest.main()
