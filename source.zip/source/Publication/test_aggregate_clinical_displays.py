#!/usr/bin/env python3
"""Execution and privacy checks using entirely invented clinical fixtures."""
import argparse
import copy
import csv
import json
import tempfile
import unittest
from collections import Counter
from pathlib import Path
import aggregate_clinical_displays as module


def fixture():
    confidence = ["Definite", "Probable", "Possible", "Definite", "Possible"]
    cases, timeline, context = [], [], []
    for i, conf in enumerate(confidence):
        row = {"case_id": f"DEMO{i+1}", "investigator_confidence": conf,
               "bsab_product": "Teclistamab", "bridging_any": "FALSE",
               "comparative_included": "TRUE", "dosing_phase_at_onset": "Step-up dosing",
               "pain_flare": "Yes" if i in [0, 2, 3] else "No",
               "organ_dysfunction": "Yes" if i in [0, 2] else "No",
               "palpable_enlargement": ["Yes", "Unknown", "No", "", "Not applicable"][i],
               "true_emd_classification": ["No true EMD", "Unknown", "Not applicable", "Visceral EMD (organ involvement)", "Unknown"][i],
               "first_response_on_index": "TRUE", "subsequent_response_on_index": "FALSE"}
        for field in ["management_steroids", "management_radiation", "management_surgery", "management_toci_anakinra",
                      "management_nonopioid", "management_opioids", "improved_while_bsab_continued"]:
            row[field] = "Unknown" if i == 2 else "Yes" if i in [0, 3] else "No"
        row.update({"bsab_action": "Continued without interruption", "resolution_status": ["Resolved", "Unknown", "Resolved", "Ongoing/not improved", "Resolved"][i],
                    "local_lesion_outcome": "Unknown" if i == 2 else "Improved",
                    "first_postflare_response": "Unknown" if i == 2 else "PR",
                    "subsequent_response": "No subsequent response documented",
                    "best_index_response": "NE/Unknown" if i == 2 else "PR"})
        cases.append(row)
        timeline.append({"case_id": row["case_id"], "case_label": f"DEMOCASE{i+1}",
                         "onset_days": [2, 10, "", "", 45][i], "peak_days": [3, 12, 14, 5, 50][i],
                         "resolution_days": [7, "", 18, "", 60][i],
                         "onset_lower": 5 if i == 2 else "", "onset_upper": 11 if i == 2 else "",
                         "onset_estimated": "TRUE" if i == 4 else "FALSE",
                         "peak_estimated": "TRUE" if i == 1 else "FALSE", "resolution_estimated": "FALSE"})
        context.append({"case_label": f"DEMOCASE{i+1}", "first_response_category_estimated": "NOT_REPORTED",
                        "later_local_after_radiation": "YES" if i == 0 else "NOT_REPORTED",
                        "later_local_after_salvage": "NO" if i == 0 else "NOT_REPORTED",
                        "later_local_after_cart": "NO" if i == 0 else "NOT_REPORTED",
                        "later_local_separate_from_systemic_response": "YES" if i == 0 else "NOT_REPORTED"})
    groups = {"All": cases, "Definite/Probable": cases[:2] + [cases[3]], "Possible": [cases[2], cases[4]]}
    fields = ["management_steroids", "management_radiation", "management_surgery", "management_toci_anakinra",
              "management_nonopioid", "management_opioids", "bsab_action", "resolution_status", "local_lesion_outcome",
              "first_postflare_response", "subsequent_response", "best_index_response", "improved_while_bsab_continued"]
    table2 = [{"field": f, "group": g, "category": c, "n": n, "denominator": len(v)}
              for g, v in groups.items() for f in fields for c, n in Counter(module.category(x[f]) for x in v).items()]
    return cases, timeline, table2, context


class AggregateTests(unittest.TestCase):
    def setUp(self):
        self.inputs = fixture()
        self.data = module.aggregate(*self.inputs)

    def row(self, field, category, group="All"):
        return next(x for x in self.data["aggregate_rows"] if x["field"] == field and x["category"] == category and x["group"] == group)

    def test_group_totals(self):
        self.assertEqual(dict(self.data["groups"]), {"All": "All cases (N = 5)", "Definite/Probable": "Definite/Probable (N = 3)", "Possible": "Possible (N = 2)"})

    def test_categorical_conservation(self):
        fields = set(x["field"] for x in self.data["aggregate_rows"] if x["category"] != "Median (IQR)")
        for field in fields:
            for group, total in [("All", 5), ("Definite/Probable", 3), ("Possible", 2)]:
                self.assertEqual(sum(x["n"] for x in self.data["aggregate_rows"] if x["field"] == field and x["group"] == group), total)

    def test_missing_categories_separate(self):
        for cat in ["Blank", "Unknown", "Not applicable"]:
            self.assertEqual(self.row("palpable_enlargement", cat)["n"], 1)

    def test_unknown_not_negative(self):
        self.assertEqual(self.row("palpable_enlargement", "No")["n"], 1)
        self.assertEqual(self.row("palpable_enlargement", "Yes")["n"], 1)

    def test_unknown_response_unavailable(self):
        self.assertEqual(self.row("best_index_response", "NE/Unknown")["n"], 1)
        self.assertEqual(self.row("best_index_response", "PR")["n"], 4)
        self.assertEqual(self.row("best_index_response", "PR")["evaluable_n"], 4)

    def test_onset_available(self):
        self.assertEqual(self.data["timing_summaries"][0]["n"], 3)

    def test_no_interval_midpoint(self):
        self.assertEqual(self.data["timing_summaries"][0]["median"], 10)
        self.assertEqual([x["n"] for x in self.data["onset_bins"]], [1, 1, 0, 1])

    def test_interval_and_unavailable_separate(self):
        self.assertEqual(self.row("onset_days_availability", "Interval only")["n"], 1)
        self.assertEqual(self.row("onset_days_availability", "Unavailable")["n"], 1)

    def test_resolution_availability_not_status(self):
        self.assertEqual(self.data["timing_summaries"][2]["n"], 3)
        self.assertEqual(self.row("resolution_status", "Unknown")["n"], 1)
        self.assertEqual(self.row("resolution_status", "Ongoing/not improved")["n"], 1)

    def test_type7_quantiles(self):
        self.assertEqual(module.quantile([1, 2, 3, 4], 0.25), 1.75)
        self.assertEqual(module.quantile([], 0.5), None)

    def test_estimated_dates_preserved(self):
        self.assertEqual(self.row("onset_days_availability", "Estimated date")["n"], 1)
        self.assertEqual(self.row("peak_days_availability", "Estimated date")["n"], 1)

    def test_overlapping_manifestations(self):
        self.assertEqual(self.row("pain_flare", "Yes")["n"], 3)
        self.assertEqual(self.row("organ_dysfunction", "Yes")["n"], 2)

    def test_true_emd_uncertain_categories(self):
        self.assertEqual(self.row("true_emd_classification", "Unknown")["n"], 2)
        self.assertEqual(self.row("true_emd_classification", "Not applicable")["n"], 1)

    def test_context_not_reported_not_no(self):
        self.assertEqual(self.row("later_local_after_salvage", "No")["n"], 1)
        self.assertEqual(self.row("later_local_after_salvage", "Not reported")["n"], 4)
        self.assertEqual(self.row("later_local_after_salvage", "No")["evaluable_n"], 1)

    def test_management_matches_supplied(self):
        self.assertEqual(len(self.data["reused_table2_fields"]), 13)
        self.assertEqual(self.row("management_steroids", "Unknown")["n"], 1)

    def test_management_conflict_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        tab[0]["n"] += 1
        with self.assertRaises(ValueError): module.aggregate(c, t, tab, ctx)

    def test_duplicate_case_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        c[1]["case_id"] = c[0]["case_id"]
        with self.assertRaises(ValueError): module.aggregate(c, t, tab, ctx)

    def test_missing_timing_link_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        with self.assertRaises(ValueError): module.aggregate(c, t[:-1], tab, ctx)

    def test_missing_context_link_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        with self.assertRaises(ValueError): module.aggregate(c, t, tab, ctx[:-1])

    def test_unknown_confidence_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        c[0]["investigator_confidence"] = "Unclassified"
        with self.assertRaises(ValueError): module.aggregate(c, t, tab, ctx)

    def test_outside_registered_windows_rejected(self):
        c, t, tab, ctx = copy.deepcopy(self.inputs)
        t[0]["onset_days"] = 120
        with self.assertRaises(ValueError): module.aggregate(c, t, tab, ctx)

    def test_inputs_not_changed(self):
        before = copy.deepcopy(self.inputs)
        module.aggregate(*self.inputs)
        self.assertEqual(self.inputs, before)

    def test_exports_have_no_individual_fields(self):
        with tempfile.TemporaryDirectory() as temp:
            module.export(self.data, temp)
            for path in Path(temp).iterdir():
                text = path.read_text()
                self.assertNotIn("DEMOCASE", text)
                self.assertNotIn("DEMO1", text)
                self.assertNotIn('"case_id"', text)
                self.assertNotIn('"case_label"', text)

    def test_wide_csv_schema_and_group_rows(self):
        with tempfile.TemporaryDirectory() as temp:
            module.export(self.data, temp)
            with (Path(temp) / "Table_S1_Panel_A.csv").open() as handle:
                reader = csv.DictReader(handle)
                self.assertEqual(len(reader.fieldnames), 4)
                rows = list(reader)
                self.assertEqual(rows[0]["All cases (N = 5)"], "")
                self.assertTrue(rows[1]["Characteristic"].startswith("  "))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-json")
    args = parser.parse_args()
    suite = unittest.defaultTestLoader.loadTestsFromTestCase(AggregateTests)
    result = unittest.TextTestRunner(verbosity=2).run(suite)
    if args.output_json:
        Path(args.output_json).write_text(json.dumps({"synthetic_only": True, "tests": result.testsRun,
            "failures": len(result.failures), "errors": len(result.errors), "status": "PASS" if result.wasSuccessful() else "FAIL"}, indent=2) + "\n")
    raise SystemExit(0 if result.wasSuccessful() else 1)
