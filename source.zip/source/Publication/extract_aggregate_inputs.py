#!/usr/bin/env python3
"""Extract published aggregate display inputs from the paired HTML supplement."""
import argparse
import csv
import json
from html.parser import HTMLParser
from pathlib import Path


class ManifestParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=False)
        self.active, self.parts = False, []

    def handle_starttag(self, tag, attrs):
        self.active = tag == 'script' and dict(attrs).get('id') == 'publication-manifest'

    def handle_endtag(self, tag):
        if tag == 'script':
            self.active = False

    def handle_data(self, data):
        if self.active:
            self.parts.append(data)


def extract(input_html, output_directory):
    parser = ManifestParser()
    parser.feed(Path(input_html).read_text(encoding='utf-8'))
    if not parser.parts:
        raise ValueError('The HTML supplement has no aggregate publication manifest')
    manifest = json.loads(''.join(parser.parts).replace('<\\/', '</'))
    try:
        from build_publication import validate_manifest
    except ImportError:
        from Publication.build_publication import validate_manifest
    validate_manifest(manifest)
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    (output / 'publication_manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    for item in manifest.get('aggregate_inputs', []):
        filename = item['filename']
        if Path(filename).name != filename or not filename.endswith('.csv'):
            raise ValueError('Aggregate inputs must use flat CSV filenames')
        with (output / filename).open('w', encoding='utf-8', newline='') as stream:
            writer = csv.writer(stream)
            writer.writerow(item['columns'])
            writer.writerows(item['rows'])
    return manifest


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('input_html', type=Path)
    p.add_argument('output_directory', type=Path)
    a = p.parse_args()
    extract(a.input_html, a.output_directory)


if __name__ == '__main__':
    main()
