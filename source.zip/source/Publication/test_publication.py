#!/usr/bin/env python3
"""Synthetic tests for aggregate HTML assembly and safe input extraction."""
import copy
import base64
import json
import re
import tempfile
import unittest
import zipfile
from pathlib import Path
from build_publication import build, code_disclosure, validate_manifest
from extract_aggregate_inputs import extract
from package_source import APPROVED_FILES, package

IMAGE='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZ9sAAAAASUVORK5CYII='


def fixture():
    return {'schema':'tumor-flare-aggregate-publication-v2','title':'Synthetic publication',
      'overview':'Invented aggregate demonstration.','download_label':'Download analysis code',
      'shared_introduction':'Synthetic code demonstration.','shared_sections':[],
      'tables':[{'label':label,'title':'Synthetic aggregate','caption':'Invented counts.',
      'panels':[{'headers':['Characteristic','All'],
      'rows':[{'kind':'group','cells':['Clinical feature']},{'kind':'category','cells':['Yes','2/3 (66.7%)']}]}],
      'aggregate_files':['synthetic_counts.csv'],
      'code_files':['Publication/build_publication.py']} for label in ['Table 1','Table 2','Table S1','Table S2','Table S3','Table S4']],
      'figures':[{'label':label,'title':'Synthetic figure','caption':'Invented illustration.',
      'image_data_url':IMAGE,'code_files':['Publication/build_publication.py']} for label in ['Figure 1','Figure 2','Figure 3','Figure 4','Figure 5','Figure S1']],
      'environment':[['R','synthetic']],
      'aggregate_inputs':[{'filename':'synthetic_counts.csv','columns':['group','n'],'rows':[['All',3]]}]}


class PublicationTest(unittest.TestCase):
    def test_roundtrip_and_closed_code(self):
        manifest=fixture()
        root=Path(__file__).resolve().parents[1]
        rendered=build(manifest,root,'analysiscode.zip')
        self.assertIn('<details class="code-disclosure">',rendered)
        self.assertNotIn('<details class="code-disclosure" open',rendered)
        self.assertIn('class="category"',rendered)
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'synthetic.html'
            p.write_text(rendered)
            recovered=extract(p,Path(directory)/'aggregates')
            self.assertEqual(manifest,recovered)
            self.assertEqual((Path(directory)/'aggregates/synthetic_counts.csv').read_text(),'group,n\nAll,3\n')

    def test_download_matches_aggregate_csv(self):
        rendered=build(fixture(),Path(__file__).resolve().parents[1],'analysiscode.zip')
        payload=re.search(r'data:text/csv;charset=utf-8;base64,([^\"]+)',rendered).group(1)
        self.assertEqual(base64.b64decode(payload).decode(),'group,n\r\nAll,3\r\n')
        self.assertIn('download="synthetic_counts.csv"',rendered)

    def test_individual_labels_rejected(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'][0]='SYN_CASE_A'
        manifest['tables'][0]['panels'][0]['rows'][1]['case_label']='SYN_CASE_A'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_columns_rejected(self):
        manifest=fixture()
        manifest['aggregate_inputs'][0]['columns']=['case_id','n']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_table_width_checked(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_schema_rejected(self):
        manifest=fixture();manifest['schema']='tumor-flare-aggregate-publication-v1'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_display_rejected(self):
        manifest=fixture();manifest['tables'][-1]['label']='Table S5'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_historical_panel_rejected(self):
        manifest=fixture();manifest['tables'][-1]['panels'][0]['title']='Historical endpoint audit'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_calendar_column_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['columns']=['onset_date','n']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_input_path_escape_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['filename']='../synthetic_counts.csv'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_duplicate_input_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'].append(copy.deepcopy(manifest['aggregate_inputs'][0]))
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_missing_download_rejected(self):
        manifest=fixture();manifest['tables'][0]['aggregate_files']=['missing.csv']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_aggregate_width_checked(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['rows'][0].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_code_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):code_disclosure('Synthetic',['../secret.py'],Path(directory))


class PackageTest(unittest.TestCase):
    def staged_fixture(self, root):
        for name in APPROVED_FILES:
            p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('Generic synthetic fixture.\n')
        (root/'Demo/SYNTHETIC.txt').write_text('Explicitly SYNTHETIC fixtures.\n')

    def test_unlisted_clinical_input_excluded(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'source';self.staged_fixture(root)
            (root/'clinical_data.csv').write_text('case_id,n\nINVENTED,1\n')
            out=Path(directory)/'source.zip';result=package(root,out)
            with zipfile.ZipFile(out) as archive:
                self.assertEqual(len(archive.namelist()),len(APPROVED_FILES))
                self.assertNotIn('source/clinical_data.csv',archive.namelist())
            self.assertEqual(result['file_count'],len(APPROVED_FILES))

    def test_symlink_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'source';self.staged_fixture(root)
            target=Path(directory)/'secret.py';target.write_text('Synthetic outside file.\n')
            path=root/'Publication/build_publication.py';path.unlink();path.symlink_to(target)
            with self.assertRaises(ValueError):package(root,Path(directory)/'source.zip')


if __name__=='__main__':
    unittest.main()
