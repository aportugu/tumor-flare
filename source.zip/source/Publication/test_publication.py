#!/usr/bin/env python3
"""Synthetic tests for aggregate HTML assembly and safe input extraction."""
import copy
import json
import tempfile
import unittest
from pathlib import Path
from build_publication import build, validate_manifest
from extract_aggregate_inputs import extract

IMAGE='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZ9sAAAAASUVORK5CYII='


def fixture():
    return {'schema':'tumor-flare-aggregate-publication-v1','title':'Synthetic publication',
      'overview':'Invented aggregate demonstration.','download_label':'Download analysis code',
      'shared_introduction':'Synthetic code demonstration.','shared_sections':[],
      'tables':[{'label':label,'title':'Synthetic aggregate','caption':'Invented counts.',
      'panels':[{'headers':['Characteristic','All'],
      'rows':[{'kind':'group','cells':['Clinical feature']},{'kind':'category','cells':['Yes','2/3 (66.7%)']}]}],
      'code_files':['Publication/build_publication.py']} for label in ['Table 1','Table 2','Table S1','Table S2','Table S3','Table S4','Table S5']],
      'figures':[{'label':label,'title':'Synthetic figure','caption':'Invented illustration.',
      'image_data_url':IMAGE,'code_files':['Publication/build_publication.py']} for label in ['Figure 1','Figure 2','Figure 3','Figure 4','Figure 5','Figure S1']],
      'environment':[['R','synthetic']],
      'aggregate_inputs':[{'filename':'synthetic_counts.csv','columns':['group','n'],'rows':[['All',3]]}]}


class PublicationTest(unittest.TestCase):
    def test_roundtrip_and_closed_code(self):
        manifest=fixture()
        root=Path(__file__).resolve().parents[1]
        rendered=build(manifest,root,'analysiscode.zip')
        self.assertIn('<details class="code-disclosure">',rendered)
        self.assertNotIn('<details class="code-disclosure" open',rendered)
        self.assertIn('class="category"',rendered)
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'synthetic.html'
            p.write_text(rendered)
            recovered=extract(p,Path(directory)/'aggregates')
            self.assertEqual(manifest,recovered)
            self.assertEqual((Path(directory)/'aggregates/synthetic_counts.csv').read_text(),'group,n\nAll,3\n')

    def test_individual_labels_rejected(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'][0]='TF12'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_columns_rejected(self):
        manifest=fixture()
        manifest['aggregate_inputs'][0]['columns']=['case_id','n']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_table_width_checked(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)


if __name__=='__main__':
    unittest.main()
