#!/usr/bin/env python3
"""Synthetic tests for aggregate HTML assembly and safe input extraction."""
import base64
import copy
import json
import re
import tempfile
import unittest
import zipfile
from html.parser import HTMLParser
from pathlib import Path
from build_publication import build, code_disclosure, validate_manifest
from extract_aggregate_inputs import extract
from package_source import APPROVED_FILES, package

IMAGE='data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aZ9sAAAAASUVORK5CYII='


class LinkReader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.links = []

    def handle_starttag(self, tag, attributes):
        if tag == 'a':
            self.links.append(dict(attributes))


class HeaderReader(HTMLParser):
    def __init__(self):
        super().__init__()
        self.in_header = False
        self.current = None
        self.text = []
        self.headings = []

    def handle_starttag(self, tag, attributes):
        attributes = dict(attributes)
        if tag == 'div' and attributes.get('id') == 'header':
            self.in_header = True
        if self.in_header and tag in {'h1', 'h4'}:
            self.current = (tag, attributes.get('class'))
            self.text = []

    def handle_endtag(self, tag):
        if self.current and tag == self.current[0]:
            self.headings.append((*self.current, ' '.join(''.join(self.text).split())))
            self.current = None
        if tag == 'div' and self.in_header:
            self.in_header = False

    def handle_data(self, value):
        if self.current:
            self.text.append(value)


def fixture():
    return {'schema':'tumor-flare-aggregate-publication-v2','title':'Synthetic publication',
      'author':'Andrew Portuguese','build_date':'2026-11-16',
      'overview':'Invented aggregate demonstration.','download_label':'Download analysis code',
      'shared_introduction':'Synthetic code demonstration.','shared_sections':[],
      'tables':[{'label':label,'title':'Synthetic aggregate','caption':'Invented counts.',
      'panels':[{'headers':['Characteristic','All'],
      'rows':[{'kind':'group','cells':['Clinical feature']},{'kind':'category','cells':['Yes','2/3 (66.7%)']}]}],
      'aggregate_files':['synthetic_counts.csv'],
      'code_files':['Publication/build_publication.py']} for label in ['Table 1','Table 2','Table S1','Table S2','Table S3','Table S4']],
      'figures':[{'label':label,'title':'Synthetic figure','caption':'Invented illustration.',
      'image_data_url':IMAGE,'code_files':['Publication/build_publication.py']} for label in ['Figure 1','Figure 2','Figure 3','Figure 4','Figure 5','Figure S1']],
      'environment':[['R','synthetic']],
      'aggregate_inputs':[{'filename':'synthetic_counts.csv','columns':['group','n'],'rows':[['All',3]]}]}


class PublicationTest(unittest.TestCase):
    def test_roundtrip_and_closed_code(self):
        manifest=fixture()
        root=Path(__file__).resolve().parents[1]
        rendered=build(manifest,root,'analysiscode.zip')
        self.assertIn('<details class="code-disclosure">',rendered)
        self.assertNotIn('<details class="code-disclosure" open',rendered)
        self.assertIn('class="category"',rendered)
        with tempfile.TemporaryDirectory() as directory:
            p=Path(directory)/'synthetic.html'
            p.write_text(rendered)
            recovered=extract(p,Path(directory)/'aggregates')
            self.assertEqual(manifest,recovered)
            self.assertEqual((Path(directory)/'aggregates/synthetic_counts.csv').read_text(),'group,n\nAll,3\n')

    def test_figure_s2_requires_the_aggregate_and_follows_figure_s1(self):
        from build_publication import FIGURE_S2_INPUT

        manifest = fixture()
        manifest["figures"].append({**manifest["figures"][-1], "label": "Figure S2",
                                    "aggregate_files": [FIGURE_S2_INPUT]})
        with self.assertRaises(ValueError):
            validate_manifest(manifest)
        manifest["aggregate_inputs"].append({"filename": FIGURE_S2_INPUT, "columns": ["confidence"], "rows": [["Definite"]]})
        validate_manifest(manifest)
        manifest["figures"][-2:] = reversed(manifest["figures"][-2:])
        with self.assertRaises(ValueError):
            validate_manifest(manifest)

    def test_download_links_removed_and_embedded_inputs_preserved(self):
        rendered=build(fixture(),Path(__file__).resolve().parents[1],'analysiscode.zip')
        links=LinkReader();links.feed(rendered)
        self.assertFalse(any('download' in link or link.get('href','').split('?',1)[0].endswith(('.csv','.zip'))
                             or link.get('href','').startswith('data:text/csv') for link in links.links))
        self.assertNotIn('Download aggregate data:',rendered)
        self.assertNotIn('publication-download',rendered)
        self.assertIn('<script type="application/json" id="publication-manifest">',rendered)
        self.assertIn('synthetic_counts.csv',rendered)

    def test_smith_zee_figure_downloads_are_self_contained(self):
        from build_publication import SMITH_ZEE_INPUT

        manifest = fixture()
        pdf = b'%PDF-1.5 synthetic fixture'
        svg = b'<svg xmlns="http://www.w3.org/2000/svg"><path d="M0 0L1 1"/></svg>'
        svg_url = 'data:image/svg+xml;base64,' + base64.b64encode(svg).decode()
        manifest['figures'][-1].update(
            aggregate_files=[SMITH_ZEE_INPUT],
            svg_data_url=svg_url,
            pdf_data_url='data:application/pdf;base64,' + base64.b64encode(pdf).decode(),
        )
        manifest['aggregate_inputs'].append({'filename': SMITH_ZEE_INPUT,
            'columns': ['endpoint', 'day', 'survival'], 'rows': [['PFS', 0, 1]]})
        root = Path(__file__).resolve().parents[1]
        rendered = build(manifest, root, 'analysiscode.zip')
        links = LinkReader(); links.feed(rendered)
        self.assertIn(f'<picture><source type="image/svg+xml" srcset="{svg_url}"><img src="data:image/png;', rendered)
        raster_svg = svg.replace(b'<path d="M0 0L1 1"/>', b'<image href="external.png"/>')
        manifest['figures'][-1]['svg_data_url'] = 'data:image/svg+xml;base64,' + base64.b64encode(raster_svg).decode()
        with self.assertRaisesRegex(ValueError, 'self-contained vector SVG'):
            validate_manifest(manifest)
        manifest['figures'][-1]['svg_data_url'] = svg_url
        payloads = {link['download']: base64.b64decode(link['href'].split(',', 1)[1])
                    for link in links.links if 'download' in link}
        self.assertEqual(payloads, {'Figure_S1_Smith_Zee_Survival.pdf': pdf,
                                   SMITH_ZEE_INPUT: b'endpoint,day,survival\r\nPFS,0,1\r\n'})
        manifest['aggregate_inputs'].append({'filename': 'landmark_km_steps.csv',
                                             'columns': ['endpoint'], 'rows': [['PFS']]})
        with self.assertRaisesRegex(ValueError, 'Retired landmark inputs'):
            validate_manifest(manifest)

    def test_author_and_long_date_follow_title(self):
        rendered=build(fixture(),Path(__file__).resolve().parents[1],'analysiscode.zip')
        header=HeaderReader();header.feed(rendered)
        self.assertEqual(header.headings,[('h1','title toc-ignore','Synthetic publication'),
                         ('h4','author','Andrew Portuguese'),('h4','date','November 16, 2026')])

    def test_group_row_spans_table_and_notes_follow_panel(self):
        manifest=fixture()
        panel=manifest['tables'][0]['panels'][0]
        panel['title']='Synthetic grouped panel'
        panel['notes']=['Global / flare P values: 0.25 / 0.50. <Unavailable>.']
        rendered=build(manifest,Path(__file__).resolve().parents[1],'analysiscode.zip')
        self.assertIn('<th scope="row" colspan="2">Clinical feature</th>',rendered)
        table_end=rendered.index('</tbody></table></div>')
        note=rendered.index('<p class="publication-note">Global / flare P values: 0.25 / 0.50. &lt;Unavailable&gt;.</p>')
        caption=rendered.index('<p class="publication-note">Invented counts.</p>')
        self.assertLess(table_end,note)
        self.assertLess(note,caption)

    def test_response_table_has_responsive_column_class(self):
        manifest=fixture();panel=manifest['tables'][0]['panels'][0]
        panel['headers']=['Model','Flare response, n/N']
        rendered=build(manifest,Path(__file__).resolve().parents[1],'analysiscode.zip')
        self.assertIn('class="publication-grid response-models"',rendered)

    def test_panel_note_schema_checked(self):
        manifest=fixture();manifest['tables'][0]['panels'][0]['notes']='Unavailable'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_spanning_group_width_checked(self):
        manifest=fixture();manifest['tables'][0]['panels'][0]['rows'][0]['cells'].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_labels_rejected(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'][0]='SYN_CASE_A'
        manifest['tables'][0]['panels'][0]['rows'][1]['case_label']='SYN_CASE_A'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_columns_rejected(self):
        manifest=fixture()
        manifest['aggregate_inputs'][0]['columns']=['case_id','n']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_table_width_checked(self):
        manifest=fixture()
        manifest['tables'][0]['panels'][0]['rows'][1]['cells'].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_schema_rejected(self):
        manifest=fixture();manifest['schema']='tumor-flare-aggregate-publication-v1'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_display_rejected(self):
        manifest=fixture();manifest['tables'][-1]['label']='Table S5'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_retired_historical_panel_rejected(self):
        manifest=fixture();manifest['tables'][-1]['panels'][0]['title']='Historical endpoint audit'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_individual_calendar_column_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['columns']=['onset_date','n']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_input_path_escape_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['filename']='../synthetic_counts.csv'
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_duplicate_input_rejected(self):
        manifest=fixture();manifest['aggregate_inputs'].append(copy.deepcopy(manifest['aggregate_inputs'][0]))
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_missing_aggregate_input_rejected(self):
        manifest=fixture();manifest['tables'][0]['aggregate_files']=['missing.csv']
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_aggregate_width_checked(self):
        manifest=fixture();manifest['aggregate_inputs'][0]['rows'][0].append('extra')
        with self.assertRaises(ValueError): validate_manifest(manifest)

    def test_code_path_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaises(ValueError):code_disclosure('Synthetic',['../secret.py'],Path(directory))


class PackageTest(unittest.TestCase):
    def staged_fixture(self, root):
        for name in APPROVED_FILES:
            p=root/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('Generic synthetic fixture.\n')
        (root/'Demo/SYNTHETIC.txt').write_text('Explicitly SYNTHETIC fixtures.\n')

    def test_unlisted_clinical_input_excluded(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'source';self.staged_fixture(root)
            (root/'clinical_data.csv').write_text('case_id,n\nINVENTED,1\n')
            out=Path(directory)/'source.zip';result=package(root,out)
            with zipfile.ZipFile(out) as archive:
                self.assertEqual(len(archive.namelist()),len(APPROVED_FILES))
                self.assertNotIn('source/clinical_data.csv',archive.namelist())
            self.assertEqual(result['file_count'],len(APPROVED_FILES))

    def test_symlink_escape_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root=Path(directory)/'source';self.staged_fixture(root)
            target=Path(directory)/'secret.py';target.write_text('Synthetic outside file.\n')
            path=root/'Publication/build_publication.py';path.unlink();path.symlink_to(target)
            with self.assertRaises(ValueError):package(root,Path(directory)/'source.zip')


if __name__=='__main__':
    unittest.main()
