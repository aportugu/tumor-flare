#!/usr/bin/env Rscript
# Focused synthetic checks; no study counts or clinical records.
script <- sub("^--file=", "", grep("^--file=", commandArgs(), value = TRUE)[1])
script <- gsub("~+~", " ", script, fixed = TRUE)
source(file.path(dirname(normalizePath(script)), "calculate_flare_frequency.R"))
checks <- 0L
check <- function(condition) { stopifnot(isTRUE(condition)); checks <<- checks + 1L }
reject <- function(expression) { check(inherits(tryCatch(force(expression), error = identity), "error")) }

result <- flare_frequency(2, 40)
expected <- stats::binom.test(2, 40)$conf.int * 100
check(result$percent == 5)
check(isTRUE(all.equal(c(result$lower_95_percent, result$upper_95_percent), as.numeric(expected))))
check(result$flare_cases == 2 && result$total_courses == 40)
check(identical(names(result), c("population", "flare_cases", "total_courses", "percent",
  "lower_95_percent", "upper_95_percent", "ci_method")))
check(flare_frequency(0, 12)$lower_95_percent == 0)
check(flare_frequency(12, 12)$upper_95_percent == 100)
check(flare_frequency(0, 12)$upper_95_percent > 0)
check(flare_frequency(12, 12)$lower_95_percent < 100)
for (count in list(-1, 0.5, NA_real_, NaN, Inf, c(1, 2), "2", TRUE)) reject(flare_frequency(count, 40))
for (count in list(0, -1, 1.5, NA_real_, Inf, c(2, 3))) reject(flare_frequency(0, count))
reject(flare_frequency(3, 2))
reject(flare_frequency(1, 5, ""))
synthetic <- data.frame(stage = c("Total cohort", "Clinical series after secondary review"), courses = c(80, 4))
check(identical(frequency_from_flow(synthetic), flare_frequency(4, 80)))
reject(frequency_from_flow(synthetic[1, , drop = FALSE]))
reject(frequency_from_flow(rbind(synthetic, synthetic[1, ])))
reject(frequency_from_flow(data.frame(stage = "Total cohort")))
cat(checks, "synthetic flare-frequency checks passed.\n")
