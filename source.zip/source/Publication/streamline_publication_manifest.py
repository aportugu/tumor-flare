#!/usr/bin/env python3
"""Select compact aggregate displays without refitting clinical analyses.

The empirical input is an aggregate publication manifest supplied separately
from this generic code and selection configuration. The configuration names
display fields and model IDs; it contains no clinical counts or estimates.
"""
import argparse
import base64
import copy
import csv
import hashlib
import json
import math
import re
from pathlib import Path


MISSING_STATES = ("Blank", "Unknown", "Not applicable", "Not reported", "Unavailable")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def input_rows(item):
    return [dict(zip(item["columns"], row)) for row in item["rows"]]


def input_object(filename, columns, rows):
    return {"filename": filename, "columns": columns,
            "rows": [[row.get(key, "") for key in columns] for row in rows]}


def register_total_cohort_frequency(manifest, frequency):
    """Replace comparative frequency registration with an aggregate overall estimate.

    The exact interval is calculated by calculate_flare_frequency.R using base R.
    The figure renderer independently recalculates and verifies it from flow.csv.
    """
    filename = "Flare_Frequency_Total_Cohort.csv"
    columns = ["population", "flare_cases", "total_courses", "percent",
               "lower_95_percent", "upper_95_percent", "ci_method"]
    if frequency.get("filename") != filename or frequency.get("columns") != columns or len(frequency.get("rows", [])) != 1:
        raise ValueError("Overall flare frequency requires one aggregate row with the registered schema")
    row = input_rows(frequency)[0]
    try:
        values = [float(row[key]) for key in columns[1:6]]
    except (ValueError, TypeError):
        raise ValueError("Overall flare frequency requires numeric counts, percentage, and interval") from None
    cases, total, percent, lower, upper = values
    if not all(math.isfinite(value) for value in values) or not (cases >= 0 and total > 0 and cases <= total and cases.is_integer() and total.is_integer()):
        raise ValueError("Invalid overall flare counts")
    if abs(percent - 100 * cases / total) > 1e-10 or not (0 <= lower <= percent <= upper <= 100):
        raise ValueError("Overall flare percentage or interval conflicts with its counts")
    if row["population"] != "Total cohort" or row["ci_method"] != "Clopper-Pearson exact binomial (95%)":
        raise ValueError("Overall flare frequency has an unsupported population or interval method")
    raw = {item["filename"]: item for item in manifest["aggregate_inputs"]}
    flow = input_rows(raw["flow.csv"])
    def stage_count(stage):
        matches = [item for item in flow if item["stage"] == stage]
        if len(matches) != 1:
            raise ValueError("Missing or duplicated cohort stage: " + stage)
        return float(matches[0]["courses"])
    if cases != stage_count("Clinical series after secondary review") or total != stage_count("Total cohort"):
        raise ValueError("Overall flare frequency conflicts with registered cohort-flow counts")
    result = copy.deepcopy(manifest)
    replaced = [item for item in result["aggregate_inputs"] if item["filename"] in {"incidence.csv", filename}]
    if len(replaced) != 1:
        raise ValueError("Expected one frequency object to replace")
    result["aggregate_inputs"] = [copy.deepcopy(frequency) if item["filename"] in {"incidence.csv", filename} else item for item in result["aggregate_inputs"]]
    figure = next(item for item in result["figures"] if item["label"] == "Figure 1")
    figure["aggregate_files"] = [filename if name == "incidence.csv" else name for name in figure["aggregate_files"]]
    for code in ("Publication/calculate_flare_frequency.R", "Publication/streamline_publication_manifest.py"):
        if code not in figure["code_files"]:
            figure["code_files"].append(code)
    figure["frequency_method"] = {"population": "Total cohort", "confidence_level": 0.95,
        "interval": "Clopper-Pearson exact binomial", "unit": "Treatment course",
        "calculation": "Base R stats::binom.test", "patient_clustering_accounted_for": False}
    return result


def register_figure2_densities(manifest, densities):
    """Register aggregate timing densities without changing other results."""
    filename = "Figure_2_Timing_Densities.csv"
    columns = ["measure", "day", "density", "denominator"]
    if densities.get("filename") != filename or densities.get("columns") != columns:
        raise ValueError("Figure 2 densities require the aggregate density-grid schema")
    raw = {item["filename"]: item for item in manifest["aggregate_inputs"]}
    summaries = {row["measure"]: row for row in input_rows(raw["Figure_2_Timing_Summaries.csv"])}
    measures = ["Onset", "Peak", "Symptom resolution"]
    rows = input_rows(densities)
    if len(rows) != 303 or set(row["measure"] for row in rows) != set(measures):
        raise ValueError("Figure 2 requires 101 density-grid values for each of three measures")
    for measure in measures:
        selected = [row for row in rows if row["measure"] == measure]
        days = [float(row["day"]) for row in selected]
        if days != list(range(101)):
            raise ValueError("Figure 2 densities require an ordered daily grid from 0 to 100")
        denominator = int(summaries[measure]["n"])
        if denominator <= 0 or any(int(row["denominator"]) != denominator for row in selected):
            raise ValueError("Figure 2 density denominators disagree with available timing summaries")
        values = [float(row["density"]) for row in selected]
        if any(not math.isfinite(value) or value < 0 for value in values):
            raise ValueError("Figure 2 densities must be finite and nonnegative")
    result = copy.deepcopy(manifest)
    result["aggregate_inputs"] = [item for item in result["aggregate_inputs"]
                                   if item["filename"] != "Figure_2_Timing_Distributions.csv"]
    previous = [index for index, item in enumerate(result["aggregate_inputs"]) if item["filename"] == filename]
    if len(previous) > 1:
        raise ValueError("Figure 2 density input is registered more than once")
    if previous:
        result["aggregate_inputs"][previous[0]] = copy.deepcopy(densities)
    else:
        result["aggregate_inputs"].append(copy.deepcopy(densities))
    figure = require_one(result["figures"], label="Figure 2")
    figure["aggregate_files"] = ["Figure_2_Onset_Bins.csv", "Figure_2_Timing_Summaries.csv", filename]
    figure["density_method"] = {"kernel": "Gaussian", "bandwidth_days": 5,
        "boundary_correction": "Reflection at zero", "evaluation_grid_days": 1,
        "display_range_days": [0, 100], "display_range_only": True,
        "renormalized_within_display": False}
    return result


def collapse_figure3_statuses(rows):
    """Combine unavailable display states without modifying original records."""
    groups = {}
    for row in rows:
        key = tuple(row[name] for name in ("panel", "field", "label"))
        category = row["category"]
        if category in (None, "", "Not applicable"):
            category = "Unknown"
        if category not in ("Yes", "No", "Unknown"):
            raise ValueError("Unexpected Figure 3 assessment category")
        n, denominator = float(row["n"]), float(row["denominator"])
        if not all(math.isfinite(v) and v.is_integer() for v in (n, denominator)) or n < 0 or denominator <= 0:
            raise ValueError("Invalid Figure 3 count or denominator")
        group = groups.setdefault(key, {"denominator": int(denominator), "counts": {}})
        if group["denominator"] != denominator:
            raise ValueError("Inconsistent Figure 3 denominators")
        group["counts"][category] = group["counts"].get(category, 0) + int(n)
    result = []
    for key, group in groups.items():
        denominator = group["denominator"]
        if sum(group["counts"].values()) != denominator:
            raise ValueError("Figure 3 counts do not conserve the full denominator")
        for category in ("Yes", "No", "Unknown"):
            if category in group["counts"]:
                n = group["counts"][category]
                result.append(dict(zip(("panel", "field", "label", "category", "n", "denominator", "percent"),
                                       (*key, category, n, denominator, 100 * n / denominator))))
    return result


def register_figure3_statuses(manifest, config):
    """Register figure-only grouping from unchanged shared aggregate inputs."""
    result = copy.deepcopy(manifest)
    if config.get("category_mapping") != {"Not applicable": "Unknown"}:
        raise ValueError("Unsupported Figure 3 category mapping")
    source_names = ("presentation.csv", "anatomy_binary.csv")
    inputs = {item["filename"]: item for item in result["aggregate_inputs"]}
    if any(name not in inputs for name in source_names):
        raise ValueError("Missing Figure 3 source aggregates")
    sources = [row for name in source_names for row in input_rows(inputs[name])]
    selected = []
    for panel, fields in config["panels"].items():
        for field in fields:
            matches = [row for row in sources if row["field"] == field]
            if not matches:
                raise ValueError("Missing Figure 3 characteristic: " + field)
            for row in matches:
                selected.append({**row, "panel": panel,
                    "label": config.get("label_updates", {}).get(field, row["label"])})
    columns = ["panel", "field", "label", "category", "n", "denominator", "percent"]
    aggregate = input_object("Figure_3_Statuses.csv", columns, collapse_figure3_statuses(selected))
    existing = [i for i, item in enumerate(result["aggregate_inputs"]) if item["filename"] == aggregate["filename"]]
    if len(existing) > 1:
        raise ValueError("Duplicate Figure 3 registration")
    if existing:
        result["aggregate_inputs"][existing[0]] = aggregate
    else:
        result["aggregate_inputs"].append(aggregate)
    figure = require_one(result["figures"], label="Figure 3")
    figure["aggregate_files"] = [aggregate["filename"]]
    for code in ("Publication/build_figures.R", "Publication/streamline_publication_manifest.py"):
        if code not in figure.setdefault("code_files", []):
            figure["code_files"].append(code)
    figure["status_presentation"] = {"source_aggregate_files": list(source_names),
        "category_mapping": config["category_mapping"], "categories": ["Yes", "No", "Unknown"],
        "denominator": "All descriptive cases for each characteristic",
        "original_assessment_categories_preserved": True}
    figure["caption"] = config["caption"]
    return result


def register_figure5_rain(manifest, content, production):
    """Register a proposed clinical framework without changing analytical inputs.

    The conceptual content is supplied as an aggregate/publication input in the
    paired HTML. Connections describe reading order and repeat assessment; they
    are not patient pathways or estimates.
    """
    filename = "Figure_5_RAIN_Content.csv"
    columns = ["stage", "element_id", "heading", "text"]
    if content.get("filename") != filename or content.get("columns") != columns:
        raise ValueError("RAIN content requires stage, element_id, heading, and text")
    rows = input_rows(content)
    if not rows or set(row["stage"] for row in rows) != {"R", "A", "I", "N"}:
        raise ValueError("RAIN content requires all four stages R, A, I, N")
    keys = [(row["stage"], row["element_id"]) for row in rows]
    if len(keys) != len(set(keys)) or any(not row["element_id"] or not (row["heading"] or row["text"]) for row in rows):
        raise ValueError("RAIN elements must be uniquely identified and contain text")
    if any(not isinstance(row[key], str) for row in rows for key in columns):
        raise ValueError("RAIN content must contain publication text only")
    if not isinstance(production, dict):
        raise ValueError("RAIN production metadata must be a mapping")
    result = copy.deepcopy(manifest)
    previous = [index for index, item in enumerate(result["aggregate_inputs"]) if item["filename"] == filename]
    if len(previous) > 1:
        raise ValueError("RAIN content is registered more than once")
    if previous:
        result["aggregate_inputs"][previous[0]] = copy.deepcopy(content)
    else:
        result["aggregate_inputs"].append(copy.deepcopy(content))
    figure = require_one(result["figures"], label="Figure 5")
    figure["aggregate_files"] = [filename]
    if "Publication/streamline_publication_manifest.py" not in figure["code_files"]:
        figure["code_files"].append("Publication/streamline_publication_manifest.py")
    figure["framework_registration"] = {
        "type": "Proposed clinical framework",
        "stages": ["R", "A", "I", "N"],
        "connections": [
            {"source": "R", "target": "A", "kind": "forward"},
            {"source": "A", "target": "I", "kind": "forward"},
            {"source": "I", "target": "N", "kind": "forward"},
            {"source": "N", "target": "I", "kind": "reassessment", "label": "Repeat assessment"},
        ],
        "urgent_complication_management": "Alongside diagnostic evaluation",
        "formal_consensus": False,
        "diagnostic_validation": False,
        "production": copy.deepcopy(production),
    }
    return result


def table_input(filename, panel):
    rows = []
    for row in panel["rows"]:
        cells = list(row["cells"])
        cells += [""] * (len(panel["headers"]) - len(cells))
        if row.get("kind") == "category":
            cells[0] = "  " + cells[0]
        rows.append(cells)
    return {"filename": filename, "columns": panel["headers"], "rows": rows}


def number(value):
    return f"{float(value):g}"


def count_cell(row):
    return f'{int(row["n"]):,}/{int(row["denominator"]):,} ({float(row["percent"]):.1f}%)'


def require_one(rows, **criteria):
    found = [row for row in rows if all(row.get(key) == value for key, value in criteria.items())]
    if len(found) != 1:
        raise ValueError(f"Expected one aggregate row for {criteria}; found {len(found)}")
    return found[0]


def grouped_table_rows(panel):
    groups, active = {}, None
    for row in panel["rows"]:
        if row.get("kind") == "group":
            active = row["cells"][0]
            groups[active] = []
        else:
            if active is None:
                raise ValueError("Expected a characteristic heading before comparative rows")
            groups[active].append(row)
    return groups


def apply_main_table_labels(table, selection):
    """Apply approved author labels without changing numerical cells."""
    updates = selection.get("main_table_label_updates", {}).get(table["label"], {})
    for panel in table["panels"]:
        for row in panel["rows"]:
            if row.get("kind") == "group" and row["cells"][0] in updates:
                row["cells"][0] = updates[row["cells"][0]]
    return table


def build_clinical_panels(full_manifest, selection):
    full_input = next(item for item in full_manifest["aggregate_inputs"]
                      if item["filename"] == "Table_S1_Aggregate.csv")
    raw = input_rows(full_input)
    groups = selection["groups"]
    totals = {group: {int(row["total_n"]) for row in raw if row["group"] == group} for group in groups}
    if any(len(values) != 1 for values in totals.values()):
        raise ValueError("Clinical confidence groups have inconsistent denominators")
    totals = {group: values.pop() for group, values in totals.items()}
    if totals[groups[0]] != sum(totals[group] for group in groups[1:]):
        raise ValueError("Clinical confidence groups do not conserve all cases")
    headers = ["Characteristic", f'All cases (N = {totals[groups[0]]})'] + [
        f"{group} (N = {totals[group]})" for group in groups[1:]]
    panels, selected_rows, selected_keys = [], [], set()
    for panel_spec in selection["clinical_panels"]:
        output_rows = []
        for section in panel_spec["sections"]:
            if section.get("heading"):
                output_rows.append({"kind": "group", "cells": [section["heading"]]})
            for spec in section["fields"]:
                field_rows = [row for row in raw if row["field"] == spec["field"]]
                if not field_rows:
                    raise ValueError(f'Missing clinical field: {spec["field"]}')
                categories = list(dict.fromkeys(row["category"] for row in field_rows))
                field = spec["field"]
                mode = spec["mode"]
                used = []
                if mode == "categorical":
                    output_rows.append({"kind": "group", "cells": [spec["label"]], "field": field})
                    for category in categories:
                        rows = [require_one(field_rows, group=group, category=category) for group in groups]
                        output_rows.append({"kind": "category", "cells": [category] + [count_cell(row) for row in rows], "field": field})
                        used += rows
                elif mode == "timing":
                    rows = [require_one(field_rows, group=group, category="Median (IQR)") for group in groups]
                    cells = [f'{number(row["median"])} ({number(row["q1"])}–{number(row["q3"])}); n = {int(row["available_n"])}' for row in rows]
                    output_rows.append({"kind": "row", "cells": [spec["label"]] + cells, "field": field})
                    used += rows
                elif mode in ("binary", "selected_category"):
                    category = "Yes" if mode == "binary" else spec["category"]
                    # Interval-only timing is displayed only when present. An
                    # explicitly assigned date removes that current category.
                    if mode == "selected_category" and category == "Interval only":
                        matches = [row for row in field_rows if row["category"] == category]
                        if not matches or not any(int(row["n"]) for row in matches):
                            continue
                    cells = []
                    for group in groups:
                        row = require_one(field_rows, group=group, category=category)
                        parts = [count_cell(row)]
                        used.append(row)
                        for missing in MISSING_STATES:
                            matching = [row for row in field_rows if row["group"] == group and row["category"] == missing]
                            if matching and int(matching[0]["n"]) > 0:
                                parts.append(f"{missing}: {count_cell(matching[0])}")
                                used.append(matching[0])
                        cells.append("\n".join(parts))
                    output_rows.append({"kind": "row", "cells": [spec["label"]] + cells, "field": field})
                else:
                    raise ValueError(f"Unsupported clinical presentation mode: {mode}")
                for row in used:
                    key = (row["field"], row["category"], row["group"])
                    if key not in selected_keys:
                        selected_rows.append(copy.deepcopy(row))
                        selected_keys.add(key)
        panels.append({"title": panel_spec["title"], "headers": headers, "rows": output_rows})
    return panels, input_object("Table_S1_Selected_Aggregates.csv", full_input["columns"], selected_rows)


def build_comparative_tables(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S3")
    grouped = grouped_table_rows(old["panels"][0])
    primary = grouped["Primary analysis — Best response distribution"]
    strict = grouped["Definite/Probable analysis — Best response distribution"]
    primary_thresholds = grouped["Primary analysis — Best response thresholds"]
    strict_thresholds = grouped["Definite/Probable analysis — Best response thresholds"]
    primary_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in primary], label="Unavailable")["cells"][1].split("/")[1].split()[0]
    strict_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in strict], label="Unavailable")["cells"][1].split("/")[1].split()[0]
    control_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in primary], label="Unavailable")["cells"][2].split("/")[1].split()[0]
    headers = ["Characteristic", f"Flare (N = {primary_n})", f"Definite/Probable flare (N = {strict_n})", f"No flare (N = {control_n})"]
    rows = []
    for title, p_rows, s_rows in [("Best response distribution", primary, strict), ("Best response thresholds", primary_thresholds, strict_thresholds)]:
        rows.append({"kind": "group", "cells": [title]})
        for p, s in zip(p_rows, s_rows):
            if p["cells"][0] != s["cells"][0] or p["cells"][2] != s["cells"][2]:
                raise ValueError("Comparative response categories or control cells disagree")
            label = p["cells"][0].replace(">=", "≥")
            rows.append({"kind": "category", "cells": [label, p["cells"][1], s["cells"][1], p["cells"][2]]})
    response_panel = {"title": "Panel A Best response to bispecific antibody treatment", "headers": headers, "rows": rows}
    immune_rows = grouped["Primary analysis — Post-treatment events"]
    immune_panel = {"title": "Panel B Immune toxicities and treatment tocilizumab", "headers": ["Characteristic", f"Flare (N = {primary_n})", f"No flare (N = {control_n})", "P value"], "rows": []}
    for label in selection["immune_characteristics"]:
        row = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in immune_rows], label=label)
        cells = row["cells"]
        immune_panel["rows"].append({"kind": "row", "cells": cells[:3] + [cells[3].split("\n")[0]]})
    return [response_panel, immune_panel]


def build_logistic_table(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S4")
    visible = {row["model_id"]: row for panel in old["panels"] for row in panel["rows"]}
    raw_input = next(item for item in full_manifest["aggregate_inputs"] if item["filename"] == "models.csv")
    raw = input_rows(raw_input)
    panels, selected = [], []
    headers = ["Model", "Courses / patients", "Flare courses / total outcomes\nOutcomes in flare courses", "Excluded for missing data", "OR (95% CI)", "P value"]
    for title, ids in selection["logistic_models"].items():
        output_rows = []
        for model_id in ids:
            row = copy.deepcopy(visible[model_id])
            original = require_one(raw, model_id=model_id)
            cells = row["cells"]
            label = cells[0]
            if model_id == "strict_true_emd":
                label += "\nDefinite/Probable cases"
            elif model_id == "without_dominant_site_true_emd":
                label += "\nLargest contributing site excluded"
            cells[0] = label
            cells[2] = cells[2].replace("Flare events", "Outcomes in flare courses")
            cells[5] = "<0.0001" if cells[5].split("\n")[0] == "0.0000" else cells[5].split("\n")[0]
            output_rows.append({"kind": "row", "cells": cells[:6], "model_id": model_id})
            selected.append(original)
        panel = {"title": title, "headers": headers, "rows": output_rows}
        if "Definite/Probable response" in title:
            panel["notes"] = [sparse_response_note(require_one(raw,model_id="strict_response_pr_adjusted"),qualified=False)]
        panels.append(panel)
    return panels, input_object("models.csv", raw_input["columns"], selected)


def build_survival_table(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S5")
    panels_by_title = {panel["title"]: panel for panel in old["panels"]}
    raw_input = next(item for item in full_manifest["aggregate_inputs"] if item["filename"] == "survival_models.csv")
    raw = input_rows(raw_input)
    panels, selected, landmark_rows = [], [], []
    headers = ["Endpoint and model", "Courses / patients", "Exposed courses / exposed events", "Total events / excluded for missing data", "HR (95% CI)", "P value", "PH global / flare P"]
    title_map = {"primary": "Primary analysis", "strict": "Definite/Probable analysis", "without_dominant_site": "Largest-site-exclusion analysis"}
    for spec in selection["survival_panels"]:
        rows = []
        source_panel = panels_by_title[title_map[spec["scenario"]]]
        for endpoint in ("PFS", "OS"):
            for model in spec["models"]:
                original = require_one(raw, scenario=spec["scenario"], endpoint=endpoint, model=model)
                match = [row for row in source_panel["rows"] if row["cells"][0].split("\n") == [endpoint, "Time-dependent exposure", model]]
                if len(match) != 1:
                    raise ValueError("Survival table does not match its registered aggregate row")
                cells = copy.deepcopy(match[0]["cells"])
                short = {"Unadjusted: all eligible": "Unadjusted, all eligible courses", "Unadjusted: adjusted subset": "Unadjusted, matched analysis population", "Adjusted: six baseline variables": "Adjusted for six baseline variables"}[model]
                cells[0] = endpoint + "\n" + short
                object_id = f'{spec["scenario"]}:{endpoint}:{model}'
                rows.append({"kind": "row", "cells": cells, "object_id": object_id})
                selected.append(original)
        panels.append({"title": spec["title"], "headers": headers, "rows": rows})
    landmark_source = panels_by_title[title_map[selection["landmark_scenario"]]]
    rows = []
    for row in landmark_source["rows"]:
        if "Landmark sensitivity" not in row["cells"][0]:
            continue
        cells = copy.deepcopy(row["cells"])
        endpoint, _, day = cells[0].split("\n")
        day = day.strip().removeprefix("day ")
        cells[0] = f"{endpoint}\nDay {day} landmark"
        # Missingness exclusions do not apply to the landmark population.
        cells[3] = cells[3].split("/")[0].strip()
        rows.append({"kind": "row", "cells": cells, "object_id": f'primary:{endpoint}:landmark:{day}'})
        landmark_rows.append({"scenario": "primary", "endpoint": endpoint, "landmark_day": day,
            "n_courses": cells[1].split("/")[0].strip(), "n_patient_clusters": cells[1].split("/")[1].strip(),
            "exposed_courses": cells[2].split("/")[0].strip(), "exposed_events": cells[2].split("/")[1].strip(),
            "events": cells[3], "hr_95ci": cells[4], "p_value": cells[5], "object_id": rows[-1]["object_id"]})
    landmark_headers = list(headers)
    landmark_headers[3] = "Total events"
    panels.append({"title": "Primary landmark analyses", "headers": landmark_headers, "rows": rows})
    return panels, input_object("survival_models.csv", raw_input["columns"], selected), input_object("Table_S4_Landmark_Models.csv", list(landmark_rows[0]), landmark_rows)


def _streamline_unconsolidated(full_manifest, selection, survival_availability_note=""):
    if full_manifest.get("schema") != "tumor-flare-aggregate-publication-v1":
        raise ValueError("Selection requires the complete aggregate publication manifest")
    result = copy.deepcopy(full_manifest)
    result["schema"] = selection["publication_schema"]
    tables = [apply_main_table_labels(copy.deepcopy(table), selection) for table in full_manifest["tables"][:2]]
    clinical_panels, clinical_input = build_clinical_panels(full_manifest, selection)
    tables.append({"label": "Table S1", "title": "Additional clinical characteristics", "caption": "Additional clinical characteristics are summarized for all 33 cases, Definite/Probable cases (N = 18), and Possible cases (N = 15). Categorical counts use the full confidence-group denominator. Binary rows show positive findings; nonzero Blank, Unknown, Not applicable, Not reported, or unavailable assessments appear on separate lines. Timing summaries report the available denominator for each measure. Dates may be recorded or estimated. Missing symptom-resolution dates do not establish persistent symptoms. Clinical features and concurrent events may overlap. Investigator confidence and competing explanations express clinical uncertainty. Later local assessments after radiation, salvage treatment, or CAR-T do not establish response to the bispecific antibody treatment being evaluated. Management and clinical outcomes are shown in Table 2. CRS, cytokine release syndrome; EMD, extramedullary disease; ICANS, immune effector cell-associated neurotoxicity syndrome; IQR, interquartile range.", "panels": clinical_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Publication/clinical_presentation_selection.json"]})
    comparison_panels = build_comparative_tables(full_manifest, selection)
    tables.append({"label": "Table S2", "title": "Comparative response and immune toxicities", "caption": "Best response to the bispecific antibody treatment being evaluated is shown for the primary comparative flare group, the Definite/Probable comparative flare group, and the no-flare group. Response categories and nested thresholds use evaluable denominators; unavailable responses use the full group denominator. The Definite/Probable comparison excludes Possible cases. CRS, ICANS, and treatment tocilizumab use evaluable denominators and two-sided Fisher exact tests in the primary population. These exploratory comparisons do not account for repeated courses within patients or establish temporal order or causation. CR, complete response; CRS, cytokine release syndrome; ICANS, immune effector cell-associated neurotoxicity syndrome; MR, minimal response; PD, progressive disease; PR, partial response; sCR, stringent complete response; SD, stable disease; VGPR, very good partial response.", "panels": comparison_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/summary_functions.R"]})
    logistic_panels, logistic_input = build_logistic_table(full_manifest, selection)
    tables.append({"label": "Table S3", "title": "Baseline and response associations", "caption": "Separate univariable Firth models assess six baseline associations with flare. Response models use flare alone or adjust for age, ECOG performance status, sex, prior treatment lines, high-risk cytogenetic abnormalities, and true extramedullary disease. Sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. Counts are specific to each model. Odds ratios have 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values. Treatment courses are treated as independent; inference does not adjust for repeated courses within patients. Outcomes in baseline models are flare; outcomes in response models are the stated response threshold. Sparse outcomes, including all 11 flare courses responding in the adjusted Definite/Probable ≥PR model, limit inference and do not establish a response benefit. CI, confidence interval; ECOG, Eastern Cooperative Oncology Group; EMD, extramedullary disease; HRCA, high-risk cytogenetic abnormality; OR, odds ratio; PR, partial response; VGPR, very good partial response.", "panels": logistic_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/analysis_functions.R"]})
    survival_panels, survival_input, landmark_input = build_survival_table(full_manifest, selection)
    tables.append({"label": "Table S4", "title": "Survival analyses", "caption": "Time-dependent Cox models compare time after flare onset with unexposed time, using Efron ties and robust standard errors for repeated courses within patients. Primary comparative models use all eligible courses, the population of the adjusted model without adjustment, or adjustment for six baseline variables. Adjusted sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. Landmark analyses begin follow-up at days 30 and 60 among eligible courses and fix flare status at each landmark. Counts and proportional-hazards diagnostics are specific to each model. Exposed events are events after flare onset or among the flare group at the landmark. The adjusted models did not fully satisfy proportional hazards, and several sensitivity estimates rely on few exposed events. A single HR across follow-up therefore requires cautious interpretation. CI, confidence interval; HR, hazard ratio; OS, overall survival; PFS, progression-free survival; PH, proportional hazards.", "panels": survival_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/analysis_functions.R"]})
    if survival_availability_note:
        tables[-1]["panels"][0]["notes"] = [survival_availability_note]
    result["tables"] = tables
    inputs = []
    for table in tables:
        filenames = []
        for index, panel in enumerate(table["panels"]):
            filename = table["label"].replace(" ", "_") + (f"_Panel_{chr(65 + index)}" if len(table["panels"]) > 1 else "") + ".csv"
            inputs.append(table_input(filename, panel))
            filenames.append(filename)
        table["aggregate_files"] = filenames
    inputs += [clinical_input, logistic_input, survival_input, landmark_input]
    tables[2]["aggregate_files"].append(clinical_input["filename"])
    tables[4]["aggregate_files"].append(logistic_input["filename"])
    tables[5]["aggregate_files"] += [survival_input["filename"], landmark_input["filename"]]
    full_inputs = {item["filename"]: item for item in full_manifest["aggregate_inputs"]}
    for filename in selection["unchanged_aggregate_files"]:
        inputs.append(copy.deepcopy(full_inputs[filename]))
    figure_files = {"Figure 1": ["Figure_1_Full_Cohort_Links.csv", "Figure_1_Initial_Review_Links.csv", "Figure_1B_Disposition_Links.csv", "flow.csv", "incidence.csv"], "Figure 2": ["Figure_2_Onset_Bins.csv", "Figure_2_Timing_Summaries.csv", "Figure_2_Timing_Densities.csv"], "Figure 3": ["presentation.csv", "anatomy_binary.csv"], "Figure 4": ["models.csv", "survival_models.csv", "Table_S3_Immune_Associations.csv"], "Figure 5": [], "Figure S1": ["landmark_km_steps.csv", "landmark_risk_counts.csv"]}
    immune_config = selection.get('display_registration_updates', {}).get('table_s3_immune')
    if immune_config and immune_config['aggregate_filename'] in full_inputs:
        inputs.append(copy.deepcopy(full_inputs[immune_config['aggregate_filename']]))
    ph_config = selection.get('display_registration_updates', {}).get('cox_ph_diagnostics')
    if ph_config and ph_config['aggregate_filename'] in full_inputs:
        inputs.append(copy.deepcopy(full_inputs[ph_config['aggregate_filename']]))
    for figure in result["figures"]:
        figure["aggregate_files"] = figure_files[figure["label"]]
        if figure["label"] == "Figure S1":
            figure["caption"] = re.sub(r" Corresponding Cox HRs .*?These conditional comparisons", " These conditional comparisons", figure["caption"])
    result["aggregate_inputs"] = inputs
    result["presentation_selection"] = {"configuration_schema": selection["schema"], "configuration_sha256": digest(selection), "model_refitting": False}
    return result


def _verify_original_selection(full, compact, selection):
    checks = []
    def check(name, value):
        checks.append({"check": name, "passed": bool(value)})
        if not value:
            raise AssertionError(name)
    check("Six publication tables in approved order", [table["label"] for table in compact["tables"]] == ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"])
    for index in range(2):
        expected = apply_main_table_labels(copy.deepcopy(full["tables"][index]), selection)
        check(f"Main table {index + 1} unchanged except approved author labels", all(compact["tables"][index][key] == expected[key] for key in expected))
    for original, selected in zip(full["figures"], compact["figures"]):
        keys = [key for key in original if original["label"] != "Figure S1" or key != "caption"]
        expected = copy.deepcopy(original)
        if original["label"] == "Figure 4":
            expected["aggregate_files"] = ["models.csv", "survival_models.csv", "Table_S3_Immune_Associations.csv"]
        check(original["label"] + " unchanged display object except registered dependencies", all(selected[key] == expected[key] for key in keys))
    check("Figure S1 caption omits duplicated HR estimates", "Corresponding Cox HRs" not in require_one(compact["figures"], label="Figure S1")["caption"])
    filenames = [item["filename"] for item in compact["aggregate_inputs"]]
    check("Aggregate filenames unique", len(filenames) == len(set(filenames)))
    for display in compact["tables"] + compact["figures"]:
        check(display["label"] + " downloads resolve", all(filename in filenames for filename in display["aggregate_files"]))
    for table in compact["tables"]:
        for panel in table["panels"]:
            check(table["label"] + ": " + panel["title"] + " table widths", all(row.get("kind") == "group" or len(row["cells"]) == len(panel["headers"]) for row in panel["rows"]))
    selected_clinical = input_rows(next(item for item in compact["aggregate_inputs"] if item["filename"] == "Table_S1_Selected_Aggregates.csv"))
    original_clinical = input_rows(next(item for item in full["aggregate_inputs"] if item["filename"] == "Table_S1_Aggregate.csv"))
    for row in selected_clinical:
        check("Clinical aggregate unchanged: " + ":".join(row[key] for key in ["field", "category", "group"]), row in original_clinical)
    check("Clinical group sizes are 33/18/15", {group: {int(row["total_n"]) for row in selected_clinical if row["group"] == group} for group in selection["groups"]} == {"All": {33}, "Definite/Probable": {18}, "Possible": {15}})
    onset_counts = [int(require_one(selected_clinical, field="onset_days", group=group, category="Median (IQR)")["available_n"]) for group in selection["groups"]]
    onset_totals = [int(require_one(selected_clinical, field="onset_days", group=group, category="Median (IQR)")["total_n"]) for group in selection["groups"]]
    check("Onset denominators conserve confidence groups", onset_counts[0] == sum(onset_counts[1:]) and all(0 <= count <= total for count, total in zip(onset_counts, onset_totals)))
    check("No eligibility or onset windows in selected clinical table", not ({"bridging_any", "comparative_included", "later_bcma_exclusion", "onset_window"} & {row["field"] for row in selected_clinical}))
    check("No Table 2 duplicates in clinical table", not any(row["field"].startswith("management_") or row["field"] in {"resolution_status", "local_lesion_outcome", "first_postflare_response", "subsequent_response", "best_index_response", "improved_while_bsab_continued", "bsab_action"} for row in selected_clinical))
    check("No response-attribution checks in clinical table", not any(row["field"] in {"first_response_on_index", "subsequent_response_on_index", "later_local_separate_from_systemic_response"} for row in selected_clinical))
    for filename in ("models.csv", "survival_models.csv"):
        original = input_rows(next(item for item in full["aggregate_inputs"] if item["filename"] == filename))
        chosen = input_rows(next(item for item in compact["aggregate_inputs"] if item["filename"] == filename))
        for row in chosen:
            check("Unchanged analytical object: " + filename + ":" + row.get("model_id", row.get("scenario", "") + ":" + row.get("endpoint", "") + ":" + row.get("model", "")), row in original)
    ids = [row["model_id"] for panel in compact["tables"][4]["panels"] for row in panel["rows"]]
    check("Exact approved logistic model selection", ids == [model for models in selection["logistic_models"].values() for model in models])
    strict = next(row for panel in compact["tables"][4]["panels"] for row in panel["rows"] if row["model_id"] == "strict_response_pr_adjusted")
    strict_raw=require_one(input_rows(next(item for item in compact["aggregate_inputs"] if item["filename"]=="models.csv")),model_id="strict_response_pr_adjusted")
    strict_effect=f'{float(strict_raw["estimate"]):.2f} ({float(strict_raw["conf_low"]):.2f}–{float(strict_raw["conf_high"]):.2f})'
    check("Sparse strict response estimate is visible", strict["cells"][4] == strict_effect and f'{strict_raw["candidates"]} / {strict_raw["events"]}' in strict["cells"][2] and f'Outcomes in flare courses {strict_raw["candidate_events"]}' in strict["cells"][2])
    check("Sparse strict response estimate is qualified", "all with at least a partial response" in compact["tables"][4]["panels"][3]["notes"][0])
    check("Survival has ten time-dependent and four landmark rows", sum(len(panel["rows"]) for panel in compact["tables"][5]["panels"]) == 14)
    check("No historical or duplicate follow-up panels", not re.search(r"historical|alternative.onset|descriptive OS follow.up", json.dumps(compact["tables"], ensure_ascii=False), re.I))
    for filename in selection["unchanged_aggregate_files"]:
        check("Figure aggregate unchanged: " + filename, next(item for item in compact["aggregate_inputs"] if item["filename"] == filename) == next(item for item in full["aggregate_inputs"] if item["filename"] == filename))
    check("No case identifiers in aggregate schemas", not any(re.search(r"^(case_id|case_label|patient_id|case_narrative)$", column) for item in compact["aggregate_inputs"] for column in item["columns"]))
    check("No case labels in reader-facing content", not re.search(r"\bTF\d{1,3}\b", json.dumps(compact["tables"], ensure_ascii=False)))
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def panel_input_names(table):
    """Names of display CSV objects, excluding registered analytical objects."""
    stem = table["label"].replace(" ", "_")
    return [stem + (f"_Panel_{chr(65 + i)}" if len(table["panels"]) > 1 else "") + ".csv"
            for i in range(len(table["panels"]))]


def integer_count(row, key):
    value = row[key]
    result = int(value)
    if result < 0 or float(value) != result:
        raise ValueError(f"Invalid nonnegative integer count: {key}")
    return result


def response_fractions(original):
    """Reconstruct both response groups from the registered aggregate 2×2 counts."""
    total = integer_count(original, "n_courses")
    flare = integer_count(original, "candidates")
    events = integer_count(original, "events")
    flare_events = integer_count(original, "candidate_events")
    comparison, comparison_events = total - flare, events - flare_events
    if not (0 <= flare_events <= flare <= total and 0 <= comparison_events <= comparison):
        raise ValueError("Response group counts do not form a valid 2×2 table")
    return f"{flare_events}/{flare}", f"{comparison_events}/{comparison}"


def sparse_response_note(row, qualified=True):
    """Describe complete response separation using the registered model values."""
    n=integer_count(row,'candidates')
    if integer_count(row,'candidate_events') != n:
        raise ValueError('The complete-separation response note requires all flare courses above threshold')
    estimate,low,high=[float(row[key]) for key in ['estimate','conf_low','conf_high']]
    label='Definite/Probable ' if qualified else ''
    return (f'The adjusted {label}≥PR model includes {n} flare courses, all with at least a partial response. '
            f'Its large estimate (OR {estimate:.2f}; 95% CI, {low:.2f}–{high:.2f}) is sensitive to sparse outcomes '
            'and complete separation and does not establish a response benefit.')


def validate_logistic_counts(display, original):
    cells = display["cells"]
    population = f'{integer_count(original, "n_courses")} / {integer_count(original, "n_patient_clusters")}'
    outcomes = (f'{integer_count(original, "candidates")} / {integer_count(original, "events")}\n'
                f'Outcomes in flare courses {integer_count(original, "candidate_events")}')
    if cells[1] != population or cells[2] != outcomes or cells[3] != original["excluded_missing"]:
        raise ValueError("Logistic display counts disagree with registered analytical counts")


def consolidate_manifest(selected, selection):
    """Change only presentation objects in an already selected aggregate manifest."""
    if selected.get("schema") != selection["publication_schema"]:
        raise ValueError("Consolidation requires a selected aggregate publication manifest")
    if selected.get("presentation_selection", {}).get("consolidation_schema"):
        raise ValueError("Manifest has already been consolidated")
    result = copy.deepcopy(selected)
    config = selection["consolidation"]
    source_tables = {table["label"]: table for table in selected["tables"]}
    tables = {table["label"]: table for table in result["tables"]}
    raw_inputs = {item["filename"]: item for item in selected["aggregate_inputs"]}
    models = input_rows(raw_inputs["models.csv"])

    clinical = source_tables["Table S1"]["panels"]
    if len(clinical) != len(config["clinical_domains"]):
        raise ValueError("Clinical domain selection does not match source panels")
    if any(panel["headers"] != clinical[0]["headers"] for panel in clinical):
        raise ValueError("Clinical domains have different populations or headers")
    rows = []
    for panel, domain in zip(clinical, config["clinical_domains"]):
        rows.append({"kind": "group", "cells": [domain["title"]], "group_type": "clinical_domain"})
        rows.extend(copy.deepcopy(row) for row in panel["rows"]
                    if not (row.get("kind") == "group" and row["cells"][0] in domain["omit_group_labels"]))
    tables["Table S1"]["panels"] = [{"title": config["clinical_title"],
        "headers": copy.deepcopy(clinical[0]["headers"]), "rows": rows}]

    logistic = source_tables["Table S3"]["panels"]
    visible = {row["model_id"]: row for panel in logistic for row in panel["rows"]}
    if len(visible) != len(models):
        raise ValueError("Logistic display and analytical model selections differ")
    baseline_rows = []
    for panel in logistic[:2]:
        for row in panel["rows"]:
            original = require_one(models, model_id=row["model_id"])
            validate_logistic_counts(row, original)
            flare = integer_count(original, "candidates")
            if integer_count(original, "events") != flare or integer_count(original, "candidate_events") != flare:
                raise ValueError("Baseline outcome counts are not redundant flare counts")
            cells = copy.deepcopy(row["cells"])
            cells[2] = str(flare)
            baseline_rows.append({"kind": "row", "cells": cells, "model_id": row["model_id"]})
    baseline_headers = copy.deepcopy(logistic[0]["headers"])
    baseline_headers[2] = "Flare courses, n"
    baseline_panel = {"title": config["baseline_title"], "headers": baseline_headers, "rows": baseline_rows}
    response_rows = []
    for group in config["response_groups"]:
        originals = [require_one(models, model_id=model_id) for model_id in group["model_ids"]]
        shared = {(row["n_courses"], row["n_patient_clusters"], row["excluded_missing"]) for row in originals}
        if len(shared) != 1:
            raise ValueError("Response thresholds have different population or exclusion counts")
        courses, patients, excluded = shared.pop()
        heading = (f'{group["title"]}\n{int(courses):,} courses / {int(patients):,} patients; '
                   f'{int(excluded):,} excluded for missing data')
        response_rows.append({"kind": "group", "cells": [heading], "group_type": "response_population",
            "model_ids": list(group["model_ids"]), "n_courses": courses,
            "n_patient_clusters": patients, "excluded_missing": excluded})
        for model_id, original in zip(group["model_ids"], originals):
            source = visible[model_id]
            validate_logistic_counts(source, original)
            flare_fraction, comparison_fraction = response_fractions(original)
            threshold = source["cells"][0].removeprefix("Response ").split(" (")[0]
            response_labels = {"response_pr": "≥PR", "response_vgpr": "≥VGPR", "response_cr": "CR/sCR"}
            if original.get("response") in response_labels and threshold != response_labels[original["response"]]:
                raise ValueError("Response threshold disagrees with registered outcome")
            response_rows.append({"kind": "row", "model_id": model_id,
                "cells": [threshold, flare_fraction, comparison_fraction] + copy.deepcopy(source["cells"][-2:])})
    response_notes = list(dict.fromkeys(note.replace("The adjusted ≥PR model", "The adjusted Definite/Probable ≥PR model")
        for panel in logistic[2:] for note in panel.get("notes", [])))
    response_panel = {"title": config["response_title"], "table_class": "response-models",
        "headers": ["Threshold", "Flare response, n/N", "No-flare response, n/N", "OR (95% CI)", "P value"],
        "rows": response_rows, "notes": response_notes}
    tables["Table S3"]["panels"] = [baseline_panel, response_panel]
    tables["Table S3"]["caption"] = (
        "Panel A shows separate univariable Firth models for six baseline associations with flare and two true-EMD sensitivity analyses. "
        "Panel B shows response models using flare alone or adjustment for age, ECOG performance status, sex, prior treatment lines, high-risk cytogenetic abnormalities, and true extramedullary disease. "
        "Sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. "
        "Response fractions use the evaluable flare and no-flare courses in each model; shared course, patient, and missing-data exclusion counts appear in group headings. "
        "Odds ratios have 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values. Treatment courses are treated as independent; inference does not adjust for repeated courses within patients. "
        "All analyses are exploratory, and sparse outcomes limit inference. CI, confidence interval; ECOG, Eastern Cooperative Oncology Group; EMD, extramedullary disease; HRCA, high-risk cytogenetic abnormality; OR, odds ratio; PR, partial response; VGPR, very good partial response.")

    survival = source_tables["Table S4"]["panels"]
    if len(survival) != 4:
        raise ValueError("Expected three time-dependent groups and one landmark panel")
    survival_raw = input_rows(raw_inputs["survival_models.csv"])
    time_rows, diagnostics = [], []
    for panel, title in zip(survival[:3], config["survival_groups"]):
        time_rows.append({"kind": "group", "cells": [title], "group_type": "survival_population"})
        group_pairs = []
        for row in panel["rows"]:
            copied = copy.deepcopy(row)
            scenario, endpoint, model = row["object_id"].split(":", 2)
            original = require_one(survival_raw, scenario=scenario, endpoint=endpoint, model=model)
            if row["cells"][-1] != "Unavailable / Unavailable":
                pair = " / ".join(f'{float(original[key]):.4f}' for key in ("ph_global_p", "ph_flare_p"))
                if pair != row["cells"][-1]:
                    raise ValueError("PH display disagrees with registered analytical diagnostics")
                group_pairs.append(f'{endpoint} {pair.replace(" / ", "/")}')
            copied["cells"] = copied["cells"][:-1]
            time_rows.append(copied)
        diagnostics.append(title + ": " + ", ".join(group_pairs))
    ph_note = "PH global/flare P values for adjusted models: " + "; ".join(diagnostics) + ". PH diagnostics were unavailable for the other models."
    inherited_notes = list(dict.fromkeys(note for panel in survival[:3] for note in panel.get("notes", [])))
    time_panel = {"title": config["time_dependent_title"], "headers": copy.deepcopy(survival[0]["headers"][:-1]),
        "rows": time_rows, "notes": [ph_note] + inherited_notes}
    landmark_panel = copy.deepcopy(survival[3])
    landmark_panel["title"] = config["landmark_title"]
    landmark_panel["headers"] = landmark_panel["headers"][:-1]
    landmark_panel["headers"][2] = "Flare by landmark: courses / events"
    for row in landmark_panel["rows"]:
        row["cells"] = row["cells"][:-1]
    tables["Table S4"]["panels"] = [time_panel, landmark_panel]

    old_display_names = {name for table in selected["tables"] for name in panel_input_names(table)}
    inputs = [copy.deepcopy(item) for item in selected["aggregate_inputs"] if item["filename"] not in old_display_names]
    for table in result["tables"]:
        new_names = panel_input_names(table)
        inputs.extend(table_input(name, panel) for name, panel in zip(new_names, table["panels"]))
        table["aggregate_files"] = new_names + [name for name in source_tables[table["label"]]["aggregate_files"] if name not in old_display_names]
    result["aggregate_inputs"] = inputs
    result["presentation_selection"] = {"configuration_schema": selection["schema"], "configuration_sha256": digest(selection),
        "consolidation_schema": config["schema"], "model_refitting": False}
    return result


def streamline(full_manifest, selection, survival_availability_note=""):
    selected = (copy.deepcopy(full_manifest) if full_manifest.get("schema") == selection["publication_schema"]
                else _streamline_unconsolidated(full_manifest, selection, survival_availability_note))
    result = consolidate_manifest(selected, selection)
    return apply_publication_metadata(result, selection)


def apply_supplementary_table_order(manifest, selection):
    """Assign publication numbers after legacy selection and consolidation."""
    result = copy.deepcopy(manifest)
    config = selection.get("supplementary_table_order")
    if not config or not {"Table S2", "Table S3"}.issubset({t["label"] for t in result.get("tables", [])}):
        return result
    records = config["tables"]
    if {r["content_id"] for r in records} != {"baseline_response_associations", "comparative_response_immune_toxicities"}:
        raise ValueError("Invalid supplementary table identities")
    state = result.setdefault("presentation_selection", {})
    already = state.get("supplementary_order_schema")
    if already and already != config["schema"]:
        raise ValueError("Unsupported supplementary table ordering")
    names = {}
    source_tables = {table["label"]: table for table in result["tables"]}
    for record in records:
        candidates = [t for t in result["tables"] if t.get("content_id") == record["content_id"]] if already else [source_tables[record["previous_label"]]]
        if len(candidates) != 1:
            raise ValueError("Supplementary table identity is missing or duplicated")
        table = candidates[0]
        if already and table["label"] != record["label"]:
            raise ValueError("Supplementary table identity and number disagree")
        old_names = panel_input_names(table)
        table["content_id"] = record["content_id"]
        table["label"] = record["label"]
        names.update(zip(old_names, panel_input_names(table)))
    for item in result["aggregate_inputs"]:
        item["filename"] = names.get(item["filename"], item["filename"])
    for display in result["tables"] + result["figures"]:
        display["aggregate_files"] = [names.get(name, name) for name in display.get("aggregate_files", [])]
    order = ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"]
    result["tables"].sort(key=lambda table: order.index(table["label"]))
    for table in result["tables"]:
        if table["label"] == "Table S4":
            for panel in table["panels"]:
                if "notes" in panel:
                    panel["notes"] = [note for note in panel["notes"] if not ("alternative" in note.lower() and "onset" in note.lower())]
    state["supplementary_order_schema"] = config["schema"]
    return result


def legacy_table_order(manifest, selection):
    """Normalize publication numbering only for legacy consolidation checks."""
    result = copy.deepcopy(manifest)
    if not result.get("presentation_selection", {}).get("supplementary_order_schema"):
        return result
    config = selection["supplementary_table_order"]
    names = {}
    for record in config["tables"]:
        table = require_one(result["tables"], content_id=record["content_id"])
        old_names = panel_input_names(table)
        table["label"] = record["previous_label"]
        table.pop("content_id")
        names.update(zip(old_names, panel_input_names(table)))
    for item in result["aggregate_inputs"]:
        item["filename"] = names.get(item["filename"], item["filename"])
    for display in result["tables"] + result["figures"]:
        display["aggregate_files"] = [names.get(name, name) for name in display.get("aggregate_files", [])]
    result["tables"].sort(key=lambda table: ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"].index(table["label"]))
    result["presentation_selection"].pop("supplementary_order_schema")
    return result


def profile_inference_values(row, config):
    """Validate registered profile bounds and same-design penalized LR inference."""
    if row.get('inference_schema') != config['inference_schema'] or row.get('method') != config['method']:
        raise ValueError('Unsupported Firth profile inference method or schema')
    if any(key.startswith('bootstrap_') or key in {'seed','minimum_successes'} for key in row):
        raise ValueError('Retired bootstrap fields cannot enter profile inference')
    truth = lambda value: str(value).upper() in {'TRUE','1'}
    if not all(truth(row.get(key,'')) for key in ['point_converged','profile_converged','plr_converged']):
        raise ValueError('Firth point, profile interval, and PLR inference must converge')
    keys = ['log_odds','log_ci_low','log_ci_high','odds_ratio','conf_low','conf_high',
            'p_value','full_loglik','restricted_loglik','plr_statistic','plr_df']
    try: values = {key:float(row[key]) for key in keys}
    except (KeyError,ValueError,TypeError): raise ValueError('Incomplete profile inference values') from None
    if not all(math.isfinite(v) for v in values.values()):
        raise ValueError('Profile inference values must be finite')
    beta, lower, upper = (values[key] for key in ['log_odds','log_ci_low','log_ci_high'])
    if not lower <= beta <= upper or values['plr_df'] != 1 or values['plr_statistic'] < 0 or not 0 <= values['p_value'] <= 1:
        raise ValueError('Invalid profile interval or PLR statistic')
    expected = [math.exp(beta),math.exp(lower),math.exp(upper),
                math.erfc(math.sqrt(values['plr_statistic']/2))]
    registered = [values[key] for key in ['odds_ratio','conf_low','conf_high','p_value']]
    statistic = max(0,2*(values['full_loglik']-values['restricted_loglik']))
    if not math.isclose(values['plr_statistic'],statistic,rel_tol=1e-10,abs_tol=1e-10) or any(
            not math.isclose(a,b,rel_tol=1e-9,abs_tol=1e-11) for a,b in zip(registered,expected)):
        raise ValueError('Profile bounds and P value must match registered penalized likelihood inference')
    return registered


def register_firth_profile_models(manifest, model_input, config):
    """Replace inference from unchanged course-level Firth models and update displays."""
    result = copy.deepcopy(manifest)
    originals = input_rows(require_one(result['aggregate_inputs'],filename='models.csv'))
    rows = input_rows(model_input)
    if model_input['filename'] != 'models.csv' or len({r['model_id'] for r in rows}) != len(rows) or not set(r['model_id'] for r in originals).issubset(r['model_id'] for r in rows):
        raise ValueError('Profile model IDs must include the previous analysis exactly once')
    stable_counts = ['n_courses','n_patient_clusters','candidates','events','candidate_events','excluded_missing']
    old_by_id={row['model_id']:row for row in originals}
    for row in rows:
        old = old_by_id.get(row['model_id'])
        if old is not None:
            if any(integer_count(row,key) != integer_count(old,key) for key in stable_counts):
                raise ValueError('Profile model populations and counts changed')
            if any(str(row[key]) != str(old[key]) for key in ['scenario','family','response','term','adjustment']):
                raise ValueError('Profile model definition changed')
            if math.isfinite(float(old['estimate'])) and not math.isclose(float(old['estimate']),float(row['estimate']),rel_tol=1e-8,abs_tol=1e-10):
                raise ValueError('Firth point estimate changed during inference-only migration')
        row.update(inference_schema=config['inference_schema'],method=config['method'])
        if str(row['model_status']).startswith('Estimated'):
            profile_inference_values(dict(row,odds_ratio=row['estimate']),config)
        elif any(str(row.get(key,'')) not in {'','NA','nan'} for key in ['conf_low','conf_high','p_value']):
            raise ValueError('Unavailable profile inference must be suppressed without fallback')
    columns=list(model_input['columns'])
    for key in ['inference_schema','method']:
        if key not in columns:columns.append(key)
    replacement=input_object('models.csv',columns,rows)
    result['aggregate_inputs']=[replacement if i['filename']=='models.csv' else i for i in result['aggregate_inputs']]
    by_id={row['model_id']:row for row in rows}
    table=next(t for t in result['tables'] if t.get('content_id')=='baseline_response_associations' or t['title']=='Baseline and response associations')
    for panel in table['panels']:
        for displayed in panel['rows']:
            if displayed.get('model_id'):
                row=by_id[displayed['model_id']]
                if str(row['model_status']).startswith('Estimated'):
                    estimate,low,high,p=[float(row[key]) for key in ['estimate','conf_low','conf_high','p_value']]
                    displayed['cells'][-2:]=[f'{estimate:.2f} ({low:.2f}–{high:.2f})','<0.0001' if p<.0001 else f'{p:.4f}']
                else:displayed['cells'][-2:]=['Unavailable','Unavailable']
    if 'strict_response_pr_adjusted' in by_id:
        note=sparse_response_note(by_id['strict_response_pr_adjusted'])
        for panel in table['panels']:
            if panel.get('notes'):
                panel['notes']=[note if 'all with at least a partial response' in old_note else old_note for old_note in panel['notes']]
    wording='Odds ratios have 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values. Treatment courses are treated as independent; inference does not adjust for repeated courses within patients.'
    table['caption']=re.sub(r'Bootstrap inference uses .*?valid variance\.',wording,table['caption'])
    if wording not in table['caption']:raise ValueError('Unexpected baseline/response inference caption')
    if 'Code/model_functions.R' not in table['code_files']:table['code_files'].append('Code/model_functions.R')
    table['logistic_inference']=copy.deepcopy(config)
    for name,panel in zip(panel_input_names(table),table['panels']):
        result['aggregate_inputs']=[table_input(name,panel) if i['filename']==name else i for i in result['aggregate_inputs']]
    figure=require_one(result['figures'],label='Figure 4')
    figword='Panels A–C use 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values, treating courses as independent without adjustment for repeated courses within patients.'
    figure['caption']=re.sub(r'Inference uses 1,000 bootstrap resamples .*?successful resamples\.',figword,figure['caption'])
    figure['caption']=figure['caption'].replace(figword.replace('Panels A–C','Panels A and B'),figword)
    if figword not in figure['caption']:raise ValueError('Unexpected Figure 4 inference caption')
    figure['logistic_inference']=copy.deepcopy(config)
    result['logistic_inference']=copy.deepcopy(config)
    return result


def register_table_s3_immune(manifest, config):
    """Present registered Firth profile/PLR results; never fit from aggregate counts."""
    result = copy.deepcopy(manifest)
    inputs = {item['filename']: item for item in result['aggregate_inputs']}
    filename = config['aggregate_filename']
    if filename not in inputs:
        raise ValueError('Fit and register immune models from restricted courses before building Table S3')
    rows = input_rows(inputs[filename])
    specs = config['models']
    if len(rows) != len(specs) or len({r['field'] for r in rows}) != len(rows):
        raise ValueError('Immune model fields must appear once each')
    candidates = [t for t in result['tables'] if t.get('content_id') == config['content_id'] or
                  t['title'] == 'Comparative response and immune toxicities']
    if len(candidates) != 1: raise ValueError('Immune association table identity is ambiguous')
    table = candidates[0]
    panel = table['panels'][1]
    old_rows = {row['cells'][0]: row for row in panel['rows']}
    displayed = []
    for spec in specs:
        row = require_one(rows, field=spec['field'])
        if row['model_id'] != spec['model_id']:
            raise ValueError('Immune model ID conflicts with registration')
        counts = {key: integer_count(row,key) for key in ['flare_events','flare_evaluable',
                  'comparison_events','comparison_evaluable','n_courses','n_patient_clusters']}
        if not (0 <= counts['flare_events'] <= counts['flare_evaluable'] and
                0 <= counts['comparison_events'] <= counts['comparison_evaluable'] and
                counts['n_courses'] == counts['flare_evaluable'] + counts['comparison_evaluable'] and
                0 < counts['n_patient_clusters'] <= counts['n_courses']):
            raise ValueError('Invalid immune model counts')
        fractions = []
        for group in ['flare','comparison']:
            events, total = counts[group+'_events'], counts[group+'_evaluable']
            if not total: raise ValueError('Immune group has no evaluable courses')
            fractions.append(f'{events:,}/{total:,} ({100*events/total:.1f}%)')
        if old_rows[spec['label']]['cells'][1:3] != fractions:
            raise ValueError('Immune model counts differ from existing displayed counts')
        estimate, low, high, p = profile_inference_values(row,config)
        displayed.append({'kind':'row','model_id':row['model_id'],
            'cells':[spec['label']]+fractions+[f'{estimate:.2f} ({low:.2f}–{high:.2f})',
                                            '<0.0001' if p<0.0001 else f'{p:.4f}']})
    panel['headers'] = panel['headers'][:3]+['OR (95% CI)','P value']
    panel['rows'] = displayed
    old = 'CRS, ICANS, and treatment tocilizumab use evaluable denominators and two-sided Fisher exact tests in the primary population. These exploratory comparisons do not account for repeated courses within patients or establish temporal order or causation.'
    new = 'Panel B reports unadjusted Firth logistic odds ratios comparing flare with no-flare courses, with 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values. Treatment courses are treated as independent; inference does not adjust for repeated courses within patients. These exploratory associations do not establish temporal order or causation.'
    if old in table['caption']:
        table['caption'] = table['caption'].replace(old,new).replace('CR, complete response;', 'CI, confidence interval; CR, complete response;').replace('MR, minimal response;', 'MR, minimal response; OR, odds ratio;')
    elif 'Panel B reports unadjusted Firth logistic odds ratios' in table['caption'] and new not in table['caption']:
        table['caption']=re.sub(r'Panel B reports unadjusted Firth logistic odds ratios.*?These exploratory associations do not establish temporal order or causation\.',new,table['caption'])
    elif new not in table['caption']: raise ValueError('Unexpected immune table caption')
    for source in ['Publication/calculate_table_s3_immune.R','Code/model_functions.R']:
        if source not in table['code_files']: table['code_files'].append(source)
    display_name = panel_input_names(table)[1]
    replacement = table_input(display_name,panel)
    result['aggregate_inputs'] = [replacement if i['filename']==display_name else i for i in result['aggregate_inputs']]
    if filename not in table['aggregate_files']: table['aggregate_files'].append(filename)
    table['immune_inference'] = copy.deepcopy(config)
    return result


def register_figure4_associations(manifest, config):
    """Register a display selection and layout; retain every analytical input."""
    if config.get('schema') != 'tumor-flare-figure4-panels-v1':
        raise ValueError('Unsupported Figure 4 panel registration')
    panels = config['panels']
    if ([p['panel'] for p in panels] != ['A', 'B', 'C', 'D'] or
            [p['metric'] for p in panels] != ['OR', 'OR', 'OR', 'HR'] or
            [len(p['model_ids']) for p in panels] != [6, 2, 3, 2]):
        raise ValueError('Figure 4 requires 6/2/3/2 registered models in panels A/B/C/D')
    ids = [model_id for panel in panels for model_id in panel['model_ids']]
    if len(set(ids)) != 13:
        raise ValueError('Figure 4 model IDs must be unique')
    if config['aggregate_files'] != ['models.csv', 'survival_models.csv', 'Table_S3_Immune_Associations.csv']:
        raise ValueError('Figure 4 requires the three registered aggregate dependencies')
    result = copy.deepcopy(manifest)
    figure = require_one(result['figures'], label='Figure 4')
    for key in ['title', 'caption', 'aggregate_files', 'axis_specification']:
        figure[key] = copy.deepcopy(config[key])
    figure['association_registration'] = {
        'schema': config['schema'], 'panels': copy.deepcopy(panels),
        'layout': copy.deepcopy(config['layout']), 'model_refitting': False,
        'cox_model_id_scope': 'Display-only IDs derived from the unchanged scenario, endpoint, and adjusted model'}
    source = 'Publication/streamline_publication_manifest.py'
    if source not in figure.setdefault('code_files', []):
        figure['code_files'].append(source)
    return result


def register_figure_layout_fonts(manifest, config):
    """Register physical font matching to unchanged Figure 2 at Word width."""
    if config.get('schema') != 'tumor-flare-figure-layout-fonts-v1':
        raise ValueError('Unsupported figure typography registration')
    roles = config['reference_font_roles']
    required = {'panel_title_pt', 'label_pt', 'axis_title_pt', 'number_mm'}
    if set(roles) != required or any(not math.isfinite(float(v)) or float(v) <= 0 for v in roles.values()):
        raise ValueError('Figure typography requires positive role sizes with explicit units')
    reference_width, embed_width = [float(config[k]) for k in ['reference_width_inches', 'word_embed_width_inches']]
    if not all(math.isfinite(v) and v > 0 for v in [reference_width, embed_width]):
        raise ValueError('Figure typography requires positive physical widths')
    productions = config['figures']
    if [p['label'] for p in productions] != ['Figure 3', 'Figure 4']:
        raise ValueError('Only Figure 3 and Figure 4 typography may change')
    result = copy.deepcopy(manifest)
    for spec in productions:
        width, height = [float(spec[k]) for k in ['export_width_inches', 'export_height_inches']]
        if not all(math.isfinite(v) and v > 0 for v in [width, height]):
            raise ValueError('Figure export dimensions must be positive')
        scale = width / reference_width
        native = {key: float(value) * scale for key, value in roles.items()}
        word = {key: float(value) * embed_width / reference_width for key, value in roles.items()}
        word['number_pt'] = word['number_mm'] * 72.27 / 25.4
        figure = require_one(result['figures'], label=spec['label'])
        figure['production'] = {
            'schema': config['schema'], 'export_inches': [width, height],
            'png_dpi': 320, 'font_family': config['font_family'],
            'word_embed_width_inches': embed_width,
            'word_embed_height_inches': height * embed_width / width,
            'typography_reference': config['reference_figure'],
            'reference_width_inches': reference_width,
            'native_font_scale': scale, 'reference_font_roles': copy.deepcopy(roles),
            'native_font_roles': native, 'word_font_roles': word}
        if 'panel_heights' in spec:
            figure['production']['panel_heights'] = copy.deepcopy(spec['panel_heights'])
    return result


COX_PH_COLUMNS = (
    'scenario', 'endpoint', 'model', 'n_courses', 'n_patient_clusters',
    'exposed_courses', 'unexposed_courses', 'courses_with_unexposed_time',
    'events', 'exposed_events', 'unexposed_events', 'total_model_eligible_courses',
    'excluded_missing', 'ph_global_chisq', 'ph_global_df', 'ph_global_p',
    'ph_flare_chisq', 'ph_flare_df', 'ph_flare_p', 'ph_method', 'ph_transform',
    'ph_status', 'ph_warning_count', 'ph_diagnostic',
    'ph_finite_transformed_times_and_residuals', 'ph_test_patient_cluster_robust')


def ph_score_p_value(statistic, degrees):
    """Upper-tail chi-square probability for the prespecified one/seven df."""
    if degrees not in [1, 7] or statistic < 0:
        raise ValueError('Unsupported PH score degrees of freedom or statistic')
    x = statistic / 2
    if x == 0:
        return 1.0
    probability = math.erfc(math.sqrt(x))
    shape = .5
    while shape < degrees / 2:
        probability += math.exp(shape * math.log(x) - x - math.lgamma(shape + 1))
        shape += 1
    return probability


def cox_ph_notes(rows, config):
    """Build publication notes from the full-precision diagnostic sidecar."""
    def ph(scenario, endpoint, model, key='ph_global_p'):
        return float(require_one(rows, scenario=scenario, endpoint=endpoint, model=model)[key])
    def pair(scenario, endpoint):
        model = 'Adjusted: six baseline variables'
        return f"{ph(scenario, endpoint, model):.4f}/{ph(scenario, endpoint, model, 'ph_flare_p'):.4f}"
    eligible, matched = 'Unadjusted: all eligible', 'Unadjusted: adjusted subset'
    values = (
        'Primary unadjusted PH P values (global and flare-specific): all eligible courses, '
        f"PFS {ph('primary', 'PFS', eligible):.4f} and OS {ph('primary', 'OS', eligible):.4f}; "
        f"matched analysis populations, PFS {ph('primary', 'PFS', matched):.4f} and OS {ph('primary', 'OS', matched):.4f}. "
        'Global/flare P values for adjusted models: '
        f"Primary analysis, PFS {pair('primary', 'PFS')} and OS {pair('primary', 'OS')}; "
        f"Definite/Probable analysis, PFS {pair('strict', 'PFS')} and OS {pair('strict', 'OS')}; "
        f"largest contributing site excluded, PFS {pair('without_dominant_site', 'PFS')} and OS {pair('without_dominant_site', 'OS')}.")
    words = {1:'one', 2:'two', 3:'three', 4:'four', 5:'five',
             6:'six', 7:'seven', 8:'eight', 9:'nine', 10:'ten'}
    counts = [integer_count(require_one(rows, scenario='strict', endpoint=e, model=matched), 'exposed_events')
              for e in ['PFS', 'OS']]
    qualification = (
        'In Definite/Probable analyses, PH departures were also detected in the unadjusted matched analysis populations '
        f"(PFS P = {ph('strict', 'PFS', matched):.4f} and OS P = {ph('strict', 'OS', matched):.4f}), "
        f"with {words.get(counts[0], str(counts[0]))} and {words.get(counts[1], str(counts[1]))} events after flare onset, respectively. "
        'Non-significant tests do not establish proportional hazards; few events during exposed time limit the power of flare-specific tests. '
        'A single adjusted HR should therefore be interpreted cautiously as a constant association over follow-up. '
        f"Full diagnostics for all {len(rows)} clinical time-dependent models are provided in the online supplement's extractable aggregate inputs. "
        'PH diagnostics were not evaluated for landmark analyses.')
    return [config['method_note'], values, qualification]


def register_cox_ph_diagnostics(manifest, diagnostics, config):
    """Register diagnostic results without exposing additional association estimates."""
    if (config.get('schema') != 'tumor-flare-cox-ph-reporting-v1' or
            config.get('test_method') != 'Model-based Schoenfeld-residual score diagnostic' or
            config.get('time_transform') != 'km' or config.get('patient_cluster_robust') is not False or
            config.get('time_scale') != 'Treatment time' or config.get('landmark_diagnostics') is not False):
        raise ValueError('Unsupported clinical PH reporting contract')
    if diagnostics.get('filename') != config['aggregate_filename'] or diagnostics.get('columns') != list(COX_PH_COLUMNS):
        raise ValueError('Clinical PH diagnostics require the approved aggregate-only schema')
    rows = input_rows(diagnostics)
    expected = {(s, e, model) for s in ['primary', 'strict', 'without_dominant_site']
                for e in ['PFS', 'OS'] for model in
                ['Unadjusted: all eligible', 'Unadjusted: adjusted subset', 'Adjusted: six baseline variables']}
    keys = [(r['scenario'], r['endpoint'], r['model']) for r in rows]
    if len(keys) != 18 or set(keys) != expected:
        raise ValueError('PH diagnostics require exactly 18 unique clinical model populations')
    count_columns = COX_PH_COLUMNS[3:13]
    for row in rows:
        for key in count_columns:
            integer_count(row, key)
        counts = {k: integer_count(row, k) for k in count_columns}
        if (counts['n_courses'] != counts['exposed_courses'] + counts['unexposed_courses'] or
                counts['events'] != counts['exposed_events'] + counts['unexposed_events'] or
                counts['n_courses'] + counts['excluded_missing'] != counts['total_model_eligible_courses'] or
                not 0 < counts['n_patient_clusters'] <= counts['n_courses']):
            raise ValueError('PH diagnostic population counts are inconsistent')
        if (row['ph_method'] != 'survival::cox.zph; model-based score diagnostic' or
                row['ph_transform'] != 'km' or row['ph_status'] not in ['computed', 'computed_with_warnings'] or
                str(row['ph_finite_transformed_times_and_residuals']).upper() != 'TRUE' or
                str(row['ph_test_patient_cluster_robust']).upper() != 'FALSE'):
            raise ValueError('PH methods and availability must match the registered model-based KM diagnostic')
        values = {k: float(row[k]) for k in ['ph_global_chisq', 'ph_global_df', 'ph_global_p',
                  'ph_flare_chisq', 'ph_flare_df', 'ph_flare_p']}
        if (not all(math.isfinite(v) for v in values.values()) or
                any(values[k] < 0 for k in ['ph_global_chisq', 'ph_flare_chisq']) or
                any(not 0 <= values[k] <= 1 for k in ['ph_global_p', 'ph_flare_p']) or
                values['ph_flare_df'] != 1 or values['ph_global_df'] != (7 if row['model'].startswith('Adjusted') else 1)):
            raise ValueError('PH score statistics, degrees of freedom, and P values are invalid')
        if any(not math.isclose(values['ph_' + term + '_p'],
                ph_score_p_value(values['ph_' + term + '_chisq'], values['ph_' + term + '_df']),
                rel_tol=1e-9, abs_tol=1e-12) for term in ['global', 'flare']):
            raise ValueError('PH P value disagrees with its score statistic and degrees of freedom')
        if row['model'].startswith('Unadjusted') and any(
                not math.isclose(values['ph_global_' + key], values['ph_flare_' + key], rel_tol=1e-12, abs_tol=1e-14)
                for key in ['chisq', 'df', 'p']):
            raise ValueError('Single-predictor global and flare-specific PH diagnostics must coincide')
        warnings = integer_count(row, 'ph_warning_count')
        if (row['ph_status'] == 'computed' and warnings != 0 or
                row['ph_status'] == 'computed_with_warnings' and (warnings == 0 or not row['ph_diagnostic'])):
            raise ValueError('PH diagnostic status must match its warning information')
    result = copy.deepcopy(manifest)
    selected = input_rows(require_one(result['aggregate_inputs'], filename='survival_models.csv'))
    for old in selected:
        row = require_one(rows, scenario=old['scenario'], endpoint=old['endpoint'], model=old['model'])
        for key in count_columns:
            if key in old and integer_count(old, key) != integer_count(row, key):
                raise ValueError('PH population counts disagree with selected survival models')
        for key in ['ph_global_p', 'ph_flare_p']:
            if old.get(key) not in ['', None, 'NA'] and not math.isclose(float(old[key]), float(row[key]), rel_tol=1e-10, abs_tol=1e-12):
                raise ValueError('PH values disagree with registered survival diagnostics')
    existing = [i for i in result['aggregate_inputs'] if i['filename'] == config['aggregate_filename']]
    if len(existing) > 1:
        raise ValueError('Duplicate clinical PH aggregate input')
    result['aggregate_inputs'] = [copy.deepcopy(diagnostics) if i['filename'] == config['aggregate_filename'] else i
                                 for i in result['aggregate_inputs']]
    if not existing:
        result['aggregate_inputs'].append(copy.deepcopy(diagnostics))
    table = require_one(result['tables'], label='Table S4')
    panel = table['panels'][0]
    other_notes = [n for n in panel.get('notes', []) if not n.startswith((
        'PH global/flare', 'PH diagnostics used', 'Primary unadjusted PH',
        'In Definite/Probable analyses, PH departures'))]
    panel['notes'] = cox_ph_notes(rows, config) + other_notes
    table['caption'] = config['caption']
    if config['aggregate_filename'] not in table['aggregate_files']:
        table['aggregate_files'].append(config['aggregate_filename'])
    for source in ['Code/model_functions.R', 'Code/summary_functions.R', 'Code/run_analysis.R']:
        if source not in table['code_files']:
            table['code_files'].append(source)
    table['ph_diagnostics'] = {k: copy.deepcopy(config[k]) for k in [
        'schema', 'aggregate_filename', 'test_method', 'time_transform',
        'patient_cluster_robust', 'time_scale', 'landmark_diagnostics']}
    result['ph_diagnostics'] = copy.deepcopy(table['ph_diagnostics'])
    for section in result.get('shared_sections', []):
        if section['title'] == 'Time-dependent survival, follow-up, and sensitivity analyses':
            for source in ['Code/model_functions.R', 'Code/summary_functions.R', 'Code/run_analysis.R']:
                if source not in section['code_files']:
                    section['code_files'].append(source)
    return result


LANDMARK_ADJUSTED_INPUT = 'Adjusted_Landmark_Models.csv'
SMITH_ZEE_STEM = 'Figure_S1_Smith_Zee_Survival'
RETIRED_LANDMARK_INPUTS = {'Table_S4_Landmark_Models.csv', 'landmark_km_steps.csv', 'landmark_risk_counts.csv'}


def read_release_csv(path, columns):
    with path.open(newline='', encoding='utf-8') as stream:
        reader = csv.DictReader(stream)
        if reader.fieldnames != columns:
            raise ValueError(f'Unexpected columns in {path.name}')
        rows = list(reader)
    if any(None in row or None in row.values() for row in rows):
        raise ValueError(f'Incomplete CSV record in {path.name}')
    return rows


def register_adjusted_landmark_smith_zee(manifest, results, registration):
    """Update selected Table S5 and Figure S1 from the shared aggregate exports."""
    from build_publication import SMITH_ZEE_INPUT, SVG_PREFIX, validate_manifest

    landmark_fields = ['endpoint', 'landmark_day', 'n_courses', 'n_patient_clusters',
        'exposed_courses', 'exposed_events', 'events', 'excluded_missing', 'estimate',
        'conf_low', 'conf_high', 'p_value', 'model_status', 'fit_reason', 'object_id']
    landmark = read_release_csv(results / LANDMARK_ADJUSTED_INPUT, landmark_fields)
    if [(r['endpoint'], int(r['landmark_day'])) for r in landmark] != [
        (endpoint, day) for endpoint in ('PFS', 'OS') for day in (30, 60)
    ]:
        raise ValueError('Table S5 requires four ordered adjusted landmark rows')
    rows = []
    for record in landmark:
        endpoint, day = record['endpoint'], record['landmark_day']
        n, patients, exposed, exposed_events, events, excluded = (
            int(record[key]) for key in landmark_fields[2:8]
        )
        if not (0 <= exposed_events <= exposed <= n and exposed_events <= events <= n
                and 0 <= patients <= n and excluded >= 0):
            raise ValueError(f'Inconsistent counts for {endpoint} day {day}')
        status = record['model_status']
        reason = record['fit_reason'].strip()
        if status == 'Not estimable':
            if not reason or any(record[key] not in ('', 'NA') for key in landmark_fields[8:12]):
                raise ValueError(f'Invalid model reporting for {endpoint} day {day}')
            hr, p_text = f'Not estimable. {reason}', '—'
        else:
            estimate, low, high, p = (float(record[key]) for key in landmark_fields[8:12])
            if not (all(math.isfinite(x) for x in (estimate, low, high, p))
                    and 0 < low <= estimate <= high and 0 <= p <= 1):
                raise ValueError(f'Invalid estimate for {endpoint} day {day}')
            hr, p_text = f'{estimate:.2f} ({low:.2f}–{high:.2f})', f'{p:.4f}'
        rows.append({'kind': 'row', 'cells': [f'{endpoint}\nDay {day} landmark',
                     f'{n} / {patients}', f'{exposed} / {exposed_events}', str(events),
                     str(excluded), hr, p_text], 'object_id': record['object_id']})
    if len({r['object_id'] for r in rows}) != 4 or any(not r['object_id'] for r in rows):
        raise ValueError('Adjusted landmark models require distinct object IDs')

    prediction_fields = ['endpoint', 'history', 'day', 'survival', 'lower95', 'upper95']
    predictions = read_release_csv(results / SMITH_ZEE_INPUT, prediction_fields)
    curves = {}
    for record in predictions:
        key = record['endpoint'], record['history']
        day, survival, low, high = (float(record[x]) for x in prediction_fields[2:])
        if not (all(math.isfinite(x) for x in (day, survival, low, high))
                and day >= 0 and 0 <= low <= survival <= high <= 1):
            raise ValueError('Invalid Figure S1 day or probabilities')
        curve = curves.setdefault(key, {})
        if day in curve:
            raise ValueError('Duplicate Figure S1 time within a history')
        curve[day] = survival, low, high
    if set(curves) != {(endpoint, history) for endpoint in ('PFS', 'OS')
                      for history in ('no_flare', 'flare_day_4')}:
        raise ValueError('Figure S1 requires two histories per endpoint')
    horizon = max(curves['PFS', 'no_flare'])
    switch = registration['switch_day']
    checkpoints = {0, switch, horizon, *range(7, math.ceil(horizon), 7)}
    display_grid = checkpoints | set(range(0, math.ceil(horizon), 2))
    for endpoint in ('PFS', 'OS'):
        reference = curves[endpoint, 'no_flare']
        switched = curves[endpoint, 'flare_day_4']
        days = sorted(reference)
        if (reference.keys() != display_grid or reference.keys() != switched.keys()
                or days[-1] != horizon or horizon < 90 or reference[0] != (1., 1., 1.)
                or switched[0] != (1., 1., 1.)):
            raise ValueError('Figure S1 histories need the fixed display grid and all weekly checkpoints')
        for previous, day in zip(days, days[1:]):
            if reference[previous][0] < reference[day][0] - 1e-12 or switched[previous][0] < switched[day][0] - 1e-12:
                raise ValueError('Figure S1 survival probability increases over time')
        if any(reference[day] != switched[day] for day in days if day <= switch):
            raise ValueError('Figure S1 histories must coincide through the switch day')

    methods = json.loads((results / 'Figure_S1_Methods.json').read_text(encoding='utf-8'))
    profile_keys = {'age10', 'ecog2', 'female', 'prior_lines', 'hrca', 'true_emd'}
    profile = methods['baseline_profile']
    if (methods['switch_day'] != switch or methods['display_months'] not in (3, 6, 9, 12)
            or abs(horizon - methods['display_months'] * methods['days_per_month']) > 1e-12
            or methods['method'] != 'survival::survfit.coxph' or methods['confidence_level'] != .95
            or methods['confidence_type'] != 'log' or set(profile) != profile_keys
            or not all(math.isfinite(value) for value in profile.values())):
        raise ValueError('Figure S1 methods metadata do not match the approved survival analysis')

    png = (results / f'{SMITH_ZEE_STEM}.png').read_bytes()
    pdf = (results / f'{SMITH_ZEE_STEM}.pdf').read_bytes()
    svg = (results / f'{SMITH_ZEE_STEM}.svg').read_bytes()
    caption = (results / 'Figure_S1_Caption.txt').read_text(encoding='utf-8').strip()
    if not png.startswith(b'\x89PNG\r\n\x1a\n') or not pdf.startswith(b'%PDF-') or not caption:
        raise ValueError('Supply the approved Figure S1 caption, PNG, and PDF')
    result = copy.deepcopy(manifest)
    table = require_one(result['tables'], label='Table S5')
    panel, = table['panels']
    section = next(i for i, row in enumerate(panel['rows']) if row['cells'] == ['Landmark analyses']
                   or row['cells'] == ['Adjusted landmark analyses'])
    panel['rows'] = panel['rows'][:section] + [{'kind': 'group', 'cells': ['Adjusted landmark analyses']}] + rows
    old_method = ('Adjusted sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest '
                  'contributing site. Landmark analyses begin follow-up at days 30 and 60 among eligible courses '
                  'and fix flare status at each landmark.')
    new_method = ('Adjusted time-dependent sensitivity analyses restrict flare to Definite/Probable cases or exclude '
                  'the largest contributing site. Adjusted landmark models use the same six baseline variables, '
                  'Efron ties, and patient-clustered robust standard errors. Follow-up restarts at day 30 or 60 among '
                  'event-free courses with further follow-up and complete covariate data. Flare status is fixed at '
                  'each landmark. Courses that flare later remain in the no-flare-by-landmark group.')
    if old_method not in table['caption'] and new_method not in table['caption']:
        raise ValueError('The Table S5 methods caption has changed')
    table['caption'] = table['caption'].replace(old_method, new_method)
    if 'notes' in panel:
        panel['notes'] = [note.replace(' PH diagnostics were not evaluated for landmark analyses.', '')
                          for note in panel['notes']]
    table['aggregate_files'] = [LANDMARK_ADJUSTED_INPUT if item == 'Table_S4_Landmark_Models.csv' else item
                                for item in table['aggregate_files']]
    for code in registration['code_files'][:2]:
        if code not in table['code_files']:
            table['code_files'].append(code)
    figure = require_one(result['figures'], label='Figure S1')
    figure.clear()
    figure.update({'label': 'Figure S1', 'title': registration['title'], 'caption': caption,
                   'alt_text': registration['alt_text'], 'code_files': registration['code_files'],
                   'aggregate_files': [SMITH_ZEE_INPUT],
                   'image_data_url': 'data:image/png;base64,' + base64.b64encode(png).decode('ascii'),
                   'svg_data_url': SVG_PREFIX + base64.b64encode(svg).decode('ascii'),
                   'pdf_data_url': 'data:application/pdf;base64,' + base64.b64encode(pdf).decode('ascii'),
                   'prediction_method': {
                       **methods,
                       'source_models': 'Primary adjusted time-dependent Cox models',
                       'display_horizon_days': horizon,
                       'display_horizon_months': methods['display_months'],
                   }})
    table_csv = {'filename': 'Table_S5.csv', 'columns': panel['headers'],
                 'rows': [r['cells'] + [''] * (len(panel['headers']) - len(r['cells'])) for r in panel['rows']]}
    result['aggregate_inputs'] = [item for item in result['aggregate_inputs']
                                  if item['filename'] not in RETIRED_LANDMARK_INPUTS |
                                  {SMITH_ZEE_INPUT, LANDMARK_ADJUSTED_INPUT, 'Table_S5.csv'}]
    result['aggregate_inputs'].extend([input_object(LANDMARK_ADJUSTED_INPUT, landmark_fields, landmark),
                                       input_object(SMITH_ZEE_INPUT, prediction_fields, predictions), table_csv])
    validate_manifest(result)
    return result


def register_figure_s2(manifest, aggregate_csv, image_png, registration):
    """Register the rendered response figure and the aggregate rows used to draw it."""
    from build_publication import FIGURE_S2_INPUT

    with aggregate_csv.open(newline="", encoding="utf-8") as stream:
        reader = csv.reader(stream)
        columns = next(reader)
        rows = list(reader)
    expected = ["confidence", "total_n", "sd_pd_or_na_n", "at_least_pr_n",
                "unavailable_n", "minimal_response_n"]
    if columns != expected or [row[0] for row in rows] != ["Definite", "Probable", "Possible"]:
        raise ValueError("Figure S2 requires one aggregate row per confidence group")
    png = image_png.read_bytes()
    if not png.startswith(b"\x89PNG\r\n\x1a\n"):
        raise ValueError("Figure S2 requires the PNG from the shared figure builder")
    item = {"filename": FIGURE_S2_INPUT, "columns": columns, "rows": rows}
    figure = {"label": "Figure S2", **registration, "aggregate_files": [FIGURE_S2_INPUT],
              "image_data_url": "data:image/png;base64," + base64.b64encode(png).decode("ascii")}
    result = copy.deepcopy(manifest)
    result["aggregate_inputs"] = [x for x in result["aggregate_inputs"] if x["filename"] != FIGURE_S2_INPUT] + [item]
    result["figures"] = [x for x in result["figures"] if x["label"] != "Figure S2"] + [figure]
    return result


def apply_publication_metadata(manifest, selection):
    """Update publication text without repeating display selection or modeling."""
    result = copy.deepcopy(manifest)
    metadata = selection.get('publication_metadata', {})
    allowed = {'title', 'author', 'build_date', 'overview', 'shared_introduction', 'download_label'}
    if set(metadata) - allowed or any(not isinstance(value, str) for value in metadata.values()):
        raise ValueError('Publication metadata must contain approved text fields only')
    result.update(metadata)
    rain = selection.get('display_registration_updates', {}).get('figure5_rain', {})
    if 'caption' in rain:
        if not isinstance(rain['caption'], str) or not rain['caption'].strip():
            raise ValueError('Figure 5 caption must contain publication text')
        figure = require_one(result['figures'], label='Figure 5')
        figure['caption'] = rain['caption']
        figure.setdefault('framework_registration', {})['caption'] = rain['caption']
        if 'title' in rain:
            if not isinstance(rain['title'], str) or not rain['title'].strip():
                raise ValueError('Figure 5 title must contain publication text')
            figure['title'] = rain['title']
    figure3 = selection.get('display_registration_updates', {}).get('figure3_statuses')
    if figure3:
        result = register_figure3_statuses(result, figure3)
    immune = selection.get('display_registration_updates', {}).get('table_s3_immune')
    if immune and any(t.get('content_id') == immune['content_id'] or t.get('title') == 'Comparative response and immune toxicities' for t in result.get('tables', [])):
        result = register_table_s3_immune(result, immune)
    figure4 = selection.get('display_registration_updates', {}).get('figure4_associations')
    if figure4:
        result = register_figure4_associations(result, figure4)
    fonts = selection.get('display_registration_updates', {}).get('figure_layout_fonts')
    if fonts:
        result = register_figure_layout_fonts(result, fonts)
    ph = selection.get('display_registration_updates', {}).get('cox_ph_diagnostics')
    if ph and any(i['filename'] == ph['aggregate_filename'] for i in result['aggregate_inputs']):
        result = register_cox_ph_diagnostics(result, require_one(result['aggregate_inputs'], filename=ph['aggregate_filename']), ph)
    elif result.get('ph_diagnostics'):
        raise ValueError('The registered clinical PH aggregate input is missing')
    result.setdefault('presentation_selection', {})['configuration_sha256'] = digest(selection)
    return apply_supplementary_table_order(result, selection)


def verify_consolidation(before, after, selection):
    before = legacy_table_order(before, selection)
    expected_before = apply_publication_metadata(before, selection)
    expected_before = legacy_table_order(expected_before, selection)
    after = legacy_table_order(after, selection)
    checks = []
    def check(name, condition):
        checks.append({"check": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)
    old = {table["label"]: table for table in before["tables"]}
    new = {table["label"]: table for table in after["tables"]}
    check("Four numbered supplementary tables and seven physical tables", [len(new[label]["panels"]) for label in ("Table S1", "Table S2", "Table S3", "Table S4")] == [1, 2, 2, 2])
    for label in ("Table 1", "Table 2", "Table S2"):
        check(label + " matches registered presentation", next(t for t in expected_before["tables"] if t["label"]==label) == new[label])
    expected_figures = apply_publication_metadata(before, selection)["figures"]
    check("All figure objects unchanged except a registered publication caption",
          after["figures"] == before["figures"] or after["figures"] == expected_figures)
    old_clinical = [row for panel in old["Table S1"]["panels"] for row in panel["rows"] if row["kind"] != "group"]
    new_clinical = [row for panel in new["Table S1"]["panels"] for row in panel["rows"] if row["kind"] != "group"]
    check("All clinical values and missing states unchanged", old_clinical == new_clinical)
    old_display_names = {name for table in before["tables"] for name in panel_input_names(table)}
    new_inputs = {item["filename"]: item for item in after["aggregate_inputs"]}
    for item in before["aggregate_inputs"]:
        if item["filename"] not in old_display_names:
            check("Analytical aggregate object unchanged: " + item["filename"], new_inputs.get(item["filename"]) == item)
    models = input_rows(new_inputs["models.csv"])
    old_models = {row["model_id"]: row for panel in old["Table S3"]["panels"] for row in panel["rows"]}
    new_models = {row["model_id"]: row for panel in new["Table S3"]["panels"] for row in panel["rows"] if row.get("model_id")}
    check("All twenty logistic model IDs retained exactly once", len(new_models) == 20 and set(new_models) == set(old_models) and sum(bool(row.get("model_id")) for panel in new["Table S3"]["panels"] for row in panel["rows"]) == 20)
    for model_id, row in new_models.items():
        original = require_one(models, model_id=model_id)
        if "response_" in model_id:
            check("Exact registered response fractions: " + model_id, tuple(row["cells"][1:3]) == response_fractions(original))
            check("Response OR and P unchanged: " + model_id, row["cells"][-2:] == old_models[model_id]["cells"][-2:])
        else:
            expected = copy.deepcopy(old_models[model_id]["cells"])
            expected[2] = original["candidates"]
            check("Baseline cells unchanged except redundant count: " + model_id, row["cells"] == expected)
    for row in new["Table S3"]["panels"][1]["rows"]:
        if row["kind"] == "group":
            raw = [require_one(models, model_id=model_id) for model_id in row["model_ids"]]
            check("Response population shared across thresholds: " + row["cells"][0].split("\n")[0], all(tuple(item[key] for key in ("n_courses", "n_patient_clusters", "excluded_missing")) == tuple(row[key] for key in ("n_courses", "n_patient_clusters", "excluded_missing")) for item in raw))
    check("Sparse strict response qualification retained", any("all with at least a partial response" in note and "does not establish a response benefit" in note for note in new["Table S3"]["panels"][1].get("notes", [])))
    old_survival = {row["object_id"]: row for panel in old["Table S4"]["panels"] for row in panel["rows"]}
    new_survival = {row["object_id"]: row for panel in new["Table S4"]["panels"] for row in panel["rows"] if row.get("object_id")}
    check("All fourteen survival IDs retained exactly once", len(new_survival) == 14 and set(old_survival) == set(new_survival) and sum(bool(row.get("object_id")) for panel in new["Table S4"]["panels"] for row in panel["rows"]) == 14)
    for object_id, row in new_survival.items():
        check("Survival counts and estimates unchanged: " + object_id, row["cells"] == old_survival[object_id]["cells"][:-1])
    ph_note = ' '.join(new["Table S4"]["panels"][0]["notes"])
    for row in old_survival.values():
        if row["cells"][-1] != "Unavailable / Unavailable":
            if 'Unadjusted:' in row['object_id'] and any(i['filename'] == 'cox_ph_diagnostics.csv' for i in after['aggregate_inputs']):
                check("Unadjusted PH value matches diagnostic note: " + row['object_id'],
                      all(value in ph_note for value in row['cells'][-1].split(' / ')))
            else:
                check("PH pair retained: " + row["object_id"], row["cells"][-1].replace(" / ", "/") in ph_note)
    if any(i['filename'] == 'cox_ph_diagnostics.csv' for i in after['aggregate_inputs']):
        check("Clinical PH diagnostics registered without a landmark PH claim",
              'PH diagnostics were unavailable for the other models.' not in ph_note and
              'PH diagnostics were not evaluated for landmark analyses.' in ph_note)
    else:
        check("Legacy PH diagnostic note unchanged", "PH diagnostics were unavailable for the other models." in ph_note)
    for table in after["tables"]:
        for panel in table["panels"]:
            check(table["label"] + ": " + panel["title"] + " widths", all(row["kind"] == "group" or len(row["cells"]) == len(panel["headers"]) for row in panel["rows"]))
        check(table["label"] + " registered inputs resolve", all(name in new_inputs for name in table["aggregate_files"]))
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def verify_selection(full, compact, selection):
    if full.get("schema") == selection["publication_schema"]:
        return verify_consolidation(full, compact, selection)
    selected = _streamline_unconsolidated(full, selection)
    old_checks = _verify_original_selection(full, selected, selection)
    new_checks = verify_consolidation(selected, compact, selection)
    checks = old_checks["checks"] + new_checks["checks"]
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def consolidate_supplementary_tables(manifest):
    """Combine registered display rows after model and diagnostic registration."""
    result = copy.deepcopy(manifest)
    tables = {table["label"]: table for table in result["tables"]}
    names = ["Table S1", "Table S2", "Table S3", "Table S4"]
    if all(len(tables[name]["panels"]) == 1 for name in names):
        return result
    if [len(tables[name]["panels"]) for name in names] != [1, 2, 2, 2]:
        raise ValueError("Expected the registered S1–S4 table layout")
    tables["Table S1"]["panels"][0].pop("title", None)
    dash = "—"

    def section(title):
        return {"kind": "group", "cells": [title]}

    def with_cells(row, *cells):
        return {**row, "cells": list(cells)}

    def combine(name, headers, rows, caption):
        table = tables[name]
        old_names = panel_input_names(table)
        notes = [note for display in table["panels"] for note in display.get("notes", [])]
        display = {"headers": headers, "rows": rows, "notes": notes,
                   "table_class": "supplementary-continuous"}
        table["panels"] = [display]
        table["caption"] = caption
        new_name, = panel_input_names(table)
        table["aggregate_files"] = [new_name] + [x for x in table["aggregate_files"] if x not in old_names]
        result["aggregate_inputs"] = [x for x in result["aggregate_inputs"] if x["filename"] not in old_names]
        result["aggregate_inputs"].append(table_input(new_name, display))

    s2 = tables["Table S2"]
    baseline, response = s2["panels"]
    rows = [section("Baseline associations")]
    for row in baseline["rows"]:
        model, population, flare, excluded, odds, p = row["cells"]
        rows.append(with_cells(row, model, population, excluded, flare, dash, dash, odds, p))
    rows.append(section("Response associations"))
    populations = {model: group for group in response["rows"] if group["kind"] == "group"
                   for model in group["model_ids"]}
    for row in response["rows"]:
        if row["kind"] == "group":
            rows.append(with_cells(row, row["cells"][0].split("\n", 1)[0]))
            continue
        threshold, flare, no_flare, odds, p = row["cells"]
        group = populations[row["model_id"]]
        population = f'{int(group["n_courses"]):,} / {int(group["n_patient_clusters"]):,}'
        excluded = f'{int(group["excluded_missing"]):,}'
        flare_courses = flare.split("/", 1)[1]
        rows.append(with_cells(row, threshold, population, excluded, flare_courses, flare, no_flare, odds, p))
    caption = s2["caption"].replace("Panel A shows", "The baseline analyses use").replace(
        "Panel B shows response models using", "Response models use").replace(
        "courses in each model; shared course, patient, and missing-data exclusion counts appear in group headings.",
        "courses in each model. An em dash indicates a quantity that does not apply.")
    combine("Table S2", ["Model or threshold", "Courses / patients", "Excluded for missing data",
             "Flare courses, n", "Flare response, n/N", "No-flare response, n/N", "OR (95% CI)", "P value"],
            rows, caption)

    s3 = tables["Table S3"]
    response, immune = s3["panels"]
    rows = [row if row["kind"] == "group" else with_cells(row, *row["cells"], dash, dash)
            for row in response["rows"]]
    rows.append(section("Immune toxicities and treatment tocilizumab"))
    for row in immune["rows"]:
        characteristic, flare, no_flare, odds, p = row["cells"]
        rows.append(with_cells(row, characteristic, flare, dash, no_flare, odds, p))
    caption = s3["caption"].replace("Panel B reports", "The immune toxicity and tocilizumab analyses report")
    caption += " An em dash indicates a quantity that does not apply or was unreported. Response model estimates are shown in Table S2."
    combine("Table S3", [*response["headers"], "OR (95% CI)", "P value"], rows, caption)

    s4 = tables["Table S4"]
    time, landmark = s4["panels"]
    rows = [section("Time-dependent analyses")]
    for row in time["rows"]:
        if row["kind"] == "group":
            rows.append(row)
            continue
        model, population, flare, events_and_excluded, hazard, p = row["cells"]
        events, excluded = events_and_excluded.split(" / ")
        rows.append(with_cells(row, model, population, flare, events, excluded, hazard, p))
    rows.append(section("Landmark analyses"))
    for row in landmark["rows"]:
        model, population, flare, events, hazard, p = row["cells"]
        rows.append(with_cells(row, model, population, flare, events, dash, hazard, p))
    caption = s4["caption"].replace(
        "Exposed events are events after flare onset or among the flare group at the landmark.",
        "For time-dependent analyses, the flare column counts courses with exposed follow-up and events after flare onset. "
        "For landmark analyses, it counts courses with flare by the landmark and their subsequent events. "
        "An em dash indicates a quantity that was unreported.")
    combine("Table S4", ["Endpoint and model", "Courses / patients", "Flare courses / events",
             "Total events", "Excluded for missing data", "HR (95% CI)", "P value"], rows, caption)
    tables["Table S4"]["panels"][0]["notes_title"] = "Proportional-hazards diagnostics for time-dependent models"
    return result


def split_association_tables(manifest):
    """Separate the registered baseline and systemic response display rows."""
    result = copy.deepcopy(manifest)
    tables = {table["label"]: table for table in result["tables"]}
    if "Table S5" in tables:
        return result
    combined = tables["Table S2"]
    display, = combined["panels"]
    baseline, response = [], []
    active_rows = baseline
    for row in display["rows"]:
        if row["cells"] == ["Baseline associations"]:
            continue
        if row["cells"] == ["Response associations"]:
            active_rows = response
            continue
        active_rows.append(row)
    if not baseline or not response or baseline[-1]["kind"] != "row" or response[0]["kind"] != "group":
        raise ValueError("Expected registered baseline and systemic response groups")
    if any(row["cells"][4:6] != ["—", "—"] for row in baseline):
        raise ValueError("Baseline models have unexpected response cells")
    if any(row["cells"][4].split("/", 1)[-1] != row["cells"][3] for row in response if row["kind"] == "row"):
        raise ValueError("Flare response denominator differs from the flare course count")

    def association_table(label, title, content_id, anchor, heading, indices, rows, caption, notes):
        return {**combined, "label": label, "title": title, "content_id": content_id, "anchor": anchor,
                "caption": caption, "panels": [{**display, "headers": [heading] + [display["headers"][i] for i in indices],
                    "rows": [{**row, "cells": [row["cells"][0]] + [row["cells"][i] for i in indices]}
                             if row["kind"] != "group" else row for row in rows], "notes": notes}]}

    original_caption = combined["caption"]
    baseline_methods, response_methods = original_caption.split(" Response models use", 1)
    response_methods, shared_methods = response_methods.split(" Odds ratios have", 1)
    response_methods = response_methods.removesuffix(" An em dash indicates a quantity that does not apply.")
    shared_methods = " Odds ratios have" + shared_methods.split(" CI, confidence interval;", 1)[0]
    baseline_caption = (baseline_methods + shared_methods + " CI, confidence interval. ECOG, Eastern Cooperative Oncology Group. "
                        "EMD, extramedullary disease. HRCA, high-risk cytogenetic abnormality. OR, odds ratio.")
    response_caption = ("Response models use" + response_methods + shared_methods +
                        " CI, confidence interval. CR, complete response. OR, odds ratio. PR, partial response. "
                        "sCR, stringent complete response. VGPR, very good partial response.")
    baseline_table = association_table("Table S2", "Baseline associations with tumor flare", "baseline_associations",
        "display-3-4", "Model", [1, 2, 3, 6, 7], baseline, baseline_caption, [])
    response_table = association_table("Table S3", "Associations between tumor flare and systemic response", "response_associations",
        "display-3-response-associations", "Response threshold", [1, 2, 4, 5, 6, 7], response, response_caption, display["notes"])
    comparative, survival = tables["Table S3"], tables["Table S4"]
    comparative.update(label="Table S4", anchor="display-3-5")
    comparative["caption"] = comparative["caption"].replace("shown in Table S2", "shown in Table S3")
    survival.update(label="Table S5", anchor="display-3-6")
    old_names = {"Table_S2.csv", "Table_S3.csv", "Table_S4.csv"}
    result["tables"] = result["tables"][:3] + [baseline_table, response_table, comparative, survival]
    result["aggregate_inputs"] = [item for item in result["aggregate_inputs"] if item["filename"] not in old_names]
    for table in result["tables"][3:]:
        name, = panel_input_names(table)
        table["aggregate_files"] = [name] + [item for item in table["aggregate_files"] if item not in old_names]
        result["aggregate_inputs"].append(table_input(name, table["panels"][0]))
    return result


def write_outputs(full, compact, selection, output_directory, checks=None):
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    aggregate_directory = output / "Aggregate_Inputs"
    aggregate_directory.mkdir(exist_ok=True)
    (output / "aggregate_publication_manifest.json").write_text(json.dumps(compact, ensure_ascii=False, indent=2) + "\n")
    for item in compact["aggregate_inputs"]:
        with (aggregate_directory / item["filename"]).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(item["columns"])
            writer.writerows(item["rows"])
    if checks is None:
        checks = verify_selection(full, compact, selection)
    (output / "streamlining_acceptance_checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    displays = []
    for display in compact['tables'] + compact['figures']:
        entry = {'label': display['label'], 'caption': display['caption'],
            'aggregate_files': display['aggregate_files'], 'executable_source': display['code_files']}
        for key in ['logistic_inference', 'immune_inference', 'ph_diagnostics', 'axis_specification', 'production',
                    'association_registration', 'status_presentation', 'density_method',
                    'framework_registration', 'frequency_method', 'prediction_method']:
            if key in display:
                entry[key] = copy.deepcopy(display[key])
        displays.append(entry)
    registry = {"schema": "tumor-flare-streamlined-display-registry-v1", "full_manifest_sha256": digest(full), "selected_manifest_sha256": digest(compact), "selection_sha256": digest(selection), "model_refitting": False, "displays": displays, "aggregate_files": [{"filename": item["filename"], "rows": len(item["rows"]), "sha256": hashlib.sha256((aggregate_directory / item["filename"]).read_bytes()).hexdigest()} for item in compact["aggregate_inputs"]]}
    (output / "streamlining_display_registry.json").write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n")
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("full_manifest", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument("--selection", type=Path, default=Path(__file__).with_name("clinical_presentation_selection.json"))
    parser.add_argument("--survival-availability-note", default="", help="Verified aggregate availability note supplied separately from generic code")
    parser.add_argument('--immune-associations', type=Path, help='Registered aggregate results from restricted-course immune models')
    parser.add_argument('--cox-ph-diagnostics', type=Path, help='Approved 18-row aggregate clinical PH diagnostics')
    parser.add_argument('--figure-s2-aggregate', type=Path, help='Figure S2 display input from the clinical exporter')
    parser.add_argument('--figure-s2-png', type=Path, help='Figure S2 image from the shared figure builder')
    parser.add_argument('--adjusted-landmark-smith-zee', type=Path, help='Directory containing the coordinated landmark and Figure S1 exports')
    parser.add_argument('--continuous-supplementary-tables', action='store_true',
                        help='Combine the registered S1–S4 displays into one table each')
    parser.add_argument('--split-association-tables', action='store_true',
                        help='Split baseline and response models into separate numbered tables')
    args = parser.parse_args()
    full = json.loads(args.full_manifest.read_text())
    if args.immune_associations:
        with args.immune_associations.open(newline='') as stream:
            reader = csv.reader(stream); columns = next(reader); rows = list(reader)
        filename = 'Table_S3_Immune_Associations.csv'
        full['aggregate_inputs'] = [i for i in full['aggregate_inputs'] if i['filename'] != filename] + [{'filename':filename,'columns':columns,'rows':rows}]
    selection = json.loads(args.selection.read_text())
    if args.cox_ph_diagnostics:
        with args.cox_ph_diagnostics.open(newline='') as stream:
            reader = csv.reader(stream); columns = next(reader); rows = list(reader)
        filename = 'cox_ph_diagnostics.csv'
        full['aggregate_inputs'] = [i for i in full['aggregate_inputs'] if i['filename'] != filename] + [
            {'filename': filename, 'columns': columns, 'rows': rows}]
    if selection.get('display_registration_updates', {}).get('cox_ph_diagnostics') and not any(
            i['filename'] == 'cox_ph_diagnostics.csv' for i in full['aggregate_inputs']):
        raise ValueError('Provide --cox-ph-diagnostics or an embedded registered clinical PH input')
    checks = None
    if bool(args.figure_s2_aggregate) != bool(args.figure_s2_png):
        parser.error('Supply the Figure S2 aggregate input and rendered PNG together')
    if args.adjusted_landmark_smith_zee:
        if args.figure_s2_aggregate or args.continuous_supplementary_tables or args.split_association_tables:
            parser.error('Stage adjusted landmark and Smith–Zee results on the latest selected publication manifest')
        registration = selection['display_registration_updates']['adjusted_landmark_smith_zee']
        compact = register_adjusted_landmark_smith_zee(full, args.adjusted_landmark_smith_zee, registration)
        compact['presentation_selection']['configuration_sha256'] = digest(selection)
        checks = {'passed': True, 'checks_count': 1,
                  'checks': [{'check': 'Validated adjusted landmark and Smith–Zee aggregate registration', 'passed': True}]}
    elif args.figure_s2_aggregate:
        if full.get('schema') != selection['publication_schema'] or not full.get('presentation_selection', {}).get('consolidation_schema'):
            parser.error('Register Figure S2 on the selected publication manifest')
        from build_publication import FIGURE_S2_INPUT, validate_manifest

        registration = selection['display_registration_updates']['figure_s2_response']
        compact = register_figure_s2(full, args.figure_s2_aggregate, args.figure_s2_png, registration)
        compact['build_date'] = selection.get('publication_metadata', {}).get('build_date', full['build_date'])
        compact['presentation_selection']['configuration_sha256'] = digest(selection)
        validate_manifest(compact)
        unchanged = {key: compact[key] == full[key] for key in full
                     if key not in {'aggregate_inputs', 'figures', 'presentation_selection', 'build_date'}}
        unchanged['figures'] = ([x for x in compact['figures'] if x['label'] != 'Figure S2'] ==
                                [x for x in full['figures'] if x['label'] != 'Figure S2'])
        unchanged['aggregate inputs'] = ([x for x in compact['aggregate_inputs'] if x['filename'] != FIGURE_S2_INPUT] ==
                                         [x for x in full['aggregate_inputs'] if x['filename'] != FIGURE_S2_INPUT])
        if not all(unchanged.values()):
            raise ValueError('Figure S2 registration changed an existing display or aggregate')
        checks = {'passed': True, 'checks_count': len(unchanged),
                  'checks': [{'check': f'Preserved existing {key}', 'passed': passed}
                             for key, passed in unchanged.items()]}
    elif args.continuous_supplementary_tables or args.split_association_tables:
        if not full.get("presentation_selection", {}).get("consolidation_schema"):
            parser.error("Provide the selected publication manifest after model and diagnostics registration")
        compact = full
    else:
        compact = streamline(full, selection, args.survival_availability_note)
    if args.continuous_supplementary_tables or args.split_association_tables:
        from build_publication import validate_manifest

        if not any(table["label"] == "Table S5" for table in compact["tables"]):
            compact = consolidate_supplementary_tables(compact)
        if args.split_association_tables:
            compact = split_association_tables(compact)
        validate_manifest(compact)
        checks = {'passed': True, 'checks_count': 1,
                  'checks': [{'check': 'Validated the registered aggregate manifest', 'passed': True}]}
    checks = write_outputs(full, compact, selection, args.output_directory, checks)
    print(f'Selected {len(compact["tables"])} tables, {len(compact["figures"])} figures, and {len(compact["aggregate_inputs"])} aggregate inputs; {checks["checks_count"]} checks passed.')


if __name__ == "__main__":
    main()
