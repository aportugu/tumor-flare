#!/usr/bin/env Rscript
# Publication figures from the canonical, reconciled tumor-flare analysis.
# This file uses relative paths and contains no patient identifiers or dates.
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
})
args <- commandArgs(trailingOnly = TRUE)
input_dir <- if (length(args) >= 1L) args[1] else "analysis"
output_dir <- if (length(args) >= 2L) args[2] else "publication"
framework_only <- "--framework-only" %in% args
association_only <- "--association-only" %in% args
dir.create(file.path(output_dir, "Figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Display_data"), recursive = TRUE, showWarnings = FALSE)
font_family <- "Helvetica"
colours <- c("Yes" = "#1B5678", "No" = "#D6DCE0", "Unknown" = "#BB9153")
theme_paper <- function(size = 10) {
  theme_classic(base_size = size, base_family = font_family) +
    theme(plot.title = element_text(face = "bold", size = size + 1, hjust = 0),
          plot.subtitle = element_text(size = size - 1, lineheight = 1.1),
          axis.title = element_text(size = size), axis.text = element_text(colour = "#222222"),
          legend.position = "bottom", legend.title = element_blank(),
          plot.margin = margin(8, 10, 8, 8))
}
read_input <- function(name, required = character()) {
  path <- file.path(input_dir, paste0(name, ".csv"))
  if (!file.exists(path)) stop("Missing canonical output: ", path)
  x <- read_csv(path, show_col_types = FALSE, progress = FALSE)
  x <- x %>% mutate(across(where(is.character), ~gsub("\u2265", ">=", gsub("\u2013|\u2014|\u2212", "-", .x))))
  missing <- setdiff(required, names(x))
  if (length(missing)) stop(name, " lacks required columns: ", paste(missing, collapse = ", "))

  x
}
save_display_data <- function(x, name) {
  stopifnot(!any(grepl("(^|_)(course_id|patient_id|mrn|source_reference|narrative|calendar_date|start_date)$", names(x))))
  write_csv(x, file.path(output_dir, "Display_data", paste0(name, ".csv")), na = "")
}
# Use a font-embedding PDF device on each platform.
embedded_pdf <- function(filename, width, height, family, bg, ...) {
  if (Sys.info()[["sysname"]] == "Darwin") {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = family, bg = bg)
  } else {
    grDevices::cairo_pdf(filename = filename, width = width,
                        height = height, family = family, bg = bg)
  }
}
save_figure <- function(p, name, width, height, dpi = 320) {
  pdf_path <- file.path(output_dir, "Figures", paste0(name, ".pdf"))
  png_path <- file.path(output_dir, "Figures", paste0(name, ".png"))
  ggsave(pdf_path, p, device = embedded_pdf, width = width, height = height,
         units = "in", family = font_family, bg = "white")
  ggsave(png_path, p, device = ragg::agg_png, width = width, height = height,
         units = "in", dpi = dpi, bg = "white")
}
panel_title <- function(letter, title) paste0(letter, "  ", title)
box_layer <- function(x, y, w, h, label, fill = "#EEF2F4", size = 3.4) {
  list(annotate("rect", xmin = x - w/2, xmax = x + w/2, ymin = y - h/2,
                ymax = y + h/2, fill = fill, colour = "#34424B", linewidth = 0.45),
       annotate("text", x = x, y = y, label = label, family = font_family,
                size = size, lineheight = 1.1))
}
arrow_layer <- function(x, y, xend, yend, colour = "#34424B") {
  annotate("segment", x = x, y = y, xend = xend, yend = yend, colour = colour,
           linewidth = .55, arrow = grid::arrow(length = grid::unit(2.5, "mm")))
}

# DISPLAY Figure5 START
if (!association_only) {
# RAIN is a proposed clinical framework. All visible text is registered as
# aggregate content; no individual records enter this renderer.
rain_content <- read_csv(file.path(input_dir, "Figure_5_RAIN_Content.csv"),
                         show_col_types = FALSE, progress = FALSE, na = character())
stopifnot(identical(names(rain_content), c("stage", "element_id", "heading", "text")),
          !anyDuplicated(rain_content$element_id),
          identical(unique(rain_content$stage), c("R", "A", "I", "N")))
rain_text <- function(id, field = "text") {
  value <- rain_content[[field]][rain_content$element_id == id]
  if (length(value) != 1L || is.na(value)) stop("Missing RAIN content: ", id)
  value
}
rain_connections <- data.frame(
  source = c("R", "A", "I", "N"), target = c("A", "I", "N", "I"),
  kind = c("forward", "forward", "forward", "reassessment"),
  label = c("", "", "", gsub("\n", " ", rain_text("feedback"))),
  stringsAsFactors = FALSE)
rain_framework <- function(family = "Helvetica") {
  ink <- "#173247"; blue <- "#315F7C"; red <- "#A3464A"; teal <- "#2A6A66"
  stroke <- "#CED8DE"; arrow_colour <- "#7D919E"
  # Coordinates are inches, so gutters, radius, and padding remain physical
  # dimensions on both raster and vector devices.
  rounded <- function(x0, x1, y0, y1, fill, border = stroke, radius = .065, lw = .65) {
    annotation_custom(grid::roundrectGrob(
      r = grid::unit(radius, "in"), gp = grid::gpar(fill = fill, col = border, lwd = lw)),
      xmin = x0, xmax = x1, ymin = y0, ymax = y1)
  }
  text_layer <- function(id, x, y, field = "text", size = 4.265,
                         colour = ink, face = "plain", hjust = 0, vjust = .5, lineheight = 1.12) {
    annotate("text", x = x, y = y, label = rain_text(id, field),
             family = family, size = size, colour = colour, fontface = face,
             hjust = hjust, vjust = vjust, lineheight = lineheight)
  }
  badge <- function(id, y, fill) {
    list(annotation_custom(grid::circleGrob(
        gp = grid::gpar(fill = fill, col = NA)), xmin = .19, xmax = .89,
        ymin = y - .35, ymax = y + .35),
      text_layer(id, .54, y - .005, field = "heading", size = 7.86,
                 colour = "white", face = "bold", hjust = .5))
  }
  stage_heading <- function(id, y, colour) text_layer(id, 1.23, y,
                                field = "heading", size = 5.075,
                                colour = colour, face = "bold")
  forward <- function(y0, y1) annotate("segment", x = .54, y = y0,
    xend = .54, yend = y1, colour = arrow_colour, linewidth = .52,
    arrow = grid::arrow(length = grid::unit(.075, "in"), type = "closed"))
  p <- ggplot() +
    # The shared rail establishes a single, unambiguous reading sequence.
    forward(6.54, 6.35) + forward(5.55, 4.30) + forward(3.53, 1.88) +
    # R: compact recognition strip.
    rounded(1.03, 7.18, 6.35, 7.20, "#EEF4F8", "#D4E0E8") +
    badge("r_badge", 6.94, blue) + stage_heading("r_heading", 6.96, blue) +
    text_layer("recognition", 1.23, 6.69, face = "bold") +
    text_layer("recognition_timing", 1.23, 6.47) +
    # A: urgency and competing causes are evaluated alongside one another.
    rounded(1.03, 7.18, 4.37, 6.12, "#FBF1F0", "#E7CDCF") +
    badge("a_badge", 5.95, red) + stage_heading("a_heading", 5.92, red) +
    text_layer("urgent_heading", 1.23, 5.60, field = "heading", face = "bold", colour = red) +
    text_layer("urgent_complications", 1.23, 5.25) +
    annotate("segment", x = 1.23, xend = 6.98, y = 4.94, yend = 4.94,
             linewidth = .33, colour = "#E5C8CA") +
    text_layer("competing_heading", 1.23, 4.75, field = "heading", face = "bold") +
    text_layer("competing_causes", 1.23, 4.52) +
    # I: three balanced evidence cards, with the same interior padding.
    badge("i_badge", 3.90, blue) + stage_heading("i_heading", 3.91, blue) +
    rounded(1.03, 3.003, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    rounded(3.118, 5.092, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    rounded(5.207, 7.18, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    text_layer("symptoms", 1.185, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("markers", 3.273, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("imaging", 5.362, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("symptoms", 1.185, 3.02, vjust = 1) +
    text_layer("markers", 3.273, 3.02, vjust = 1) +
    text_layer("imaging", 5.362, 3.02, vjust = 1) +
    # N: decisions and the three distinct clinical outcomes.
    rounded(1.03, 7.18, .14, 1.66, "#EDF5F3", "#CDDEDA") +
    badge("n_badge", 1.48, teal) + stage_heading("n_heading", 1.45, teal) +
    text_layer("treatment", 1.23, 1.16, face = "bold") +
    text_layer("reassessment_heading", 1.23, .88, field = "heading", colour = teal, face = "bold") +
    rounded(1.23, 3.067, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    rounded(3.186, 5.023, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    rounded(5.142, 6.98, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    text_layer("symptom_outcome", 2.1485, .495, size = 3.95, hjust = .5) +
    text_layer("local_outcome", 4.1045, .495, size = 3.95, hjust = .5) +
    text_layer("systemic_outcome", 6.061, .495, size = 3.95, hjust = .5) +
    # Dedicated feedback lane: horizontal label, outside every content card.
    annotate("segment", x = 7.18, xend = 8.08, y = 1.45, yend = 1.45,
             colour = teal, linewidth = .58) +
    annotate("segment", x = 8.08, xend = 8.08, y = 1.45, yend = 3.91,
             colour = teal, linewidth = .58) +
    annotate("segment", x = 8.08, xend = 7.24, y = 3.91, yend = 3.91,
             colour = teal, linewidth = .58,
             arrow = grid::arrow(length = grid::unit(.085, "in"), type = "closed")) +
    rounded(7.24, 8.42, 2.32, 3.10, "white", "white", radius = .04, lw = 0) +
    text_layer("feedback", 7.83, 2.71, colour = teal, size = 3.95, face = "bold", hjust = .5) +
    coord_fixed(ratio = 1, xlim = c(0, 8.5), ylim = c(0, 7.45),
                expand = FALSE, clip = "off") +
    theme_void(base_family = family) + theme(plot.margin = margin(0, 0, 0, 0))
  p
}
rain_pdf_path <- file.path(output_dir, "Figures", "Figure_5_Recognition_framework.pdf")
rain_png_path <- file.path(output_dir, "Figures", "Figure_5_Recognition_framework.png")
if (Sys.info()[["sysname"]] == "Darwin") {
  # Named Quartz registration prevents its implicit Arial substitution and
  # embeds true Helvetica subsets; it does not change other figures' families.
  grDevices::quartzFonts(RAINHelvetica = grDevices::quartzFont(c(
    "Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique")))
  rain_pdf_device <- function(filename, width, height, bg, ...) {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = "RAINHelvetica", bg = bg)
  }
  ggsave(rain_pdf_path, rain_framework("RAINHelvetica"), device = rain_pdf_device,
         width = 8.5, height = 7.45, units = "in", bg = "white")
} else {
  ggsave(rain_pdf_path, rain_framework("Helvetica"), device = grDevices::cairo_pdf,
         width = 8.5, height = 7.45, units = "in", family = "Helvetica", bg = "white")
}
ggsave(rain_png_path, rain_framework("Helvetica"), device = ragg::agg_png,
       width = 8.5, height = 7.45, units = "in", dpi = 600, bg = "white")
save_display_data(rain_content, "Figure_5_RAIN_Content")
save_display_data(rain_connections, "Figure_5_RAIN_Connections")
# DISPLAY Figure5 END
if (framework_only) quit(save = "no", status = 0L)



# DISPLAY Figure2 START
# Only aggregate inputs enter these figures. Recorded and explicitly estimated
# dates enter the numerical summaries; unavailable dates do not.
onset <- read_input("Figure_2_Onset_Bins", c("window", "lower_day", "upper_day", "n", "denominator", "percent"))
timing <- read_input("Figure_2_Timing_Summaries", c("measure", "n", "total_n", "median", "q1", "q3"))
densities <- read_input("Figure_2_Timing_Densities", c("measure", "day", "density", "denominator"))
stopifnot(nrow(onset) == 4L, length(unique(onset$denominator)) == 1L,
          all(onset$denominator > 0), sum(onset$n) == onset$denominator[1],
          all(abs(onset$percent - 100*onset$n/onset$denominator) < 1e-10),
          timing$n[timing$measure == "Onset"] == onset$denominator[1],
          length(unique(timing$total_n)) == 1L, all(timing$n <= timing$total_n),
          all(timing$q1 <= timing$median),
          all(timing$median <= timing$q3))
measure_order <- c("Onset", "Peak", "Symptom resolution")
stopifnot(nrow(densities) == 303L, setequal(unique(densities$measure), measure_order),
          !anyDuplicated(densities[c("measure", "day")]),
          all(is.finite(densities$density)), all(densities$density >= 0),
          all(densities$density < .12), all(densities$denominator > 0))
for (measure_name in measure_order) {
  z <- densities %>% filter(measure == measure_name) %>% arrange(day)
  expected_n <- timing$n[timing$measure == measure_name]
  stopifnot(nrow(z) == 101L, identical(z$day, as.numeric(0:100)),
            all(z$denominator == expected_n))
}
onset <- onset %>% mutate(window = factor(window, levels = window),
                         value_label = sprintf("%d (%.1f%%)", n, percent))
p_a <- ggplot(onset, aes(window, n)) +
  geom_col(fill = "#1B5678", width = .62) +
  geom_text(aes(label = value_label), vjust = -.6, family = font_family, size = 3.35) +
  scale_y_continuous(limits = c(0, 33), breaks = c(0, 10, 20, 30),
                     expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("A", "Onset timing"),
       x = "Days after first step-up dose", y = "Cases") +
  theme_paper(10) + theme(axis.line.x = element_blank(), axis.ticks.x = element_blank(),
                          axis.text = element_text(size = 9.2),
                          axis.title.y = element_text(margin = margin(r = 6)))
timing <- timing %>% mutate(n_label = paste0(measure, " (n = ", n, ")"),
                           label = sprintf("Median %g days; IQR %g-%g", median, q1, q3))
density_colours <- c(Onset = "#1B5678", Peak = "#9B6A2D", "Symptom resolution" = "#547761")
# Curves are evaluated from the original elapsed times upstream, using a
# Gaussian kernel with bandwidth 5 days and reflection at zero only. The
# renderer consumes aggregate grid values; it never reads individual timings.
# Empirical medians and quartiles come from the separate registered summaries.
density_panels <- lapply(seq_along(measure_order), function(index) {
  measure_name <- measure_order[index]
  z <- densities %>% filter(measure == measure_name) %>% arrange(day)
  s <- timing %>% filter(measure == measure_name)
  colour <- unname(density_colours[measure_name])
  iqr_days <- sort(unique(c(s$q1, z$day[z$day > s$q1 & z$day < s$q3], s$q3)))
  iqr_curve <- data.frame(day = iqr_days, density = approx(z$day, z$density, xout = iqr_days)$y)
  median_height <- approx(z$day, z$density, xout = s$median)$y
  p <- ggplot(z, aes(day, density)) +
    geom_area(fill = colour, alpha = .25) +
    geom_area(data = iqr_curve, fill = colour, alpha = .65) +
    geom_line(colour = colour, linewidth = .45) +
    annotate("segment", x = s$median, xend = s$median, y = 0, yend = median_height,
             colour = colour, linewidth = .6) +
    annotate("text", x = 0, y = .12, label = s$n_label, hjust = 0, vjust = -1,
             family = font_family, size = 3.55, colour = "#222222") +
    annotate("text", x = 100, y = .12, label = s$label, hjust = 1, vjust = -1,
             family = font_family, size = 3.35, colour = "#222222") +
    scale_y_continuous(limits = c(0, .12), breaks = c(0, .04, .08, .12),
                       labels = function(x) sprintf("%.2f", x), expand = expansion(mult = c(0, 0))) +
    scale_x_continuous(limits = c(0, 100), breaks = seq(0, 100, 20),
                       expand = expansion(mult = c(0, 0))) +
    coord_cartesian(clip = "off") +
    labs(x = if (index == 3L) "Days after first step-up dose" else NULL,
         y = if (index == 2L) "Density (per day)" else NULL) +
    theme_paper(10) +
    theme(axis.text = element_text(size = 9.2),
          axis.title.y = element_text(margin = margin(r = 6)),
          plot.margin = margin(17, 10, if (index == 3L) 8 else 3, 8))
  if (index < 3L) p <- p + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())
  p
})
p_b <- wrap_plots(density_panels, ncol = 1, heights = c(1, 1, 1)) +
  plot_annotation(title = panel_title("B", "Timing distributions"),
                  theme = theme(plot.title = element_text(face = "bold", family = font_family,
                                                         size = 11, hjust = 0, margin = margin(l = 30)),
                                plot.margin = margin(0, 0, 0, 0)))
save_figure(p_a / wrap_elements(full = p_b) + plot_layout(heights = c(1, 1.5)),
            "Figure_2_Aggregate_timing", 7.2, 6.2)
save_display_data(onset %>% select(-value_label), "Figure_2_Onset_Bins")
save_display_data(timing %>% select(measure, n, total_n, median, q1, q3), "Figure_2_Timing_Summaries")
save_display_data(densities %>% select(measure, day, density, denominator), "Figure_2_Timing_Densities")
# DISPLAY Figure2 END

# DISPLAY Figure3 START
# Match Figure 2 text roles at the common 6.5-inch manuscript display width.
# geom_text sizes are millimetres; theme text sizes are points.
figure3_font_scale <- 9.5 / 7.2
figure3_fonts <- list(title = 11 * figure3_font_scale,
                     labels = 9.2 * figure3_font_scale,
                     axis_title = 10 * figure3_font_scale,
                     numbers_mm = 3.35 * figure3_font_scale)
figure3_display_label <- function(label) {
  wrapped <- c("Biochemical/organ manifestation" = "Biochemical/organ\nmanifestation",
               "Admission attributed to flare" = "Admission attributed\nto flare",
               "ICU care attributed to flare" = "ICU care attributed\nto flare",
               "Neurological manifestation" = "Neurological\nmanifestation")
  ifelse(label %in% names(wrapped), unname(wrapped[label]), label)
}
collapse_figure3_statuses <- function(x) {
  required <- c("panel", "field", "label", "category", "n", "denominator")
  if (!all(required %in% names(x))) stop("Missing Figure 3 status columns")
  x <- x %>% mutate(category = ifelse(is.na(category) | category %in% c("", "Not applicable"), "Unknown", category),
                    .order = row_number())
  if (!all(x$category %in% c("Yes", "No", "Unknown")) ||
      any(!is.finite(x$n) | x$n < 0 | x$n != floor(x$n)) ||
      any(!is.finite(x$denominator) | x$denominator <= 0 | x$denominator != floor(x$denominator)))
    stop("Invalid Figure 3 assessment counts or categories")
  denominators <- x %>% group_by(panel, field, label) %>% summarise(values = n_distinct(denominator), .groups = "drop")
  if (any(denominators$values != 1)) stop("Inconsistent Figure 3 denominators")
  x <- x %>% group_by(panel, field, label, category, denominator) %>%
    summarise(n = sum(n), .order = min(.order), .groups = "drop")
  totals <- x %>% group_by(panel, field, label, denominator) %>% summarise(total = sum(n), .groups = "drop")
  if (any(totals$total != totals$denominator)) stop("Figure 3 counts do not conserve the full denominator")
  x %>% group_by(panel, field, label) %>% mutate(.order = min(.order)) %>% ungroup() %>%
    arrange(.order, match(category, c("Yes", "No", "Unknown"))) %>%
    mutate(percent = 100 * n / denominator) %>%
    select(panel, field, label, category, n, denominator, percent)
}

status_bars <- function(x, title) {
  stopifnot(all(c("label", "category", "n", "denominator") %in% names(x)))
  x <- x %>% mutate(category = ifelse(is.na(category) | category == "", "Unknown", category))
  if (!all(x$category %in% names(colours))) stop("Unexpected clinical status category")
  labels <- unique(x$label)
  x <- x %>% mutate(label = factor(label, levels = rev(labels)), category = factor(category, levels = names(colours)), proportion = n/denominator)
  yes <- x %>% filter(category == "Yes")
  ggplot(x, aes(proportion, label, fill = category)) + geom_col(width = .64, position = position_stack(reverse = TRUE), colour = "white", linewidth = .25, show.legend = TRUE) +
    geom_text(data = yes, aes(x = 1.02, y = label, label = paste0(n, "/", denominator)), inherit.aes = FALSE,
              hjust = 0, size = figure3_fonts$numbers_mm, family = font_family) +
    scale_fill_manual(values = colours, drop = FALSE) +
    scale_y_discrete(labels = figure3_display_label) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1), breaks = c(0, .25, .5, .75, 1), expand = expansion(mult = c(0, 0))) +
    coord_cartesian(xlim = c(0, 1.14), clip = "off") +
    labs(title = title, x = "Proportion of tumor flare cases", y = NULL) + theme_paper(figure3_fonts$axis_title) +
    theme(plot.title = element_text(size = figure3_fonts$title),
          axis.text = element_text(size = figure3_fonts$labels),
          axis.text.y = element_text(lineheight = 1.0, margin = margin(r = 7)),
          axis.title = element_text(size = figure3_fonts$axis_title),
          legend.text = element_text(size = figure3_fonts$labels),
          legend.title = element_blank(),
          axis.line.y = element_blank(), axis.ticks.y = element_blank(),
          plot.margin = margin(10, 14, 10, 8))
}
if (file.exists(file.path(input_dir, "Figure_3_Statuses.csv"))) {
  statuses <- collapse_figure3_statuses(read_input("Figure_3_Statuses", c("panel", "field", "label", "category", "n", "denominator", "percent")))
} else {
  presentation <- read_input("presentation", c("field", "label", "panel", "category", "n", "denominator"))
  anatomy <- read_input("anatomy_binary", c("field", "label", "category", "n", "denominator"))
  presentation <- presentation %>% mutate(label = case_when(
    field == "flare_hospitalization" ~ "Admission attributed to flare",
    field == "icu_due_to_flare" ~ "ICU care attributed to flare", TRUE ~ label))
  manifest <- presentation %>% filter(field %in% c("pain_flare", "palpable_enlargement", "imaging_worsening", "new_lesion", "neurologic_cns", "biochemical_or_organ")) %>% mutate(panel = "A")
  impact <- presentation %>% filter(field %in% c("organ_dysfunction", "flare_hospitalization", "neurologic_deficit", "pathologic_fracture", "cord_compression", "icu_due_to_flare")) %>% mutate(panel = "B")
  site <- anatomy %>% filter(field %in% c("true_emd_any", "paraskeletal_involvement", "spinal_involvement", "cns_involvement")) %>% mutate(panel = "C")
  statuses <- collapse_figure3_statuses(bind_rows(manifest, impact, site))
}
manifest <- statuses %>% filter(panel == "A")
impact <- statuses %>% filter(panel == "B")
site <- statuses %>% filter(panel == "C")
save_figure((status_bars(manifest, panel_title("A", "Clinical manifestations")) /
             status_bars(impact, panel_title("B", "Clinical impact")) /
             status_bars(site, panel_title("C", "Anatomical involvement during flare"))) + plot_layout(guides = "collect", heights = c(6, 6, 4)) & theme(legend.position = "bottom"),
            "Figure_3_Clinical_spectrum", 9.5, 10)
save_display_data(statuses, "Figure_3_Statuses")
# DISPLAY Figure3 END
}

# DISPLAY Figure4 START
figure4_font_scale <- 12 / 7.2
figure4_fonts <- list(title = 11 * figure4_font_scale,
                     labels = 9.2 * figure4_font_scale,
                     axis_title = 10 * figure4_font_scale,
                     numbers_mm = 3.35 * figure4_font_scale)
forest <- function(x, title, metric, x_limits = NULL, x_breaks = NULL) {
  stopifnot(all(c("label", "estimate", "conf_low", "conf_high", "n_courses", "candidates") %in% names(x)))
  x <- x %>% mutate(row = rev(row_number()))
  if (is.null(x_limits)) {
    rng <- range(c(x$conf_low, x$conf_high, 1), na.rm = TRUE)
    rng <- c(max(.01, rng[1] * .8), rng[2] * 1.2)
  } else {
    rng <- x_limits
    stopifnot(length(rng) == 2L, all(is.finite(rng)), 0 < rng[1], rng[1] < rng[2],
              all(x$conf_low >= rng[1]), all(x$conf_high <= rng[2]))
  }
  # Keep analytical labels unchanged; use the clinical threshold glyph in the figure.
  x <- x %>% mutate(display_label = gsub(">=", "\u2265", label, fixed = TRUE),
                    display_label = vapply(display_label, function(value) paste(strwrap(value, width = 29), collapse = "\n"), character(1)))
  labels <- ggplot(x, aes(y = row)) + geom_text(aes(x = 0, label = display_label), hjust = 0, family = font_family,
    size = figure4_fonts$labels / (72.27 / 25.4), lineheight = 1.0) +
    coord_cartesian(xlim = c(0, 1), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  values <- x %>% mutate(value = ifelse(is.finite(estimate), sprintf("%.2f (%.2f-%.2f)", estimate, conf_low, conf_high), "Not estimated"),
    population = paste0("N=", format(n_courses, big.mark = ","), "; flare=", candidates))
  right <- ggplot(values, aes(y = row)) + geom_text(aes(x = 0, label = value), hjust = 0, family = font_family, size = figure4_fonts$numbers_mm) +
    geom_text(aes(x = .60, label = population), hjust = 0, family = font_family, size = figure4_fonts$numbers_mm) +
    coord_cartesian(xlim = c(0, 1.35), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  x_scale <- if (is.null(x_breaks)) scale_x_log10(limits = rng) else
    scale_x_log10(limits = rng, breaks = x_breaks,
      labels = function(value) vapply(value, function(v) format(v, scientific = FALSE, trim = TRUE), character(1)),
      expand = expansion(mult = c(0, 0)))
  center <- ggplot(x, aes(estimate, row)) + geom_vline(xintercept = 1, linetype = "dashed", colour = "#89949C", linewidth = .4) +
    geom_errorbar(aes(xmin = conf_low, xmax = conf_high), orientation = "y", width = .12, linewidth = .55, na.rm = TRUE) +
    geom_point(size = 2.1, colour = "#1B5678", na.rm = TRUE) + x_scale +
    coord_cartesian(ylim = c(.35, nrow(x) + .65)) + labs(x = paste0(metric, " (95% CI)"), y = NULL) + theme_paper(figure4_fonts$axis_title) +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(), axis.line.y = element_blank(),
          axis.text.x = element_text(size = figure4_fonts$labels),
          axis.title.x = element_text(size = figure4_fonts$axis_title),
          plot.margin = margin(4, 4, 4, 4))
  (labels + center + right + plot_layout(widths = c(1.05, 1.0, 1.55))) +
    plot_annotation(title = title, theme = theme(plot.title = element_text(family = font_family, face = "bold", size = figure4_fonts$title)))
}
models <- read_input("models", c("model_id", "scenario", "family", "label", "estimate", "conf_low", "conf_high", "n_courses", "candidates"))
survival <- read_input("survival_models", c("scenario", "model", "endpoint", "estimate", "conf_low", "conf_high", "n_courses", "exposed_courses"))
registered_rows <- function(x, ids) {
  positions <- match(ids, x$model_id)
  stopifnot(!anyDuplicated(x$model_id), !anyNA(positions))
  x[positions, , drop = FALSE]
}
baseline <- registered_rows(models, paste0("primary_", c("age10", "ecog2", "female", "prior_lines", "hrca", "true_emd"))) %>% mutate(panel = "A")
responses <- registered_rows(models, paste0("primary_response_", c("pr", "vgpr", "cr"), "_adjusted")) %>% mutate(panel = "C")
immune <- read_input("Table_S3_Immune_Associations", c("model_id", "characteristic", "odds_ratio", "conf_low", "conf_high", "p_value", "n_courses", "n_patient_clusters", "flare_evaluable", "flare_events", "comparison_evaluable", "inference_method", "point_converged", "profile_converged", "plr_converged"))
immune <- registered_rows(immune, c("primary_immune_crs_unadjusted", "primary_immune_icans_unadjusted")) %>%
  mutate(panel = "B", scenario = "primary", family = "Immune toxicity", label = characteristic,
         estimate = odds_ratio, candidates = flare_evaluable, events = flare_events, adjustment = "")
stopifnot(all(immune$inference_method == "Firth profile penalized likelihood"),
          all(immune$point_converged & immune$profile_converged & immune$plr_converged),
          all(is.finite(immune$estimate)), all(immune$conf_low > 0),
          all(immune$conf_low <= immune$estimate & immune$estimate <= immune$conf_high),
          all(is.finite(immune$p_value) & immune$p_value >= 0 & immune$p_value <= 1),
          all(immune$n_courses == immune$flare_evaluable + immune$comparison_evaluable),
          all(immune$events <= immune$candidates))
surv_primary <- survival %>% filter(scenario == "primary", grepl("Adjusted", model)) %>%
  arrange(match(endpoint, c("PFS", "OS"))) %>%
  mutate(panel = "D", model_id = paste0("primary_survival_", tolower(endpoint), "_adjusted"),
         label = endpoint, candidates = exposed_courses)
if (nrow(baseline) != 6L || nrow(immune) != 2L || nrow(responses) != 3L || nrow(surv_primary) != 2L) stop("Figure4 model selection is not 6 baseline/2 immune/3 response/2 survival models")
shared_or_limits <- c(0.1, 10)
# Expand the common logarithmic axis only when a valid profile interval extends beyond it.
or_bounds <- range(c(baseline$conf_low, baseline$conf_high, immune$conf_low, immune$conf_high, responses$conf_low, responses$conf_high),na.rm=TRUE)
shared_or_limits <- c(min(.1,10^floor(log10(or_bounds[1]))),max(10,10^ceiling(log10(or_bounds[2]))))
shared_or_breaks <- sort(unique(c(shared_or_limits,c(.1,.3,1,3,10))))
save_figure(wrap_plots(list(
              wrap_elements(full = forest(baseline, panel_title("A", "Unadjusted baseline associations with tumor flare"), "OR", shared_or_limits, shared_or_breaks)),
              wrap_elements(full = forest(immune, panel_title("B", "Unadjusted immune toxicity associations"), "OR", shared_or_limits, shared_or_breaks)),
              wrap_elements(full = forest(responses, panel_title("C", "Adjusted best-response associations"), "OR", shared_or_limits, shared_or_breaks)),
              wrap_elements(full = forest(surv_primary, panel_title("D", "Adjusted time-dependent survival associations"), "HR"))),
              ncol = 1, heights = c(6, 2.6, 3.3, 2.6)), "Figure_4_Association_models", 12, 11)
save_display_data(bind_rows(baseline, immune, responses, surv_primary) %>% select(any_of(c("panel", "model_id", "scenario", "family", "model", "label", "endpoint", "estimate", "conf_low", "conf_high", "p_value", "n_courses", "n_patient_clusters", "candidates", "events", "adjustment", "inference_method", "point_converged", "profile_converged", "plr_converged", "model_status"))), "Figure_4")
# DISPLAY Figure4 END

# DISPLAY FigureS1 START
if (!association_only) {
km <- read_input("landmark_km_steps", c("endpoint", "landmark_day", "group", "time", "survival", "lower", "upper"))
risk <- read_input("landmark_risk_counts", c("endpoint", "landmark_day", "group", "time", "n_risk"))
group_label <- function(x) ifelse(as.character(x) == "0", "No flare by landmark", ifelse(as.character(x) == "1", "Flare by landmark", as.character(x)))
km <- km %>% mutate(group = group_label(group))
risk <- risk %>% mutate(group = group_label(group))
group_colours <- c("No flare by landmark" = "#65747E", "Flare by landmark" = "#1B5678")
landmark_panel <- function(endpoint_value, day_value, letter) {
  x <- km %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  r <- risk %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  stopifnot(nrow(x) > 0, nrow(r) > 0)
  xmax <- max(r$time)
  x <- x %>% arrange(group, time)
  step_band <- x %>% group_by(group) %>% mutate(next_time = lead(time)) %>% ungroup()
  step_band <- bind_rows(step_band %>% mutate(order = 1), step_band %>% filter(is.finite(next_time)) %>% mutate(time = next_time, order = 0)) %>% arrange(group, time, order)
  # Canonical landmark KM and risk-count time fields are elapsed months.
  p <- ggplot(x, aes(time, survival, colour = group, fill = group)) +
    geom_ribbon(data = step_band, aes(ymin = lower, ymax = upper), alpha = .12, colour = NA) + geom_step(linewidth = .65) +
    scale_colour_manual(values = group_colours) + scale_fill_manual(values = group_colours) +
    scale_y_continuous(limits = c(0, 1), labels = scales::label_percent(accuracy = 1)) +
    scale_x_continuous(breaks = sort(unique(r$time)), labels = scales::label_number(accuracy = 1)) + coord_cartesian(xlim = c(0, xmax)) +
    labs(title = panel_title(letter, paste0(endpoint_value, " at day ", day_value)), x = "Months after landmark", y = paste0(endpoint_value, " probability")) +
    theme_paper(9) + theme(legend.position = "bottom")
  groups <- c("Flare by landmark", "No flare by landmark")
  r <- r %>% mutate(row = match(group, rev(groups)))
  rt <- ggplot(r, aes(time, row, label = n_risk, colour = group)) + geom_text(family = font_family, size = 2.7) +
    scale_colour_manual(values = group_colours) + scale_x_continuous(breaks = sort(unique(r$time))) +
    scale_y_continuous(breaks = 1:2, labels = rev(groups)) + coord_cartesian(xlim = c(0, xmax), ylim = c(.4, 2.6), clip = "off") +
    labs(x = NULL, y = NULL, title = "Number at risk") + theme_void(base_family = font_family) +
    theme(axis.text.y = element_text(size = 7, hjust = 1), plot.title = element_text(size = 8.5, hjust = 0),
          plot.margin = margin(3, 10, 3, 8), legend.position = "none")
  p / rt + plot_layout(heights = c(4.2, 1))
}
save_figure(wrap_plots(list(
              wrap_elements(full = landmark_panel("PFS", 30, "A")),
              wrap_elements(full = landmark_panel("OS", 30, "B")),
              wrap_elements(full = landmark_panel("PFS", 60, "C")),
              wrap_elements(full = landmark_panel("OS", 60, "D"))), ncol = 2, nrow = 2),
            "Figure_S1_Landmark_survival", 12, 9.5)
save_display_data(km, "Figure_S1_KM")
save_display_data(risk, "Figure_S1_Risk")
# DISPLAY FigureS1 END

# DISPLAY FigureS2 START
figure_s2_fields <- c("confidence", "total_n", "sd_pd_or_na_n", "at_least_pr_n",
                      "unavailable_n", "minimal_response_n")
response_confidence <- read_input("Figure_S2_Response_by_Confidence", figure_s2_fields)
confidence_levels <- c("Definite", "Probable", "Possible")
stopifnot(identical(names(response_confidence), figure_s2_fields),
          identical(response_confidence$confidence, confidence_levels),
          all(vapply(response_confidence[-1], function(x) {
            is.numeric(x) && all(is.finite(x) & x >= 0 & x == trunc(x))
          }, logical(1))),
          all(response_confidence$total_n > 0),
          with(response_confidence, all(sd_pd_or_na_n + at_least_pr_n == total_n &
                                        unavailable_n + minimal_response_n <= sd_pd_or_na_n)))
confidence_colours <- c(Definite = "#173D55", Probable = "#24655D", Possible = "#78501D")
response_bars <- response_confidence %>%
  mutate(confidence = factor(confidence, levels = confidence_levels)) %>%
  pivot_longer(c(sd_pd_or_na_n, at_least_pr_n), names_to = "response", values_to = "n") %>%
  mutate(response = factor(response, levels = c("sd_pd_or_na_n", "at_least_pr_n"),
                           labels = c("SD, PD, or NA", "\u2265PR")), proportion = n / total_n,
         count_label = paste0(n, "/", total_n))
confidence_labels <- with(response_confidence, sprintf("%s (n = %d)", confidence, total_n))
bar_position <- position_dodge(width = 0.72)
response_plot <- ggplot(response_bars, aes(response, proportion, fill = confidence)) +
  geom_col(width = 0.64, position = bar_position) +
  geom_text(aes(label = count_label, colour = confidence), position = bar_position,
            vjust = -0.55, family = font_family, size = 3.35, show.legend = FALSE) +
  scale_fill_manual(values = confidence_colours, labels = confidence_labels) +
  scale_colour_manual(values = confidence_colours) +
  scale_y_continuous(breaks = seq(0, 1, .25), labels = scales::label_percent(accuracy = 1),
                     expand = expansion(mult = c(0, .045))) +
  coord_cartesian(ylim = c(0, 1), clip = "off") +
  labs(x = NULL, y = "Cases within confidence group") +
  theme_paper(10) + theme(panel.grid.major.y = element_line(colour = "#E2E8EB", linewidth = .3),
                          axis.text.x = element_text(face = "bold"),
                          legend.position = "top", legend.margin = margin(b = 4),
                          legend.key.size = grid::unit(11, "pt"))
save_figure(response_plot, "Figure_S2_Best_Systemic_Response_by_Flare_Confidence", 6.5, 3.65, dpi = 300)
save_display_data(response_bars, "Figure_S2_Response_Bars")
# DISPLAY FigureS2 END
}
cat("Publication figures exported from", normalizePath(input_dir), "\n")
