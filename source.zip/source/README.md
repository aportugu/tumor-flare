# Tumor flare during bispecific antibody therapy for multiple myeloma: a multicenter study

Analysis code

This archive contains executable analysis and display code, the input dictionary, dependency specifications, model-specific seeds, file hashes, and synthetic fixtures. Clinical study records and patient-level derived data are excluded. All files in `Demo/` are invented test data, as described in `Demo/SYNTHETIC.txt`.

The clinical assessments replace discordant earlier values before cohort construction. Blank and Unknown assessments remain unavailable. Recorded and estimated dates enter timing analyses; other missing dates remain unavailable. Responses after another treatment cannot improve the response attributed to the original bispecific antibody course. Symptom recovery, local-lesion outcomes, systemic response, and survival follow-up are analyzed separately.

## Recreate the aggregate supplement

The paired self-contained HTML contains the published aggregate presentation manifest and figure inputs. Extract them, then rebuild the HTML from this source directory:

```sh
python3 Publication/extract_aggregate_inputs.py SUPPLEMENT.html aggregate_inputs
python3 Publication/compact_main_tables.py aggregate_inputs/publication_manifest.json compact_manifest.json --aggregate-directory compact_tables
Rscript --no-restore Publication/calculate_flare_frequency.R aggregate_inputs/flow.csv recalculated_frequency.csv
python3 Publication/build_publication.py aggregate_inputs/publication_manifest.json reproduced.html --archive-link analysiscode.zip
Rscript --no-restore Publication/build_figures_Figure1_Total_Cohort_Sankey.R aggregate_inputs reproduced_figures --figure1-only
Rscript --no-restore Publication/build_figures.R aggregate_inputs reproduced_figures
```

The manifest contains Tables 1–2 and S1–S4, captions, and all six figure images. The extractor writes only the selected aggregate CSV inputs and presentation manifest. The figure renderers use these aggregate inputs; they do not accept individual clinical display records. No clinical input files or rendered study images are included in this ZIP.

The clinical display selections are recorded in `Publication/clinical_presentation_selection.json` and applied by `Publication/streamline_publication_manifest.py`. They select existing aggregate results without refitting models. The HTML embeds the aggregate inputs needed to reproduce its tables and figures. The HTML has no file-download controls. Standalone aggregate CSV assets are not published.

Tables 1 and 2 use `Publication/compact_main_tables.py` to read the original registered aggregate counts and produce their compact views. Group totals appear in column headers; clinical percentages exclude Unknown and Not applicable, which are shown as counts only. Blank and unavailable assessment labels are combined as Unknown for display. Original categories remain unchanged in the analytical records and original aggregate inputs. The two presentation registrations record exact counts, evaluable denominators, original category labels, and whether a row is displayed. Running the compact-table command on an extracted current manifest reproduces its main tables without changing other displays or fitting models.

The overall observed flare frequency divides the secondary-review case count by all treatment courses in `flow.csv`. Base R `binom.test` calculates its exact 95% binomial interval. This course-based interval does not account for repeated courses within patients. The Figure 1 renderer recalculates and verifies the registered frequency before drawing the unchanged cohort flow.

Figure 5 presents RAIN (Recognize, Assess, Integrate, Next steps), a proposed clinical framework. Its text is registered in `Figure_5_RAIN_Content.csv`; the presentation manifest records the forward connections and the repeat-assessment loop. `Publication/build_figures.R` reads this conceptual content and renders the vector figure. The publication caption is supplied by the Figure 5 registration in `Publication/clinical_presentation_selection.json` and applied by the presentation assembly code. The framework has not undergone formal consensus development or diagnostic validation. Its content describes clinical assessment rather than patient pathways or analytical estimates.

## Synthetic execution

Install the versions recorded in `renv.lock`, or select a compatible R library with `TF_R_LIBRARY`. Run:

```sh
Rscript --no-restore Code/run_analysis.R Demo demo_results 20
python3 Publication/test_publication.py
python3 Publication/test_streamline_publication_manifest.py
python3 Publication/test_aggregate_clinical_displays.py
python3 Publication/test_compact_main_tables.py
Rscript --no-restore Publication/test_flare_frequency.R
python3 Code/Figure1_Total_Cohort_Sankey/test_extraction.py --output-dir extraction_checks
Rscript --no-restore Code/Figure1_Total_Cohort_Sankey/test_figure1_total_cohort_sankey.R Publication/build_figures_Figure1_Total_Cohort_Sankey.R sankey_checks.csv
Rscript --no-restore Code/Drafting/reverse_km_global_os_followup.R Demo/global_os_endpoint_audit_synthetic.csv followup_checks
python3 Code/Drafting/verify_reverse_km_independently.py Demo/global_os_endpoint_audit_synthetic.csv followup_checks
```

The 20-draw demonstration checks execution and does not reproduce study estimates. Logistic inference in the study requested 1,000 patient bootstrap draws per model and required at least 900 successful draws. Each sampled patient contributes all eligible courses. Seeds are recorded in `Code/model_seed_manifest.csv`.

## Reanalyze the clinical cohort

With approved access to controlled clinical inputs, run:

```sh
Rscript --no-restore Code/run_analysis.R INPUT_DIRECTORY OUTPUT_DIRECTORY 1000
python3 Publication/aggregate_clinical_displays.py OUTPUT_DIRECTORY AGGREGATE_DIRECTORY
```

The analytical pipeline produces private reconciliation, provenance, and model-membership files for verification. These files must stay within the controlled study environment. The publication layer accepts aggregate inputs only. Packaging uses the explicit `archive_allowlist.json`; clinical records, analysis outputs, audit exports, figures, and correspondence cannot enter the archive through directory-wide inclusion.


## Supplementary table order

Table S1 presents additional clinical characteristics; Table S2 presents baseline and response associations; Table S3 presents comparative response and immune toxicities; Table S4 presents survival analyses. The presentation configuration assigns table numbers after legacy selection and consolidation, using stable content identities. The numbering step is idempotent and preserves every displayed value and analytical object. The active sensitivity analyses comprise the Definite/Probable restriction, largest-site exclusion, and day-30/day-60 landmarks.


## Figure 3 presentation categories

Figure 3 combines Not applicable with Unknown before plotting, using a dedicated Figure_3_Statuses.csv aggregate. Yes and No counts and the full denominator of 33 are preserved. The grouping is idempotent and is limited to this figure; original clinical categories, shared inputs, and table categories are unchanged. The registration and renderer use the same Yes, No, Unknown categories.
