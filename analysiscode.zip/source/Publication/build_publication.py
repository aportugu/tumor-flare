#!/usr/bin/env python3
"""Render an aggregate-only HTML supplement from a presentation manifest.

The HTML embeds the aggregate presentation manifest for extraction and replay.
A local manifest can also be supplied to the renderer. The generic source archive
contains no study inputs or figures.
"""
import argparse
import base64
import csv
from datetime import date
import html
import io
import json
import re
from pathlib import Path

SCHEMA = 'tumor-flare-aggregate-publication-v2'
TABLE_LABELS = ['Table 1', 'Table 2', 'Table S1', 'Table S2', 'Table S3', 'Table S4']
FIGURE_LABELS = ['Figure 1', 'Figure 2', 'Figure 3', 'Figure 4', 'Figure 5', 'Figure S1', 'Figure S2']
FIGURE_S2_INPUT = 'Figure_S2_Response_by_Confidence.csv'
INDIVIDUAL_COLUMNS = {
    'case_id', 'case_label', 'patient_id', 'course_id', 'mrn',
    'medical_record_number', 'date_of_birth', 'birth_date', 'calendar_date',
    'treatment_date', 'onset_date', 'peak_date', 'resolution_date',
    'progression_date', 'death_date', 'last_followup_date',
    'clinical_narrative', 'site_correspondence',
}


def escape(text):
    return html.escape(str(text), quote=True)


def text_lines(text):
    return '<br>'.join(escape(line) for line in str(text).split('\n'))


def section_start(section_id, title, level=1):
    return f'<div id="{escape(section_id)}" class="section level{level}"><h{level}>{escape(title)}</h{level}>'


def paragraph(text, css=''):
    return f'<p class="{escape(css)}">{text_lines(text)}</p>'


def code_disclosure(label, code_files, code_root):
    fragments = []
    root = Path(code_root).resolve()
    for relative in code_files:
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError(f'Invalid executable code path: {relative}')
        fragments.append(f'# {relative}\n' + path.read_text(encoding='utf-8'))
    return ('<details class="code-disclosure"><summary>' + escape(label) +
            '</summary><pre><code>' + escape('\n\n'.join(fragments)) + '</code></pre></details>')


def render_table(panel):
    headers = panel['headers']
    response_counts = any(str(header).startswith(('Flare response', 'Response in flare courses')) for header in headers)
    css = 'publication-grid response-models' if response_counts else 'publication-grid'
    if panel.get('table_class') == 'supplementary-continuous':
        css += ' supplementary-continuous'
    if panel.get('compact_main_table'):
        css += ' compact-main'
    output = ['<div class="publication-table table-scroll"><table class="' + css + '"><thead><tr>']
    output.extend(f'<th scope="col">{text_lines(x)}</th>' for x in headers)
    output.append('</tr></thead><tbody>')
    for row in panel['rows']:
        if row.get('kind') == 'group':
            output.append(f'<tr class="characteristic-group"><th scope="row" colspan="{len(headers)}">{text_lines(row["cells"][0])}</th></tr>')
        else:
            output.append('<tr>')
            for i, cell in enumerate(row['cells']):
                css = ' class="category"' if i == 0 and row.get('kind') == 'category' else ''
                output.append(f'<td{css}>{text_lines(cell)}</td>')
            output.append('</tr>')
    output.append('</tbody></table></div>')
    return ''.join(output)


def aggregate_csv(item):
    stream = io.StringIO(newline='')
    writer = csv.writer(stream)
    writer.writerow(item['columns'])
    writer.writerows(item['rows'])
    return stream.getvalue()


def validate_manifest(manifest):
    if manifest.get('schema') != SCHEMA:
        raise ValueError('Unsupported publication schema')
    if [x.get('label') for x in manifest.get('tables', [])] != TABLE_LABELS:
        raise ValueError('Expected Tables 1–2/S1–S4 in manuscript order')
    figures = [x.get('label') for x in manifest.get('figures', [])]
    has_s2 = any(x.get('filename') == FIGURE_S2_INPUT for x in manifest.get('aggregate_inputs', []))
    if figures != (FIGURE_LABELS if has_s2 else FIGURE_LABELS[:-1]):
        raise ValueError('Expected Figures 1–5/S1 and any registered Figure S2 in manuscript order')
    if has_s2 and manifest['figures'][-1].get('aggregate_files') != [FIGURE_S2_INPUT]:
        raise ValueError('Figure S2 must reference its registered aggregate input')
    for display in manifest['tables']:
        for panel in display['panels']:
            if not isinstance(panel.get('notes', []), list) or any(not isinstance(note, str) for note in panel.get('notes', [])):
                raise ValueError(f'Panel notes must be a list of strings: {display["label"]}')
            for row in panel['rows']:
                if row.get('kind') == 'group' and len(row['cells']) != 1:
                    raise ValueError(f'Group rows require one spanning cell: {display["label"]}')
                if row.get('kind') != 'group' and len(row['cells']) != len(panel['headers']):
                    raise ValueError(f'Inconsistent table width: {display["label"]}')
    # Clinical case contracts and individual case labels are never accepted.
    reader_fields = {k: v for k, v in manifest.items() if k not in {'aggregate_inputs', 'figures'}}
    reader_fields['figures'] = [{k: v for k, v in figure.items() if k != 'image_data_url'}
                                for figure in manifest['figures']]
    reader_data = json.dumps(reader_fields, ensure_ascii=False)
    if re.search(r'\bTF\d{1,3}\b|"(?:case_id|case_label|patient_id)"', reader_data):
        raise ValueError('Individual clinical data are not publication inputs')
    if re.search(r'Historical endpoint audit|original_master_endpoints', reader_data, re.I):
        raise ValueError('Retired historical endpoint displays cannot be published')
    filenames = set()
    for item in manifest.get('aggregate_inputs', []):
        filename = item.get('filename', '')
        if Path(filename).name != filename or not filename.endswith('.csv') or filename in filenames:
            raise ValueError('Aggregate inputs must have unique flat CSV filenames')
        filenames.add(filename)
        columns = item.get('columns', [])
        if any(str(x).lower() in INDIVIDUAL_COLUMNS for x in columns):
            raise ValueError('Individual-record columns cannot be exported')
        if any(len(row) != len(columns) for row in item.get('rows', [])):
            raise ValueError(f'Inconsistent aggregate input width: {filename}')
    for display in manifest['tables'] + manifest['figures']:
        if any(filename not in filenames for filename in display.get('aggregate_files', [])):
            raise ValueError(f'Missing aggregate input: {display["label"]}')


def build(manifest, code_root, archive_link):
    validate_manifest(manifest)
    parts = [section_start('reproducibility-overview', '1 Reproducibility overview'),
             paragraph(manifest['overview']),
             '</div>',
             section_start('shared-analysis-code', '2 Shared analysis code'),
             paragraph(manifest['shared_introduction'])]
    for i, item in enumerate(manifest['shared_sections'], 1):
        parts += [section_start(f'display-2-{i}', f'2.{i} {item["title"]}', 2),
                  code_disclosure(f'Show code used for {item["title"].lower()}', item['code_files'], code_root), '</div>']
    parts += ['</div>', section_start('tables', '3 Tables')]
    for i, item in enumerate(manifest['tables'], 1):
        parts.append(section_start(f'display-3-{i}', f'3.{i} {item["label"]} {item["title"]}', 2))
        for j, panel in enumerate(item['panels'], 1):
            if panel.get('title'):
                parts.append(section_start(f'display-3-{i}-{j}', f'3.{i}.{j} {panel["title"]}', 3))
            parts.append(render_table(panel))
            if panel.get('notes_title'):
                parts.append('<h3 class="publication-notes-heading">' + escape(panel['notes_title']) + '</h3>')
            for note in panel.get('notes', []):
                parts.append(paragraph(note, 'publication-note'))
            if panel.get('title'):
                parts.append('</div>')
        parts += [paragraph(item['caption'], 'publication-note'),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div>']
    parts += ['</div>', section_start('figures', '4 Figures')]
    for i, item in enumerate(manifest['figures'], 1):
        parts.append(section_start(f'display-4-{i}', f'4.{i} {item["label"]} {item["title"]}', 2))
        source = item['image_data_url']
        if not source.startswith('data:image/png;base64,'):
            raise ValueError('Publication figures must use embedded PNG data')
        base64.b64decode(source.split(',', 1)[1], validate=True)
        parts += ['<div class="publication-figure"><img src="' + escape(source) + '" alt="' + escape(item['title']) + '">',
                  paragraph(item['caption'], 'publication-legend'),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div></div>']
    parts += ['</div>', section_start('computational-environment', '5 Computational environment'),
              render_table({'headers': ['Software', 'Version'], 'rows': [{'cells': row} for row in manifest['environment']]}), '</div>']
    encoded_manifest = json.dumps(manifest, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    parts.append('<script type="application/json" id="publication-manifest">' + encoded_manifest + '</script>')
    template = (Path(code_root) / 'Publication/reproducibility_layout.html').read_text(encoding='utf-8')
    build_date = manifest.get('build_date', '')
    parsed_date = date.fromisoformat(build_date) if build_date else None
    display_date = f'{parsed_date.strftime("%B")} {parsed_date.day}, {parsed_date.year}' if parsed_date else ''
    return (template.replace('{{TITLE}}', escape(manifest['title']))
            .replace('{{AUTHOR}}', escape(manifest.get('author', 'Andrew Portuguese')))
            .replace('{{BUILD_DATE}}', escape(build_date))
            .replace('{{DISPLAY_DATE}}', escape(display_date))
            .replace('{{CONTENT}}', ''.join(parts)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--code-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--archive-link', default='analysiscode.zip')
    args = parser.parse_args()
    args.output.write_text(build(json.loads(args.manifest.read_text()), args.code_root, args.archive_link), encoding='utf-8')


if __name__ == '__main__':
    main()
