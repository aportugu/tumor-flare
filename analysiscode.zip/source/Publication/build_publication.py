#!/usr/bin/env python3
"""Render an aggregate-only HTML supplement from a presentation manifest.

The HTML embeds the aggregate presentation manifest for extraction and replay.
A local manifest can also be supplied to the renderer. The generic source archive
contains no study inputs or figures.
"""
import argparse
import base64
from datetime import date
import html
import json
import re
from pathlib import Path
from xml.etree import ElementTree

if __package__:
    from .select_survival_sensitivity import PLOT_INPUT
else:
    from select_survival_sensitivity import PLOT_INPUT

SCHEMA = 'tumor-flare-aggregate-publication-v2'
TABLE_LABELS = ['Table 1', 'Table 2', 'Table S1', 'Table S2', 'Table S3', 'Table S4']
FIGURE_LABELS = ['Figure 1', 'Figure 2', 'Figure 3', 'Figure 4', 'Figure 5', 'Figure S1']
SMITH_ZEE_INPUT = 'Figure_S1_Smith_Zee_Predictions.csv'
VECTOR_FIGURE_INPUTS = {
    'Figure S1': SMITH_ZEE_INPUT,
    'Figure S3': PLOT_INPUT,
}
S3_ANCHOR = 'display-4-8'
PH_INPUT = 'cox_ph_diagnostics.csv'
FIGURE_S2_INPUT = 'Figure_S2_Response_by_Confidence.csv'
INDIVIDUAL_COLUMNS = {
    'case_id', 'case_label', 'patient_id', 'course_id', 'mrn',
    'medical_record_number', 'date_of_birth', 'birth_date', 'calendar_date',
    'treatment_date', 'onset_date', 'peak_date', 'resolution_date',
    'progression_date', 'death_date', 'last_followup_date',
    'clinical_narrative', 'site_correspondence',
}


def escape(text):
    return html.escape(str(text), quote=True)


def text_lines(text):
    return '<br>'.join(escape(line) for line in str(text).split('\n'))


def section_start(section_id, title, level=1):
    return f'<div id="{escape(section_id)}" class="section level{level}"><h{level}>{escape(title)}</h{level}>'


def paragraph(text, css=''):
    return f'<p class="{escape(css)}">{text_lines(text)}</p>'


def code_disclosure(label, code_files, code_root):
    fragments = []
    root = Path(code_root).resolve()
    for relative in code_files:
        path = (root / relative).resolve()
        if not path.is_relative_to(root) or not path.is_file():
            raise ValueError(f'Invalid executable code path: {relative}')
        fragments.append(f'# {relative}\n' + path.read_text(encoding='utf-8'))
    return ('<details class="code-disclosure"><summary>' + escape(label) +
            '</summary><pre><code>' + escape('\n\n'.join(fragments)) + '</code></pre></details>')


def render_table(panel):
    headers = panel['headers']
    response_counts = any(str(header).startswith(('Flare response', 'Response in flare courses')) for header in headers)
    continuous = panel.get('table_class') == 'supplementary-continuous'
    css = 'publication-grid'
    if continuous:
        css += ' supplementary-continuous'
    elif response_counts:
        css += ' response-models'
    if panel.get('compact_main_table'):
        css += ' compact-main'
    output = ['<div class="publication-table table-scroll"><table class="' + css + '"><thead><tr>']
    output.extend(f'<th scope="col">{text_lines(x)}</th>' for x in headers)
    output.append('</tr></thead><tbody>')
    for row in panel['rows']:
        if row.get('kind') == 'group':
            output.append(f'<tr class="characteristic-group"><th scope="row" colspan="{len(headers)}">{text_lines(row["cells"][0])}</th></tr>')
        else:
            output.append('<tr>')
            for i, cell in enumerate(row['cells']):
                css = ' class="category"' if i == 0 and row.get('kind') == 'category' else ''
                output.append(f'<td{css}>{text_lines(cell)}</td>')
            output.append('</tr>')
    output.append('</tbody></table></div>')
    return ''.join(output)


def render_prediction_details(figure):
    if 'prediction_method' not in figure:
        return ''
    method = figure['prediction_method']
    text = f"Predictions are shown through month {method['display_horizon_months']}."
    return paragraph(text, 'publication-legend')


SVG_PREFIX = 'data:image/svg+xml;base64,'
SVG_NS = '{http://www.w3.org/2000/svg}'
LINK_ATTR = '{http://www.w3.org/1999/xlink}href'


def validate_figure_svg(source):
    if not isinstance(source, str) or not source.startswith(SVG_PREFIX):
        raise ValueError('The figure SVG must be embedded')
    data = base64.b64decode(source.removeprefix(SVG_PREFIX), validate=True)
    if re.search(rb'<!|<\?(?!xml\s)', data):
        raise ValueError('The figure requires a self-contained vector SVG')
    root = ElementTree.fromstring(data)
    allowed = {SVG_NS + name for name in ('svg', 'defs', 'g', 'clipPath', 'path', 'use', 'rect', 'symbol')}
    elements = list(root.iter())
    if (root.tag != SVG_NS + 'svg' or not any(node.tag == SVG_NS + 'path' for node in elements)
            or any(node.tag not in allowed or any(
                key.startswith('on') or (key in ('href', LINK_ATTR) and not value.startswith('#'))
                or re.search(r'url\(\s*[^#]', value, re.I)
                for key, value in node.attrib.items()) for node in elements)):
        raise ValueError('The figure requires a self-contained vector SVG')


def validate_manifest(manifest):
    if manifest.get('schema') != SCHEMA:
        raise ValueError('Unsupported publication schema')
    tables = manifest.get('tables', [])
    labels = [table.get('label') for table in tables]
    if labels not in (TABLE_LABELS, TABLE_LABELS + ['Table S5']):
        raise ValueError('Expected Tables 1–2 and supplemental tables in manuscript order')
    anchors = [table.get('anchor', f'display-3-{i}') for i, table in enumerate(tables, 1)]
    if len(set(anchors)) != len(anchors) or any(not re.fullmatch(r'display-3-[a-z0-9-]+', anchor) for anchor in anchors):
        raise ValueError('Table anchors must be unique within the tables section')
    figures = {figure['label']: figure for figure in manifest['figures']}
    input_names = {item['filename'] for item in manifest.get('aggregate_inputs', [])}
    expected_figures = FIGURE_LABELS.copy()
    if FIGURE_S2_INPUT in input_names:
        expected_figures.append('Figure S2')
    if PLOT_INPUT in input_names:
        if 'Figure S2' not in expected_figures:
            raise ValueError('Figure S3 follows Figure S2')
        expected_figures.append('Figure S3')
    if [item['label'] for item in manifest['figures']] != expected_figures:
        raise ValueError('Expected figures in manuscript order')
    if 'Figure S2' in figures and figures['Figure S2'].get('aggregate_files') != [FIGURE_S2_INPUT]:
        raise ValueError('Figure S2 must reference its registered aggregate input')
    if 'Figure S3' in figures:
        s3 = figures['Figure S3']
        if not {'svg_data_url', 'pdf_data_url'} <= s3.keys():
            raise ValueError('Figure S3 requires a vector preview and PDF')
        if 'legacy_anchor' in s3:
            if ('Table S5' in labels or 'Table_S5.csv' in input_names
                    or s3['legacy_anchor'] in anchors or not re.fullmatch(r'display-3-[a-z0-9-]+', s3['legacy_anchor'])
                    or not isinstance(s3.get('notes'), list) or not s3['notes']
                    or any(not isinstance(note, str) or not note.strip() for note in s3['notes'])):
                raise ValueError('Expanded Figure S3 requires its notes and retired Table S5 bookmark')
            inputs = {item['filename']: item for item in manifest['aggregate_inputs']}
            if len(inputs.get(PH_INPUT, {}).get('rows', [])) != 18 or len(inputs[PLOT_INPUT]['rows']) != 14:
                raise ValueError('Expanded Figure S3 requires 14 survival rows and 18 diagnostic rows')
        elif 'Table S5' not in labels:
            raise ValueError('Legacy Figure S3 requires Table S5')
    for display in manifest['tables']:
        for panel in display['panels']:
            if not isinstance(panel.get('notes', []), list) or any(not isinstance(note, str) for note in panel.get('notes', [])):
                raise ValueError(f'Panel notes must be a list of strings: {display["label"]}')
            for row in panel['rows']:
                if row.get('kind') == 'group' and len(row['cells']) != 1:
                    raise ValueError(f'Group rows require one spanning cell: {display["label"]}')
                if row.get('kind') != 'group' and len(row['cells']) != len(panel['headers']):
                    raise ValueError(f'Inconsistent table width: {display["label"]}')
    # Clinical case contracts and individual case labels are never accepted.
    reader_fields = {k: v for k, v in manifest.items() if k not in {'aggregate_inputs', 'figures'}}
    reader_fields['figures'] = [{k: v for k, v in figure.items() if k not in {'image_data_url', 'svg_data_url'}}
                                for figure in manifest['figures']]
    reader_data = json.dumps(reader_fields, ensure_ascii=False)
    if re.search(r'\bTF\d{1,3}\b|"(?:case_id|case_label|patient_id)"', reader_data):
        raise ValueError('Individual clinical data are not publication inputs')
    if re.search(r'Historical endpoint audit|original_master_endpoints', reader_data, re.I):
        raise ValueError('Retired historical endpoint displays cannot be published')
    filenames = set()
    for item in manifest.get('aggregate_inputs', []):
        filename = item.get('filename', '')
        if Path(filename).name != filename or not filename.endswith('.csv') or filename in filenames:
            raise ValueError('Aggregate inputs must have unique flat CSV filenames')
        filenames.add(filename)
        columns = item.get('columns', [])
        if any(str(x).lower() in INDIVIDUAL_COLUMNS for x in columns):
            raise ValueError('Individual-record columns cannot be exported')
        if any(len(row) != len(columns) for row in item.get('rows', [])):
            raise ValueError(f'Inconsistent aggregate input width: {filename}')
    for figure in manifest['figures']:
        if 'svg_data_url' in figure:
            if figure['label'] not in VECTOR_FIGURE_INPUTS or 'pdf_data_url' not in figure:
                raise ValueError('Unregistered SVG preview or missing PDF')
            validate_figure_svg(figure['svg_data_url'])
        if 'pdf_data_url' not in figure:
            continue
        aggregate_input = VECTOR_FIGURE_INPUTS.get(figure['label'])
        expected_files = [aggregate_input] if aggregate_input else []
        if figure['label'] == 'Figure S3' and 'legacy_anchor' in figure:
            expected_files.append(PH_INPUT)
        if aggregate_input is None or figure.get('aggregate_files') != expected_files:
            raise ValueError('Vector figures require their registered aggregate inputs')
        pdf = figure['pdf_data_url']
        prefix = 'data:application/pdf;base64,'
        if not isinstance(pdf, str) or not pdf.startswith(prefix):
            raise ValueError('The figure PDF must be embedded')
        if not base64.b64decode(pdf.removeprefix(prefix), validate=True).startswith(b'%PDF-'):
            raise ValueError('The figure PDF is invalid')
    if SMITH_ZEE_INPUT in filenames:
        figure_s1 = manifest['figures'][5]
        if figure_s1.get('aggregate_files') != [SMITH_ZEE_INPUT] or 'pdf_data_url' not in figure_s1:
            raise ValueError('Smith–Zee Figure S1 must include its predictions and PDF')
        if filenames & {'landmark_km_steps.csv', 'landmark_risk_counts.csv', 'Table_S4_Landmark_Models.csv'}:
            raise ValueError('Retired landmark inputs cannot appear beside Smith–Zee Figure S1')
    for display in manifest['tables'] + manifest['figures']:
        if any(filename not in filenames for filename in display.get('aggregate_files', [])):
            raise ValueError(f'Missing aggregate input: {display["label"]}')


def build(manifest, code_root, archive_link):
    validate_manifest(manifest)
    parts = [section_start('reproducibility-overview', '1 Reproducibility overview'),
             paragraph(manifest['overview']),
             '</div>',
             section_start('shared-analysis-code', '2 Shared analysis code'),
             paragraph(manifest['shared_introduction'])]
    for i, item in enumerate(manifest['shared_sections'], 1):
        parts += [section_start(f'display-2-{i}', f'2.{i} {item["title"]}', 2),
                  code_disclosure(f'Show code used for {item["title"].lower()}', item['code_files'], code_root), '</div>']
    parts += ['</div>', section_start('tables', '3 Tables')]
    has_s3 = any(figure['label'] == 'Figure S3' for figure in manifest['figures'])
    for i, item in enumerate(manifest['tables'], 1):
        anchor = item.get('anchor', f'display-3-{i}')
        parts.append(section_start(anchor, f'3.{i} {item["label"]} {item["title"]}', 2))
        for j, panel in enumerate(item['panels'], 1):
            if panel.get('title'):
                parts.append(section_start(f'{anchor}-{j}', f'3.{i}.{j} {panel["title"]}', 3))
            parts.append(render_table(panel))
            if panel.get('notes_title'):
                parts.append('<h3 class="publication-notes-heading">' + escape(panel['notes_title']) + '</h3>')
            for note in panel.get('notes', []):
                parts.append(paragraph(note, 'publication-note'))
            if panel.get('title'):
                parts.append('</div>')
        if has_s3 and item['label'] == 'Table S5':
            parts.append(f'<p class="publication-note"><a href="#{S3_ANCHOR}">See Figure S3 for the adjusted estimates</a>.</p>')
        parts += [paragraph(item['caption'], 'publication-note'),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div>']
    table_s5_anchor = next((item.get('anchor', f'display-3-{i}') for i, item in enumerate(manifest['tables'], 1)
                            if item['label'] == 'Table S5'), None)
    parts += ['</div>', section_start('figures', '4 Figures')]
    for i, item in enumerate(manifest['figures'], 1):
        if 'legacy_anchor' in item:
            parts.append(f'<div id="{escape(item["legacy_anchor"])}"></div>')
        parts.append(section_start(f'display-4-{i}', f'4.{i} {item["label"]} {item["title"]}', 2))
        source = item['image_data_url']
        if not source.startswith('data:image/png;base64,'):
            raise ValueError('Publication figures must use embedded PNG data')
        base64.b64decode(source.split(',', 1)[1], validate=True)
        preview = f'<img src="{escape(source)}" alt="{escape(item.get("alt_text", item["title"]))}">'
        if 'svg_data_url' in item:
            preview = (f'<div class="publication-vector-scroll" role="region" tabindex="0" aria-label="{escape(item["label"])} chart">'
                       '<picture><source type="image/svg+xml" srcset="' + escape(item['svg_data_url']) +
                       '">' + preview + '</picture></div>')
        parts += ['<div class="publication-figure">' + preview,
                  paragraph(item['caption'], 'publication-legend'),
                  render_prediction_details(item),
                  (f'<p class="publication-legend"><a href="#{escape(table_s5_anchor)}">See Table S5 for the full survival results</a>.</p>'
                   if item['label'] == 'Figure S3' and table_s5_anchor else ''),
                  *(paragraph(note, 'publication-legend') for note in item.get('notes', [])),
                  code_disclosure(f'Show code used to generate {item["label"]}', item['code_files'], code_root), '</div></div>']
    parts += ['</div>', section_start('computational-environment', '5 Computational environment'),
              render_table({'headers': ['Software', 'Version'], 'rows': [{'cells': row} for row in manifest['environment']]}), '</div>']
    encoded_manifest = json.dumps(manifest, ensure_ascii=False, separators=(',', ':')).replace('</', '<\\/')
    parts.append('<script type="application/json" id="publication-manifest">' + encoded_manifest + '</script>')
    template = (Path(code_root) / 'Publication/reproducibility_layout.html').read_text(encoding='utf-8')
    build_date = manifest.get('build_date', '')
    parsed_date = date.fromisoformat(build_date) if build_date else None
    display_date = f'{parsed_date.strftime("%B")} {parsed_date.day}, {parsed_date.year}' if parsed_date else ''
    return (template.replace('{{TITLE}}', escape(manifest['title']))
            .replace('{{AUTHOR}}', escape(manifest.get('author', 'Andrew Portuguese')))
            .replace('{{BUILD_DATE}}', escape(build_date))
            .replace('{{DISPLAY_DATE}}', escape(display_date))
            .replace('{{CONTENT}}', ''.join(parts)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('manifest', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--code-root', type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument('--archive-link', default='analysiscode.zip')
    args = parser.parse_args()
    args.output.write_text(build(json.loads(args.manifest.read_text()), args.code_root, args.archive_link), encoding='utf-8')


if __name__ == '__main__':
    main()
