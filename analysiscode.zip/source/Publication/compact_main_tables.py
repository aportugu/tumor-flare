"""Create compact main-table views from registered aggregate counts only.

Original Table_1.csv/Table_2.csv inputs remain unchanged. Publication percentages
exclude unavailable and inapplicable assessments. Unknown rows are omitted.
This module never reads individual clinical records or fits statistical models.
"""
from collections import OrderedDict
from copy import deepcopy
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
import argparse, csv, json, re

NOTE = ('Categorical values are n (%) among evaluable assessments, excluding Unknown and Not applicable. '
        'Binary rows show cases with the characteristic. '
        'Continuous values are medians (IQRs) among available measurements.')
NOT_APPLICABLE_NOTE = 'Not applicable is shown as counts only.'
UNKNOWN = {'Blank','Unknown','Not reported','Unavailable','Not evaluable','NE','NE/Unknown',
           'Not reassessed','No subsequent response documented'}
RESPONSE_ORDER = ['CR','VGPR','PR','MR','SD','PD']
PRIORITIES = {
    'Symptom-resolution status':['Resolved','Improved but ongoing','Ongoing/not improved','Death prior to resolution'],
    'Local-lesion outcome':['Resolved','Improved','Worsened'],
    'BsAb action':['Continued without interruption','Delayed','Temporarily held then resumed','Permanently discontinued']}
RESPONSE_GROUPS = {'First postflare systemic assessment','Later supported systemic response','Best response to BsAb treatment'}
REG_COLUMNS = ['table','characteristic','category','cohort','n','evaluable_n','group_n',
               'displayed','row_kind','display','summary','available_n','original_categories']

def count(value):
    match = re.fullmatch(r'([\d,]+)/([\d,]+) \([\d.]+%\)', str(value))
    if not match: raise ValueError(f'Expected registered exact numerator/denominator: {value!r}')
    n,total=(int(x.replace(',','')) for x in match.groups())
    if n>total: raise ValueError('Numerator exceeds registered denominator')
    return n,total

def display(n,denominator):
    if not denominator: return '—'
    percent=(Decimal(100)*n/denominator).quantize(Decimal('0.1'),rounding=ROUND_HALF_UP)
    return f'{n:,} ({percent:.1f}%)'

def groups(item):
    out=OrderedDict()
    for row in item['rows']:
        label=str(row[0])
        if not label.startswith(' ') and all(not str(x) for x in row[1:]):
            if label in out:raise ValueError(f'Duplicate characteristic: {label}')
            out[label]=[]
        elif label.startswith(' ') and out:
            out[next(reversed(out))].append([label.strip(),*row[1:]])
        else:raise ValueError(f'Unrecognized aggregate row: {row}')
    return out

def compact_table(table,item):
    """Return presentation table and auditable aggregate denominator rows."""
    label=table['label'];cohorts=list(item['columns'][1:]);source=groups(item)
    widths=len(cohorts)
    totals=[max(count(row[i+1])[1] for rows in source.values() for row in rows
                if not row[0].startswith('Median')) for i in range(widths)]
    names=['Flare','No flare'] if label=='Table 1' else ['All cases','Definite/Probable','Possible']
    headers=['Characteristic']+[f'{name}\nN={total:,}' for name,total in zip(names,totals)]
    rows=[];registration=[]
    for characteristic,original in source.items():
        continuous=any(row[0].startswith('Median') for row in original)
        merged=OrderedDict();origins={};summaries=[];available=[]
        for row in original:
            category=row[0]
            if category.startswith('Median'):
                if summaries:raise ValueError('Multiple continuous summaries')
                for value in row[1:]:
                    match=re.fullmatch(r'(.+); available n=([\d,]+)',value)
                    if not match:raise ValueError(f'Unrecognized continuous summary: {value}')
                    summaries.append(match[1]);available.append(int(match[2].replace(',','')))
                continue
            target='Unknown' if category in UNKNOWN else category
            merged.setdefault(target,[0]*widths);origins.setdefault(target,[]).append(category)
            for i,value in enumerate(row[1:]):merged[target][i]+=count(value)[0]
        merged.setdefault('Not applicable',[0]*widths);merged.setdefault('Unknown',[0]*widths)
        valid=[totals[i]-merged['Unknown'][i]-merged['Not applicable'][i] for i in range(widths)]
        if any(x<0 for x in valid):raise ValueError('Unavailable counts exceed the group')
        if continuous:
            if available!=valid:raise ValueError(f'Continuous availability mismatch: {characteristic}')
        else:
            if any(sum(ns[i] for ns in merged.values())!=totals[i] for i in range(widths)):
                raise ValueError(f'Counts do not conserve the group: {characteristic}')
        known=[x for x in merged if x not in {'Unknown','Not applicable'}]
        binary=set(known)=={'No','Yes'}
        positive='Yes';negative='No';name=characteristic
        if characteristic=='Sex' and set(known)=={'Female','Male'}:
            binary=True;positive='Female';negative='Male';name='Female sex'
        if continuous:
            rows.append({'kind':'measure','cells':[characteristic+', median (IQR)',*summaries]})
            for i in range(widths):registration.append([label,characteristic,'Median (IQR)',names[i],'',valid[i],totals[i],
                True,'measure',summaries[i],summaries[i],available[i],'Median (IQR)'])
        elif binary:
            rows.append({'kind':'measure','cells':[name,*[display(n,d) for n,d in zip(merged[positive],valid)]]})
        else:
            rows.append({'kind':'group','cells':[characteristic]})
        if characteristic in RESPONSE_GROUPS:
            unexpected=set(known)-set(RESPONSE_ORDER)
            if unexpected:raise ValueError(f'Unexpected response labels: {unexpected}')
            known=[x for x in RESPONSE_ORDER if x in known]
        elif characteristic in PRIORITIES:
            known=[x for x in PRIORITIES[characteristic] if x in known]
        order=known+['Not applicable','Unknown']
        for category in order:
            ns=merged[category];missing=category in {'Unknown','Not applicable'}
            shown=(not missing or (category=='Not applicable' and any(ns))) and not (binary and category==negative)
            cells=[str(n) if missing else display(n,d) for n,d in zip(ns,valid)]
            row_kind='measure' if binary and category==positive else 'category'
            if shown and not (binary and category==positive):rows.append({'kind':row_kind,'cells':[category,*cells]})
            for i,n in enumerate(ns):registration.append([label,characteristic,category,names[i],n,valid[i],totals[i],
                shown,row_kind,cells[i] if shown else '', '', '', '|'.join(origins.get(category,[]))])
    result=deepcopy(table)
    result['panels']=[{'title':'','headers':headers,'rows':rows,'notes':[],'compact_main_table':True}]
    name=f'Table_{1 if label=="Table 1" else 2}_Presentation.csv'
    result['aggregate_files']=[item['filename'],name]
    result['code_files']=['Code/summary_functions.R','Publication/compact_main_tables.py','Publication/build_publication.py']
    if label=='Table 1':
        tail=table['caption'].split('An unavailable finding',1)[-1]
        result['caption']=NOTE+' An unavailable finding'+tail
    else:
        tail=table['caption'].split('Interventions may overlap.',1)[-1]
        result['caption']=(NOTE+' '+NOT_APPLICABLE_NOTE+' Interventions may overlap.'+tail).replace(' NE, not evaluable;','')
    return result,{'filename':name,'columns':REG_COLUMNS,'rows':registration}

def prepare(manifest):
    result=deepcopy(manifest);inputs={x['filename']:x for x in manifest['aggregate_inputs']}
    for i in range(2):
        result['tables'][i],obj=compact_table(manifest['tables'][i],inputs[f'Table_{i+1}.csv'])
        inputs[obj['filename']]=obj
    result['aggregate_inputs']=list(inputs.values())
    result['main_table_presentation']={'version':1,'source':'Publication/compact_main_tables.py',
        'percentage_denominator':'Evaluable assessments excluding Unknown and Not applicable',
        'missing_rows':'Unknown omitted. Not applicable shown as counts when present.',
        'binary_rows':'Positive findings; No omitted from display only',
        'response_order':RESPONSE_ORDER+['Not applicable'],'note':NOTE,'model_refitting':False}
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('input_manifest',type=Path);parser.add_argument('output_manifest',type=Path)
    parser.add_argument('--aggregate-directory',type=Path)
    args=parser.parse_args();result=prepare(json.loads(args.input_manifest.read_text()))
    args.output_manifest.parent.mkdir(parents=True,exist_ok=True)
    args.output_manifest.write_text(json.dumps(result,ensure_ascii=False,indent=2)+'\n')
    if args.aggregate_directory:
        args.aggregate_directory.mkdir(parents=True,exist_ok=True)
        for item in result['aggregate_inputs']:
            if item['filename'] in {'Table_1_Presentation.csv','Table_2_Presentation.csv'}:
                with (args.aggregate_directory/item['filename']).open('w',newline='') as stream:
                    writer=csv.writer(stream);writer.writerow(item['columns']);writer.writerows(item['rows'])
    print('Prepared compact Tables 1 and 2 from registered aggregate counts.')

if __name__=='__main__':main()
