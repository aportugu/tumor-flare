#!/usr/bin/env Rscript
args <- commandArgs(trailingOnly=TRUE)
root <- if(length(args)) args[1] else '.'
script <- gsub('~+~',' ',sub('^--file=','',grep('^--file=',commandArgs(),value=TRUE)[1]),fixed=TRUE)
source(file.path(dirname(normalizePath(script)),'calculate_table_s3_immune.R'))
source(file.path(root,'Code/model_functions.R'))
checks <- 0L
check <- function(value) { stopifnot(value); checks <<- checks+1L }
reject <- function(fun) { check(inherits(tryCatch(fun(),error=identity),'error')) }
d <- data.frame(course_id=paste0('synthetic-course-',1:6),
  patient_cluster_id=c('a','a','b','c','d','e'),comparative_eligible=c(TRUE,TRUE,TRUE,TRUE,FALSE,TRUE),
  analysis_flare=c(1,0,0,1,1,NA),crs_1=c(1,0,1,0,1,0),icans_1=c(0,1,0,1,0,0),toci_treatment=c(1,NA,0,1,0,0))
z <- immune_model_input(d)
check(nrow(z)==4L && length(unique(z$patient_cluster_id))==3L)
check(is.na(z$toci_treatment[2]))
bad <- d; bad$course_id[2]<-bad$course_id[1]; reject(function()immune_model_input(bad))
bad <- d; bad$crs_1[1]<-2; reject(function()immune_model_input(bad))
bad <- d; bad$patient_cluster_id[1]<-''; reject(function()immune_model_input(bad))
set.seed(81); for(i in 1:20) {
  positions <- tf_ash_cluster_indices(z$patient_cluster_id)
  check(sum(positions==1)==sum(positions==2))
}
valid <- tf_ash_bootstrap_inference(log(2),seq(-1,1,length.out=900),1000)
check(valid$successes==900 && valid$inference_available)
check(isTRUE(all.equal(valid$p_value,2*pnorm(-abs(log(2)/valid$se)))))
check(!tf_ash_bootstrap_inference(log(2),seq(-1,1,length.out=899),1000)$inference_available)
check(!tf_ash_bootstrap_inference(log(2),rep(1,1000),1000)$inference_available)
cat(checks,'synthetic immune-input, cluster-resampling, and inference checks passed\n')
