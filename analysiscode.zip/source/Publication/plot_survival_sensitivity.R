#!/usr/bin/env Rscript
# Usage: Rscript Publication/plot_survival_sensitivity.R PLOTTING_CSV OUTPUT_DIRECTORY
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Expected the aggregate plotting CSV and an output directory")
rows <- utils::read.csv(args[1L], stringsAsFactors = FALSE, check.names = FALSE)
models <- c("primary", "unadjusted_all", "unadjusted_matched", "strict",
            "without_dominant_site", "landmark_30", "landmark_60")
endpoints <- c("PFS", "OS")
stopifnot(nrow(rows) == 14L, setequal(rows$endpoint, endpoints), setequal(rows$analysis, models),
          !anyDuplicated(rows[c("endpoint", "analysis")]),
          all(rows$model_status %in% c("Estimated (exploratory)", "Not estimable")),
          all(with(rows, 0 <= exposed_events & exposed_events <= events & events <= n_courses &
                     exposed_events <= exposed_courses & exposed_courses <= n_courses), na.rm = TRUE))
estimated <- rows$model_status == "Estimated (exploratory)"
inference <- rows[c("estimate", "conf_low", "conf_high", "p_value")]
stopifnot(all(is.finite(as.matrix(inference[estimated, ]))), all(is.na(inference[!estimated, ])),
          all(with(rows[estimated, ], 0 < conf_low & conf_low <= estimate & estimate <= conf_high)))

limits <- c(.25, 3)
if (any(estimated)) {
  low <- min(rows$conf_low[estimated])
  high <- max(rows$conf_high[estimated])
  if (low < limits[1L]) limits[1L] <- 2^floor(log2(low))
  if (high > limits[2L]) limits[2L] <- 2^ceiling(log2(high))
}
ticks <- c(.25, .5, 1, 2, 3)
if (!identical(limits, c(.25, 3))) {
  # Keep the shared null and display boundary ticks. Drop near-neighbors when
  # a wide future interval would bring their labels together.
  middle <- c(.25, .5, 2, 3)
  keep <- vapply(middle, function(value) min(abs(log(value / c(limits, 1)))) > .12 * diff(log(limits)), TRUE)
  ticks <- sort(unique(c(limits, middle[keep], 1)))
}
width <- 6.5
height <- 5.62
ink <- "#263440"
navy <- "#173D55"
ochre <- "#78501D"
plum <- "#863A6D"
orange <- "#A84D12"
muted <- "#566571"
inches <- function(value) grid::unit(value, "in")
gp <- grid::gpar
x_hr <- function(hr) 1.93 + 2.35 * (log(hr) - log(limits[1L])) / diff(log(limits))
labels <- c("Primary adjusted", "Unadjusted, all eligible",
            "Unadjusted, matched courses", "Definite/Probable only",
            "Largest site excluded", "Adjusted day-30 landmark", "Adjusted day-60 landmark")
points <- c(23L, 22L, 22L, 21L, 21L, 21L, 21L)
colors <- c(navy, ochre, ochre, plum, plum, orange, orange)
fills <- c(navy, "white", "white", plum, plum, "white", "white")
text_at <- function(value, x, y, size = 9, bold = FALSE, just = "left", color = ink) {
  grid::grid.text(value, inches(x), inches(y), just = just,
                  gp = gp(fontfamily = "Helvetica", fontsize = size, col = color,
                          fontface = if (bold) "bold" else "plain"))
}
segment <- function(x0, y0, x1, y1, col = muted, lwd = .75, lty = 1) {
  grid::grid.segments(inches(x0), inches(y0), inches(x1), inches(y1), gp = gp(col = col, lwd = lwd, lty = lty))
}

plot_panel <- function(endpoint, tag, title, top) {
  panel <- rows[rows$endpoint == endpoint, ]
  panel <- panel[match(models, panel$analysis), ]
  usable <- panel$model_status == "Estimated (exploratory)"
  y <- top - seq(.43, 1.93, by = .25)
  axis <- top - 2.08
  text_at(tag, .12, top, size = 12)
  text_at(title, x_hr(limits[1L]), top, size = 12, bold = TRUE)
  segment(x_hr(1), axis, x_hr(1), top - .28, "#8C949A", lty = 2)
  text_at(labels, 1.82, y, just = "right", size = 9)
  if (any(usable)) {
    xlo <- x_hr(panel$conf_low[usable])
    xhi <- x_hr(panel$conf_high[usable])
    center <- x_hr(panel$estimate[usable])
    segment(xlo, y[usable], xhi, y[usable], muted, lwd = 1.25)
    grid::grid.points(inches(center), inches(y[usable]), pch = points[usable],
                      size = grid::unit(ifelse(models[usable] == "primary", 7.2, 6.3), "pt"),
                      gp = gp(col = colors[usable], fill = fills[usable], lwd = 1.1))
    hr <- sprintf("%.2f", panel$estimate[usable])
    to_right <- center + .34 <= x_hr(limits[2L])
    if (any(to_right)) text_at(hr[to_right], center[to_right] + .075, y[usable][to_right] + .088,
            size = 8.5, color = colors[usable][to_right])
    if (any(!to_right)) text_at(hr[!to_right], center[!to_right] - .075, y[usable][!to_right] + .088,
            size = 8.5, color = colors[usable][!to_right], just = "right")
  }
  count <- ifelse(is.na(panel$events), "—", format(panel$events, big.mark = ",", trim = TRUE))
  details <- paste0("Not estimable, events = ", count)
  p_value <- panel$p_value[usable]
  p_label <- ifelse(p_value < .001, "P<.001", paste0("P=", sub("^0", "", sprintf("%.3f", p_value))))
  details[usable] <- sprintf("95%% CI %.2f–%.2f, %s, events=%s", panel$conf_low[usable],
                              panel$conf_high[usable], p_label, count[usable])
  text_at(details, 4.38, y, size = 7.9, color = muted)
  segment(x_hr(limits[1L]), top - .28, x_hr(limits[1L]), axis, ink, lwd = 1)
  segment(x_hr(limits[1L]), axis, x_hr(limits[2L]), axis, ink, lwd = 1)
  tick_x <- x_hr(ticks)
  segment(tick_x, axis, tick_x, axis - .045, ink)
  text_at(format(ticks, trim = TRUE, scientific = FALSE, drop0trailing = TRUE), tick_x,
          axis - .14, size = 8.5, just = "centre")
  text_at("Hazard ratio for flare (log scale)", x_hr(sqrt(prod(limits))), axis - .31,
          size = 9.5, just = "centre")
}

dir.create(args[2L], recursive = TRUE, showWarnings = FALSE)
stem <- file.path(normalizePath(args[2L]), "Figure_S3_Adjusted_Survival_Analyses")
pdf <- paste0(stem, ".pdf")
if (capabilities("aqua")) {
  grDevices::quartz(type = "pdf", file = pdf, width = width, height = height, bg = "white")
} else {
  grDevices::cairo_pdf(filename = pdf, width = width, height = height, bg = "white")
}
grid::grid.newpage()
grid::grid.rect(gp = gp(fill = "white", col = NA))
plot_panel("PFS", "A", "Progression-free survival", 5.41)
plot_panel("OS", "B", "Overall survival", 2.79)
legend_rows <- c(1L, 2L, 4L, 6L)
legend_x <- c(.19, 1.62, 3.34, 4.96)
grid::grid.points(inches(legend_x), inches(rep(.19, length(legend_x))), pch = points[legend_rows],
                  size = grid::unit(5.4, "pt"), gp = gp(col = colors[legend_rows], fill = fills[legend_rows]))
text_at(c("Primary adjusted", "Unadjusted comparison", "Adjusted cohort", "Adjusted landmark"),
        legend_x + .11, .19, size = 8.3)
invisible(grDevices::dev.off())

poppler <- Sys.which("pdftocairo")
if (!nzchar(poppler)) stop("Install Poppler (pdftocairo) for the outlined SVG and 600 dpi PNG")
convert <- function(options, output) {
  status <- system2(poppler, c(options, shQuote(pdf), shQuote(output)))
  if (status != 0L) stop("Figure S3 conversion failed: ", output)
}
convert("-svg", paste0(stem, ".svg"))
convert(c("-png", "-singlefile", "-r", "600"), stem)
