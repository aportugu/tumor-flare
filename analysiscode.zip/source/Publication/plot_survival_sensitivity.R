#!/usr/bin/env Rscript
# Usage: Rscript Publication/plot_survival_sensitivity.R PLOTTING_CSV OUTPUT_DIRECTORY
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Expected the aggregate plotting CSV and an output directory")
rows <- utils::read.csv(args[1L], stringsAsFactors = FALSE, check.names = FALSE)
models <- c("primary", "strict", "without_dominant_site", "landmark_30", "landmark_60")
endpoints <- c("PFS", "OS")
stopifnot(nrow(rows) == 10L, setequal(rows$endpoint, endpoints), setequal(rows$analysis, models),
          !anyDuplicated(rows[c("endpoint", "analysis")]),
          all(rows$model_status %in% c("Estimated (exploratory)", "Not estimable")),
          all(with(rows, 0 <= exposed_events & exposed_events <= events & events <= n_courses &
                     exposed_events <= exposed_courses & exposed_courses <= n_courses)))
estimated <- rows$model_status == "Estimated (exploratory)"
inference <- rows[c("estimate", "conf_low", "conf_high")]
stopifnot(all(is.finite(as.matrix(inference[estimated, ]))), all(is.na(inference[!estimated, ])),
          all(with(rows[estimated, ], 0 < conf_low & conf_low <= estimate & estimate <= conf_high)))

limits <- c(.25, 3)
if (any(estimated)) {
  low <- min(rows$conf_low[estimated])
  high <- max(rows$conf_high[estimated])
  if (low < limits[1L]) limits[1L] <- 2^floor(log2(low))
  if (high > limits[2L]) limits[2L] <- 2^ceiling(log2(high))
}
ticks <- c(.25, .5, 1, 2, 3)
if (!identical(limits, c(.25, 3))) {
  # Keep the shared null and display boundary ticks. Drop near-neighbors when
  # a wide future interval would bring their labels together.
  middle <- c(.25, .5, 2, 3)
  keep <- vapply(middle, function(value) min(abs(log(value / c(limits, 1)))) > .12 * diff(log(limits)), TRUE)
  ticks <- sort(unique(c(limits, middle[keep], 1)))
}
width <- 6.5
height <- 4.85
ink <- "#263440"
navy <- "#173D55"
accent <- "#9E3045"
muted <- "#566571"
rule <- "#DCE4E9"
inches <- function(value) grid::unit(value, "in")
gp <- grid::gpar
x_hr <- function(hr) 2.27 + 1.79 * (log(hr) - log(limits[1L])) / diff(log(limits))
labels <- c("Primary adjusted", "Definite/Probable only", "Largest contributing site excluded",
            "Adjusted day-30 landmark", "Adjusted day-60 landmark")
points <- c(18, 16, 16, 1, 1)
colors <- c(accent, navy, navy, navy, navy)
text_at <- function(value, x, y, size = 9, bold = FALSE, just = "left", color = ink) {
  grid::grid.text(value, inches(x), inches(y), just = just,
                  gp = gp(fontfamily = "Helvetica", fontsize = size, col = color,
                          fontface = if (bold) "bold" else "plain"))
}
segment <- function(x0, y0, x1, y1, col = rule, lwd = .75, lty = 1) {
  grid::grid.segments(inches(x0), inches(y0), inches(x1), inches(y1), gp = gp(col = col, lwd = lwd, lty = lty))
}

plot_panel <- function(endpoint, title, top) {
  panel <- rows[rows$endpoint == endpoint, ]
  panel <- panel[match(models, panel$analysis), ]
  usable <- panel$model_status == "Estimated (exploratory)"
  y <- top - c(.62, .88, 1.14, 1.46, 1.72)
  axis <- top - 1.96
  grid::grid.rect(inches(3.25), inches(y[1L]), inches(6.33), inches(.23),
                  gp = gp(fill = "#EDF3F6", col = NA))
  text_at(title, .12, top, size = 11, bold = TRUE, color = navy)
  text_at("Model", .12, top - .34, bold = TRUE)
  text_at("HR (95% CI)", 4.20, top - .34, bold = TRUE)
  text_at("Courses", 5.48, top - .34, size = 8.5, bold = TRUE, just = "centre")
  text_at("Flare events", 6.12, top - .34, size = 8.5, bold = TRUE, just = "centre")
  segment(.12, top - .46, 6.40, top - .46)
  segment(.12, top - 1.30, 6.40, top - 1.30)
  segment(x_hr(1), axis, x_hr(1), top - .46, muted, lty = 2)
  text_at(labels[1L], .12, y[1L], bold = TRUE)
  text_at(labels[-1L], .12, y[-1L])
  if (any(usable)) {
    xlo <- x_hr(panel$conf_low[usable])
    xhi <- x_hr(panel$conf_high[usable])
    segment(xlo, y[usable], xhi, y[usable], navy, lwd = 1.15)
    segment(c(xlo, xhi), rep(y[usable] - .042, 2), c(xlo, xhi), rep(y[usable] + .042, 2), navy)
    grid::grid.points(inches(x_hr(panel$estimate[usable])), inches(y[usable]),
                      pch = points[usable], size = grid::unit(ifelse(models[usable] == "primary", 7.2, 5.4), "pt"),
                      gp = gp(col = colors[usable], lwd = 1.1))
  }
  estimates <- rep("Not estimable", length(models))
  estimates[usable] <- sprintf("%.2f (%.2f–%.2f)", panel$estimate[usable],
                                panel$conf_low[usable], panel$conf_high[usable])
  text_at(estimates, 4.20, y, size = 8.5)
  text_at(format(panel$n_courses, big.mark = ",", trim = TRUE), 5.48, y, just = "centre")
  text_at(panel$exposed_events, 6.12, y, just = "centre")
  segment(x_hr(limits[1L]), axis, x_hr(limits[2L]), axis, muted)
  tick_x <- x_hr(ticks)
  segment(tick_x, axis, tick_x, axis - .045, muted)
  text_at(format(ticks, trim = TRUE, scientific = FALSE, drop0trailing = TRUE), tick_x,
          axis - .14, size = 8.5, just = "centre")
}

dir.create(args[2L], recursive = TRUE, showWarnings = FALSE)
stem <- file.path(normalizePath(args[2L]), "Figure_S3_Adjusted_Survival_Analyses")
pdf <- paste0(stem, ".pdf")
if (capabilities("aqua")) {
  grDevices::quartz(type = "pdf", file = pdf, width = width, height = height, bg = "white")
} else {
  grDevices::cairo_pdf(filename = pdf, width = width, height = height, bg = "white")
}
grid::grid.newpage()
grid::grid.rect(gp = gp(fill = "white", col = NA))
plot_panel("PFS", "A  Progression-free survival", 4.68)
plot_panel("OS", "B  Overall survival", 2.38)
text_at("Adjusted hazard ratio", x_hr(sqrt(prod(limits))), .13, just = "centre")
invisible(grDevices::dev.off())

poppler <- Sys.which("pdftocairo")
if (!nzchar(poppler)) stop("Install Poppler (pdftocairo) for the outlined SVG and 600 dpi PNG")
convert <- function(options, output) {
  status <- system2(poppler, c(options, shQuote(pdf), shQuote(output)))
  if (status != 0L) stop("Figure S3 conversion failed: ", output)
}
convert("-svg", paste0(stem, ".svg"))
convert(c("-png", "-singlefile", "-r", "600"), stem)
