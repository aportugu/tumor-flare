#!/usr/bin/env python3
"""Select the fourteen survival estimates for Figure S3 from aggregate exports."""
import argparse
import csv
import math
from pathlib import Path

PLOT_INPUT = 'Figure_S3_Survival_Sensitivity.csv'
STEM = 'Figure_S3_Adjusted_Survival_Analyses'
FIELDS = ('endpoint', 'analysis', 'n_courses', 'n_patient_clusters', 'events', 'exposed_courses',
          'exposed_events', 'excluded_missing', 'estimate', 'conf_low', 'conf_high', 'p_value',
          'model_status', 'fit_reason', 'object_id')
ADJUSTED = 'Adjusted: six baseline variables'
TIME_DEPENDENT = (
    ('primary', ADJUSTED, 'primary'),
    ('primary', 'Unadjusted: all eligible', 'unadjusted_all'),
    ('primary', 'Unadjusted: adjusted subset', 'unadjusted_matched'),
    ('strict', ADJUSTED, 'strict'),
    ('without_dominant_site', ADJUSTED, 'without_dominant_site'),
)
LANDMARK_DAYS = ('30', '60')


def read_rows(path):
    with path.open(newline='', encoding='utf-8') as stream:
        return list(csv.DictReader(stream))


def validate_row(row):
    counts = [None if row[key] in ('', 'NA') else int(row[key]) for key in FIELDS[2:8]]
    courses, patients, events, exposed, flare_events, _ = counts
    ordered_pairs = ((patients, courses), (events, courses), (exposed, courses),
                     (flare_events, events), (flare_events, exposed))
    if (any(value is not None and value < 0 for value in counts)
            or any(a is not None and b is not None and a > b for a, b in ordered_pairs)
            or (row['model_status'] != 'Not estimable' and None in counts)):
        raise ValueError(f'Invalid model counts for {row["object_id"]}')
    inference = [row[key] for key in FIELDS[8:12]]
    if row['model_status'] == 'Not estimable':
        if not row['fit_reason'].strip() or any(v not in ('', 'NA') for v in inference):
            raise ValueError(f'Invalid unavailable model for {row["object_id"]}')
        return
    hr, low, high, p = map(float, inference)
    if (row['model_status'] != 'Estimated (exploratory)' or not all(map(math.isfinite, (hr, low, high, p)))
            or not (0 < low <= hr <= high and 0 <= p <= 1)):
        raise ValueError(f'Invalid survival estimate for {row["object_id"]}')


def select_models(time_dependent, landmark):
    selected = []
    for endpoint in ('PFS', 'OS'):
        for scenario, model, label in TIME_DEPENDENT:
            source, = (r for r in time_dependent if (r['endpoint'], r['scenario'], r['model'])
                       == (endpoint, scenario, model))
            selected.append({**source, 'analysis': label, 'object_id': f'{scenario}:{endpoint}:{model}',
                             'fit_reason': source.get('diagnostic', '') if source['model_status'] == 'Not estimable' else ''})
        for day in LANDMARK_DAYS:
            source, = (r for r in landmark if (r['endpoint'], r['landmark_day']) == (endpoint, day))
            if source['object_id'] != f'primary:{endpoint}:landmark:{day}:adjusted':
                raise ValueError(f'Unexpected landmark model identifier for {endpoint} day {day}')
            selected.append({**source, 'analysis': f'landmark_{day}'})
    rows = [{key: row[key] for key in FIELDS} for row in selected]
    for row in rows:
        validate_row(row)
    return rows


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('aggregate_dir', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    rows = select_models(read_rows(args.aggregate_dir / 'survival_models.csv'),
                         read_rows(args.aggregate_dir / 'Adjusted_Landmark_Models.csv'))
    with args.output.open('w', newline='', encoding='utf-8') as stream:
        writer = csv.DictWriter(stream, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)


if __name__ == '__main__':
    main()
