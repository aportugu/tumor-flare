#!/usr/bin/env python3
"""Aggregate clinical summaries for tumor flare; no individual exports.

Usage: aggregate_clinical_displays.py ANALYSIS_DIRECTORY OUTPUT_DIRECTORY
       [--context-csv CONFIDENTIAL_CONTEXT_FILE]

Clinical inputs are confidential and are not included in the code download.
The optional context file contains previously reviewed finite-category
assessments; the program does not interpret clinical narratives.
"""
import argparse
import csv
import hashlib
import json
import math
from collections import Counter
from pathlib import Path

GROUPS = [("All", "All cases (N = 33)"),
          ("Definite/Probable", "Definite/Probable (N = 18)"),
          ("Possible", "Possible (N = 15)")]
UNAVAILABLE = {"Blank", "Unknown", "Not applicable", "Not reported", "Unavailable", "Not evaluable",
               "NE", "NE/Unknown", "Not reassessed", "No subsequent response documented"}
PANEL_TITLES = {"A": "Treatment and timing", "B": "Clinical features", "C": "Management and outcomes"}


def read_csv(path):
    with Path(path).open(newline="", encoding="utf-8-sig") as handle:
        return list(csv.DictReader(handle))


def number(value):
    try:
        x = float(value)
        return x if math.isfinite(x) else None
    except (TypeError, ValueError):
        return None


def quantile(values, p):
    """Linear quantile, identical to R quantile(type = 7)."""
    values = sorted(values)
    if not values:
        return None
    h = (len(values) - 1) * p
    lo = math.floor(h)
    hi = math.ceil(h)
    return values[lo] + (h - lo) * (values[hi] - values[lo])


def category(value):
    if value is None or str(value).strip() in {"", "NA", "NaN"}:
        return "Blank"
    return {"TRUE": "Yes", "FALSE": "No", "YES": "Yes", "NO": "No",
            "UNKNOWN": "Unknown", "NOT_APPLICABLE": "Not applicable",
            "NOT_REPORTED": "Not reported", "UNAVAILABLE": "Unavailable"}.get(str(value), str(value))


def ordered_categories(values):
    leading = ["No", "Yes"]
    ending = ["Blank", "Unknown", "Not applicable", "Not reported", "Unavailable", "Not evaluable"]
    return [x for x in leading if x in values] + sorted(set(values) - set(leading + ending)) + [x for x in ending if x in values]


def fmt_number(x):
    return "Unavailable" if x is None else f"{x:g}"


def available_elapsed_days(data, field, measure):
    """Return recorded or estimated elapsed days without imputing missing values."""
    values = []
    for record in data:
        raw = record.get(field)
        day = number(raw)
        if day is None:
            try:
                numeric = float(raw)
            except (TypeError, ValueError):
                continue
            if math.isinf(numeric):
                raise ValueError(f"{measure} timing must be finite and within (0,100] days")
            continue
        if not 0 < day <= 100:
            raise ValueError(f"{measure} timing is outside (0,100] days")
        values.append(day)
    return sorted(values)


def timing_distributions(data):
    """Count available elapsed days in (0,5], (5,10], ..., (95,100]."""
    rows = []
    for field, measure in [("onset_days", "Onset"), ("peak_days", "Peak"),
                           ("resolution_days", "Symptom resolution")]:
        counts = [0] * 20
        for day in available_elapsed_days(data, field, measure):
            counts[math.ceil(day / 5) - 1] += 1
        denominator = sum(counts)
        for index, n in enumerate(counts):
            rows.append({"measure": measure, "lower_day": 5 * index + 1,
                         "upper_day": 5 * (index + 1), "n": n,
                         "denominator": denominator,
                         "percent": 100 * n / denominator if denominator else None})
    return rows


def reflected_gaussian_density(values, day, bandwidth=5.0):
    """Gaussian KDE reflected at zero and normalized on [0, infinity)."""
    if not values:
        return None
    if day < 0:
        return 0.0
    terms = (math.exp(-0.5 * ((day - value) / bandwidth) ** 2) +
             math.exp(-0.5 * ((day + value) / bandwidth) ** 2)
             for value in values)
    return math.fsum(terms) / (len(values) * bandwidth * math.sqrt(2 * math.pi))


def timing_densities(data):
    """Evaluate direct KDEs on days 0–100 by 1, using a shared 5-day bandwidth.

    Day 100 is the display limit. Curves have no upper reflection and are not
    renormalized within that display window. Duplicate elapsed times contribute
    separate observations; unavailable timings do not enter the denominator.
    """
    rows = []
    for field, measure in [("onset_days", "Onset"), ("peak_days", "Peak"),
                           ("resolution_days", "Symptom resolution")]:
        values = available_elapsed_days(data, field, measure)
        rows.extend({"measure": measure, "day": day,
                     "density": reflected_gaussian_density(values, day),
                     "denominator": len(values)} for day in range(101))
    return rows


def aggregate(cases, timeline, table2, context=None):
    """Return aggregate rows and display objects, never a case frame."""
    if not cases:
        raise ValueError("The clinical series must contain at least one case")
    ids = [x["case_id"] for x in cases]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate clinical case linkage")
    dates = {x["case_id"]: x for x in timeline}
    if len(dates) != len(timeline) or set(dates) != set(ids):
        raise ValueError("Timing linkage must match the clinical series exactly")
    if any(x["investigator_confidence"] not in {"Definite", "Probable", "Possible"} for x in cases):
        raise ValueError("Unknown confidence classification")
    merged = [{**x, **{k: v for k, v in dates[x["case_id"]].items()
                      if k not in {"confidence", "product", "bridging", "comparative_included"}}} for x in cases]
    if context is not None:
        contexts = {x["case_label"]: x for x in context}
        if len(contexts) != len(context) or set(contexts) != {x["case_label"] for x in merged}:
            raise ValueError("Clinical context linkage must match the series exactly")
        for x in merged:
            for k in ["first_response_category_estimated", "later_local_after_radiation",
                      "later_local_after_salvage", "later_local_after_cart",
                      "later_local_separate_from_systemic_response"]:
                x[k] = contexts[x["case_label"]].get(k, "NOT_REPORTED")
    groups = {"All": merged,
              "Definite/Probable": [x for x in merged if x["investigator_confidence"] in {"Definite", "Probable"}],
              "Possible": [x for x in merged if x["investigator_confidence"] == "Possible"]}
    group_titles = [(g, f"{('All cases' if g == 'All' else g)} (N = {len(groups[g])})") for g, _ in GROUPS]
    rows = []
    panels = {p: [] for p in PANEL_TITLES}
    reused = []

    def add_categories(panel, field, label, mapping=None, supplied=None):
        counts = {}
        for g, values in groups.items():
            counts[g] = Counter(category(mapping(x) if mapping else x.get(field)) for x in values)
        if supplied is not None:
            counts = {g: Counter({category(x["category"]): int(x["n"])
                                  for x in supplied if x["group"] == g}) for g in groups}
            # Supplied aggregates and direct clinical counts must agree.
            for g, values in groups.items():
                direct = Counter(category(mapping(x) if mapping else x.get(field)) for x in values)
                if dict(direct) != dict(+counts[g]):
                    raise ValueError(f"Published management count conflict: {field}, {g}")
            reused.append(field)
        cats = ordered_categories(set().union(*(set(v) for v in counts.values())))
        preferred = {"onset_window": ["Days 1–7", "Days 8–14", "Days 15–30", "Days 31–100", "Interval only", "Unavailable"],
                     "dosing_phase_at_onset": ["Step-up dosing", "First target dose", "Cycle 1 after target dose", "Cycle 2", "Cycle 3 or later", "Blank", "Unknown"]}
        if field.endswith("_availability"):
            preferred[field] = ["Recorded date", "Estimated date", "Date type unknown", "Interval only", "Unavailable"]
        if field in preferred:
            cats = [x for x in preferred[field] if x in cats] + [x for x in cats if x not in preferred[field]]
        panels[panel].append({"kind": "group", "characteristic": label, "values": {g: "" for g in groups}, "field": field})
        for cat in cats:
            values = {}
            for g in groups:
                n, total = counts[g][cat], len(groups[g])
                available = sum(v for k, v in counts[g].items() if k not in UNAVAILABLE)
                pct = 100 * n / total if total else None
                values[g] = f"{n}/{total} ({pct:.1f}%)" if pct is not None else "Unavailable"
                rows.append({"panel": panel, "field": field, "characteristic": label,
                             "category": cat, "group": g, "n": n, "total_n": total,
                             "evaluable_n": available, "denominator": total, "percent": pct,
                             "available_n": "", "median": "", "q1": "", "q3": ""})
            panels[panel].append({"kind": "category", "characteristic": cat, "values": values, "field": field})

    def add_timing(panel, field, label):
        values = {}
        for g, data in groups.items():
            v = [number(x.get(field)) for x in data]
            v = [x for x in v if x is not None]
            med, q1, q3 = (quantile(v, p) for p in [0.5, 0.25, 0.75])
            values[g] = f"{fmt_number(med)} ({fmt_number(q1)}–{fmt_number(q3)}); n = {len(v)}" if v else "Unavailable; n = 0"
            rows.append({"panel": panel, "field": field, "characteristic": label,
                         "category": "Median (IQR)", "group": g, "n": "", "total_n": len(data),
                         "evaluable_n": len(v), "denominator": len(v), "percent": "",
                         "available_n": len(v), "median": med, "q1": q1, "q3": q3})
        panels[panel].append({"kind": "group", "characteristic": label, "values": {g: "" for g in groups}, "field": field})
        panels[panel].append({"kind": "category", "characteristic": "Median (IQR), available n", "values": values, "field": field})

    add_categories("A", "bsab_product", "Bispecific antibody")
    add_categories("A", "bridging_any", "Bridging treatment")
    add_categories("A", "comparative_included", "Included in comparative analysis")
    add_categories("A", "later_bcma_exclusion", "Later BCMA-directed treatment excluded from comparison",
                   mapping=lambda x: "Yes" if category(x.get("bridging_any")) == "No" and category(x.get("comparative_included")) == "No" else "No")
    add_categories("A", "dosing_phase_at_onset", "Dosing phase at flare onset")
    for field, label, estimated in [("onset_days", "Onset timing", "onset_estimated"),
                                    ("peak_days", "Peak timing", "peak_estimated"),
                                    ("resolution_days", "Symptom-resolution timing", "resolution_estimated")]:
        def timing_category(x, field=field, estimated=estimated):
            if number(x.get(field)) is not None:
                flag = category(x.get(estimated))
                return "Estimated date" if flag == "Yes" else "Recorded date" if flag == "No" else "Date type unknown"
            if field == "onset_days" and number(x.get("onset_lower")) is not None and number(x.get("onset_upper")) is not None:
                return "Interval only"
            return "Unavailable"
        add_categories("A", f"{field}_availability", label, mapping=timing_category)
        add_timing("A", field, f"Days to {label.lower().replace(' timing', '')} after first step-up dose")

    def onset_bin(x):
        day = number(x.get("onset_days"))
        if day is None:
            return "Interval only" if number(x.get("onset_lower")) is not None and number(x.get("onset_upper")) is not None else "Unavailable"
        for lo, hi, label in [(1, 7, "Days 1–7"), (8, 14, "Days 8–14"), (15, 30, "Days 15–30"), (31, 100, "Days 31–100")]:
            if lo <= day <= hi:
                return label
        raise ValueError("An available onset date is outside the registered time windows")
    add_categories("A", "onset_window", "Onset window", mapping=onset_bin)

    phenotype = [("pain_flare", "Pain"), ("ctcae_pain_grade", "Pain grade"),
        ("palpable_enlargement", "Palpable enlargement"), ("imaging_worsening", "Imaging worsening"),
        ("new_lesion", "New lesion"), ("neurologic_cns", "Neurological or CNS manifestation"),
        ("biochemical_or_organ", "Biochemical or organ manifestation"), ("focality", "Distribution of manifestations"),
        ("known_or_new_site", "Known or new disease site"), ("skeletal_flare_type", "Skeletal lesion type"),
        ("paraskeletal_involvement", "Paraskeletal involvement during flare"), ("true_emd_classification", "True EMD during flare"),
        ("spinal_involvement", "Spinal involvement during flare"), ("cns_involvement", "CNS involvement during flare"),
        ("organ_dysfunction", "Organ dysfunction"), ("flare_hospitalization", "Admission attributed to flare"),
        ("icu_due_to_flare", "ICU care attributed to flare"), ("pathologic_fracture", "Pathological fracture"),
        ("cord_compression", "Cord compression"), ("neurologic_deficit", "Neurological deficit"),
        ("overlap_crs", "Concurrent CRS"), ("overlap_icans", "Concurrent ICANS"),
        ("overlap_infection", "Concurrent infection"), ("alternative_fracture", "Fracture as a competing explanation"),
        ("alternative_toxicity", "Other toxicity as a competing explanation"),
        ("other_competing_explanation", "Other competing explanation"),
        ("alternative_diagnosis", "Investigator assessment of an alternative diagnosis"),
        ("true_pd_within_14d", "True progression within 14 days of flare")]
    for field, label in phenotype:
        add_categories("B", field, label)

    management = [("management_steroids", "Corticosteroids"), ("management_radiation", "Radiation"),
        ("management_surgery", "Surgery or procedure"), ("management_toci_anakinra", "Tocilizumab or anakinra"),
        ("management_nonopioid", "Non-opioid analgesia"), ("management_opioids", "Opioid analgesia"),
        ("bsab_action", "Bispecific antibody treatment"), ("resolution_status", "Symptom outcome"),
        ("local_lesion_outcome", "Local-lesion outcome"), ("first_postflare_response", "First systemic response assessment after flare"),
        ("subsequent_response", "Later systemic response assessment"),
        ("best_index_response", "Best response to bispecific antibody treatment"),
        ("improved_while_bsab_continued", "Improvement without permanent treatment discontinuation")]
    for field, label in management:
        add_categories("C", field, label, supplied=[x for x in table2 if x["field"] == field])
    for field, label in [("first_response_on_index", "First assessment attributed to the treatment being evaluated"),
                         ("subsequent_response_on_index", "Later assessment attributed to the treatment being evaluated")]:
        add_categories("C", field, label)
    if context is not None:
        for field, label in [("first_response_category_estimated", "First response category estimated"),
            ("later_local_after_radiation", "Later local assessment after radiation"),
            ("later_local_after_salvage", "Later local assessment after salvage treatment"),
            ("later_local_after_cart", "Later local assessment after CAR-T"),
            ("later_local_separate_from_systemic_response", "Later local assessment distinguished from systemic response")]:
            add_categories("C", field, label)

    onset_values = [number(x.get("onset_days")) for x in merged]
    available_onset = sum(x is not None for x in onset_values)
    bins = []
    for lo, hi, label in [(1, 7, "1–7"), (8, 14, "8–14"), (15, 30, "15–30"), (31, 100, "31–100")]:
        n = sum(x is not None and lo <= x <= hi for x in onset_values)
        bins.append({"window": label, "lower_day": lo, "upper_day": hi, "n": n,
                     "denominator": available_onset, "percent": 100 * n / available_onset if available_onset else None})
    if sum(x["n"] for x in bins) != available_onset:
        raise ValueError("Onset windows do not account for all available dates")
    summaries = [{"measure": label, "n": int(x["available_n"]), "total_n": x["total_n"],
                  "median": x["median"], "q1": x["q1"], "q3": x["q3"]}
                 for field, label in [("onset_days", "Onset"), ("peak_days", "Peak"), ("resolution_days", "Symptom resolution")]
                 for x in rows if x["group"] == "All" and x["field"] == field and x["category"] == "Median (IQR)"]
    return {"groups": group_titles, "panels": panels, "aggregate_rows": rows,
            "onset_bins": bins, "timing_summaries": summaries,
            "timing_distributions": timing_distributions(merged),
            "timing_densities": timing_densities(merged), "reused_table2_fields": reused}


def write_csv(path, rows, fields=None):
    fields = fields or list(rows[0])
    with Path(path).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fields)
        writer.writeheader()
        writer.writerows(rows)


def export(result, output):
    output = Path(output)
    output.mkdir(parents=True, exist_ok=True)
    write_csv(output / "Table_S1_Aggregate.csv", result["aggregate_rows"])
    for panel, rows in result["panels"].items():
        wide = [{"Characteristic": ("  " if x["kind"] == "category" else "") + x["characteristic"],
                 **{title: x["values"][g] for g, title in result["groups"]}} for x in rows]
        write_csv(output / f"Table_S1_Panel_{panel}.csv", wide)
    write_csv(output / "Figure_2_Onset_Bins.csv", result["onset_bins"])
    write_csv(output / "Figure_2_Timing_Summaries.csv", result["timing_summaries"])
    write_csv(output / "Figure_2_Timing_Distributions.csv", result["timing_distributions"])
    write_csv(output / "Figure_2_Timing_Densities.csv", result["timing_densities"])
    (output / "Table_S1_Formatted.json").write_text(json.dumps({"groups": result["groups"], "panel_titles": PANEL_TITLES,
        "panels": result["panels"]}, indent=2, ensure_ascii=False) + "\n")
    manifest = {"display_objects": ["TABLE_S1_AGGREGATE_001", "FIGURE_2_AGGREGATE_TIMING_001",
                                   "FIGURE_2_TIMING_DISTRIBUTIONS_001", "FIGURE_2_TIMING_DENSITIES_001"],
        "clinical_group_sizes": {g: int(title.split("N = ")[1].rstrip(")")) for g, title in result["groups"]},
        "reused_table2_fields": result["reused_table2_fields"], "individual_exports": False,
        "output_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in output.iterdir()
                          if p.is_file() and p.name != "aggregate_display_registry.json"}}
    (output / "aggregate_display_registry.json").write_text(json.dumps(manifest, indent=2) + "\n")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("analysis_directory")
    parser.add_argument("output_directory")
    parser.add_argument("--context-csv")
    args = parser.parse_args()
    analysis = Path(args.analysis_directory)
    timeline_file = analysis / "case_timeline_restricted.csv"
    if not timeline_file.exists():
        timeline_file = analysis / "case_timeline.csv"
    result = aggregate(read_csv(analysis / "canonical_cases_restricted.csv"),
                       read_csv(timeline_file), read_csv(analysis / "table2_clinical_course.csv"),
                       read_csv(args.context_csv) if args.context_csv else None)
    export(result, args.output_directory)
    print(json.dumps({"group_sizes": {g: int(title.split("N = ")[1].rstrip(")")) for g, title in result["groups"]},
                      "onset_bins": [x["n"] for x in result["onset_bins"]], "timing_available": [x["n"] for x in result["timing_summaries"]],
                      "individual_exports": False}))


if __name__ == "__main__":
    main()
