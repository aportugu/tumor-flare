#!/usr/bin/env python3
"""Synthetic tests for a course-preserving Firth inference migration."""
import copy,json,math,unittest
from pathlib import Path
import streamline_publication_manifest as m
CONFIG=json.loads(Path(__file__).with_name('clinical_presentation_selection.json').read_text())['logistic_inference']

def fixture():
    beta,lower,upper,stat=.6,-.3,1.7,2.5
    old=dict(model_id='synthetic_model',scenario='primary',family='Baseline',response='flare',term='x',adjustment='',
        n_courses=22,n_patient_clusters=20,candidates=5,events=5,candidate_events=5,excluded_missing=0,estimate=math.exp(beta))
    new=dict(old,log_odds=beta,log_ci_low=lower,log_ci_high=upper,conf_low=math.exp(lower),conf_high=math.exp(upper),
        p_value=math.erfc(math.sqrt(stat/2)),full_loglik=-12,restricted_loglik=-13.25,plr_statistic=stat,plr_df=1,
        point_converged=True,profile_converged=True,plr_converged=True,model_status='Estimated (exploratory)')
    panel={'title':'Synthetic baseline','headers':['Variable','Population','Flare','Excluded','OR (95% CI)','P'],
        'rows':[{'kind':'row','model_id':'synthetic_model','cells':['Synthetic','22 / 20','5','0','old CI','old P']}]}
    caption='Bootstrap inference uses 1,000 resamples of patients, including all eligible courses for each sampled patient, and requires at least 900 successful samples and valid variance.'
    figcaption='Inference uses 1,000 bootstrap resamples of patients, including all eligible courses per sampled patient, and requires at least 900 successful resamples. Cox methods unchanged.'
    manifest={'tables':[{'label':'Table S2','title':'Baseline and response associations','content_id':'baseline_response_associations',
        'caption':caption,'panels':[panel],'code_files':['Code/analysis_functions.R']}],
        'figures':[{'label':'Figure 4','caption':figcaption,'image_data_url':'synthetic image'}],
        'aggregate_inputs':[m.input_object('models.csv',list(old),[old]),m.table_input('Table_S2_Panel_A.csv',panel)]}
    return manifest,m.input_object('models.csv',list(new),[new])

class ProfileMigrationTests(unittest.TestCase):
    def test_updates_profile_inference_without_changing_counts(self):
        before,new=fixture();after=m.register_firth_profile_models(before,new,CONFIG)
        cells=after['tables'][0]['panels'][0]['rows'][0]['cells']
        self.assertEqual(cells[:-2],before['tables'][0]['panels'][0]['rows'][0]['cells'][:-2])
        self.assertEqual(cells[-2:],['1.82 (0.74–5.47)','0.1138'])
        self.assertEqual(after['figures'][0]['image_data_url'],'synthetic image')
        self.assertIn('Cox methods unchanged',after['figures'][0]['caption'])
        self.assertIn('treated as independent',after['tables'][0]['caption'])
    def test_registration_is_idempotent(self):
        before,new=fixture();after=m.register_firth_profile_models(before,new,CONFIG)
        self.assertEqual(after,m.register_firth_profile_models(after,new,CONFIG))
    def test_changed_population_rejected(self):
        before,new=fixture();new['rows'][0][new['columns'].index('n_courses')]=21
        with self.assertRaisesRegex(ValueError,'counts changed'):m.register_firth_profile_models(before,new,CONFIG)
    def test_changed_point_estimate_rejected(self):
        before,new=fixture();new['rows'][0][new['columns'].index('estimate')]=2
        with self.assertRaisesRegex(ValueError,'point estimate changed'):m.register_firth_profile_models(before,new,CONFIG)
    def test_duplicate_model_rejected(self):
        before,new=fixture();new['rows'].append(copy.deepcopy(new['rows'][0]))
        with self.assertRaisesRegex(ValueError,'exactly once'):m.register_firth_profile_models(before,new,CONFIG)
    def test_unconverged_inference_has_no_fallback(self):
        before,new=fixture();new['rows'][0][new['columns'].index('profile_converged')]=False
        with self.assertRaisesRegex(ValueError,'must converge'):m.register_firth_profile_models(before,new,CONFIG)
    def test_sparse_note_uses_registered_profile_limits(self):
        note=m.sparse_response_note(dict(candidates=5,candidate_events=5,estimate=12.7,conf_low=1.63,conf_high=1637.83))
        self.assertIn('5 flare courses',note)
        self.assertIn('1.63–1637.83',note)
        self.assertIn('does not establish a response benefit',note)
    def test_wrong_log_bounds_rejected(self):
        before,new=fixture();new['rows'][0][new['columns'].index('conf_low')]=.9
        with self.assertRaisesRegex(ValueError,'penalized likelihood'):m.register_firth_profile_models(before,new,CONFIG)

if __name__=='__main__':unittest.main()
