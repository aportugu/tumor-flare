#!/usr/bin/env python3
"""Package only approved generic code, specifications, and synthetic fixtures."""
import argparse
import hashlib
import json
import zipfile
from pathlib import Path

APPROVED_FILES = '''
Code/Drafting/reverse_km_global_os_followup.R
Code/Drafting/verify_reverse_km_independently.py
Code/Figure1_Total_Cohort_Sankey/extract_review_transitions.py
Code/Figure1_Total_Cohort_Sankey/test_extraction.py
Code/Figure1_Total_Cohort_Sankey/test_figure1_total_cohort_sankey.R
Code/analysis_functions.R
Code/ground_truth_tests.R
Code/model_functions.R
Code/model_seed_manifest.csv
Code/reconciliation_functions.R
Code/run_analysis.R
Code/summary_functions.R
Code/survival_functions.R
Config/controlled_input_dictionary.csv
Demo/SYNTHETIC.txt
Demo/edc_cases.csv
Demo/global_os_endpoint_audit_synthetic.csv
Demo/master_courses.csv
Demo/verified_corrections.csv
Publication/aggregate_clinical_displays.py
Publication/build_figures.R
Publication/build_figures_Figure1_Total_Cohort_Sankey.R
Publication/calculate_flare_frequency.R
Publication/calculate_table_s3_immune.R
Publication/test_table_s3_immune.R
Publication/compact_main_tables.py
Publication/build_publication.py
Publication/clinical_presentation_selection.json
Publication/environment_metadata.json
Publication/extract_aggregate_inputs.py
Publication/package_source.py
Publication/reproducibility_layout.html
Publication/streamline_publication_manifest.py
Publication/test_aggregate_clinical_displays.py
Publication/test_compact_main_tables.py
Publication/test_flare_frequency.R
Publication/test_publication.py
Publication/test_streamline_publication_manifest.py
README.md
archive_allowlist.json
publication_runtime.json
renv.lock
requirements-publication.txt
source_manifest.json
'''.strip().splitlines()


def package(root, output):
    root, output = Path(root).resolve(), Path(output)
    files = sorted(APPROVED_FILES)
    missing = [name for name in files if not (root/name).is_file()]
    if missing: raise ValueError(f'Missing approved code files: {missing}')
    for name in files:
        path = root/name
        if path.is_symlink() or not path.resolve().is_relative_to(root):
            raise ValueError(f'Approved source path cannot resolve outside the package: {name}')
        if path.suffix.lower() not in {'.r', '.py', '.json', '.csv', '.txt', '.md', '.lock', '.html'}:
            raise ValueError(f'Unexpected source file type: {name}')
        if path.suffix.lower()=='.csv' and not (name.startswith('Demo/') or name.startswith('Config/') or name=='Code/model_seed_manifest.csv'):
            raise ValueError(f'Study aggregate CSVs cannot enter the source archive: {name}')
    if 'SYNTHETIC' not in (root/'Demo/SYNTHETIC.txt').read_text().upper():
        raise ValueError('Synthetic-fixture declaration is missing')
    policy='Generic code, specifications, and explicitly synthetic fixtures only. Clinical inputs, aggregate study data files, rendered study assets, and patient-level outputs are excluded.'
    allowlist={'files':files,'policy':policy,'exclude':['clinical records','analysis outputs','patient-level audit exports','aggregate study data files','rendered study figures','correspondence','References/**','__pycache__/**']}
    (root/'archive_allowlist.json').write_text(json.dumps(allowlist,indent=2)+'\n')
    hashes={name:hashlib.sha256((root/name).read_bytes()).hexdigest() for name in files if name!='source_manifest.json'}
    manifest={'sha256':hashes,'data_policy':policy,'hash_scope':'Every archive member except source_manifest.json; this avoids a recursive self-hash.'}
    (root/'source_manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    output.parent.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(output,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as archive:
        for name in files:
            info=zipfile.ZipInfo('source/'+name,date_time=(2026,11,12,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.external_attr=0o100644 << 16
            archive.writestr(info,(root/name).read_bytes())
    with zipfile.ZipFile(output) as archive:
        if set(archive.namelist()) != {'source/'+x for x in files}: raise ValueError('Archive is outside the allowlist')
        for name,digest in hashes.items():
            if hashlib.sha256(archive.read('source/'+name)).hexdigest()!=digest: raise ValueError(f'Archive hash mismatch: {name}')
    return {'file_count':len(files),'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'source_hashes':hashes,'policy':policy}


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('output',type=Path)
    p.add_argument('--root',type=Path,default=Path(__file__).resolve().parents[1])
    a=p.parse_args()
    print(json.dumps(package(a.root,a.output),indent=2))


if __name__=='__main__': main()
