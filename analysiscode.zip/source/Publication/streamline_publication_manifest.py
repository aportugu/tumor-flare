#!/usr/bin/env python3
"""Select compact aggregate displays without refitting clinical analyses.

The empirical input is an aggregate publication manifest supplied separately
from this generic code and selection configuration. The configuration names
display fields and model IDs; it contains no clinical counts or estimates.
"""
import argparse
import base64
import copy
import csv
import hashlib
import json
import math
import re
from pathlib import Path


MISSING_STATES = ("Blank", "Unknown", "Not applicable", "Not reported", "Unavailable")


def digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True,
                                     separators=(",", ":")).encode()).hexdigest()


def input_rows(item):
    return [dict(zip(item["columns"], row)) for row in item["rows"]]


def input_object(filename, columns, rows):
    return {"filename": filename, "columns": columns,
            "rows": [[row.get(key, "") for key in columns] for row in rows]}


def register_total_cohort_frequency(manifest, frequency):
    """Replace comparative frequency registration with an aggregate overall estimate.

    The exact interval is calculated by calculate_flare_frequency.R using base R.
    The figure renderer independently recalculates and verifies it from flow.csv.
    """
    filename = "Flare_Frequency_Total_Cohort.csv"
    columns = ["population", "flare_cases", "total_courses", "percent",
               "lower_95_percent", "upper_95_percent", "ci_method"]
    if frequency.get("filename") != filename or frequency.get("columns") != columns or len(frequency.get("rows", [])) != 1:
        raise ValueError("Overall flare frequency requires one aggregate row with the registered schema")
    row = input_rows(frequency)[0]
    try:
        values = [float(row[key]) for key in columns[1:6]]
    except (ValueError, TypeError):
        raise ValueError("Overall flare frequency requires numeric counts, percentage, and interval") from None
    cases, total, percent, lower, upper = values
    if not all(math.isfinite(value) for value in values) or not (cases >= 0 and total > 0 and cases <= total and cases.is_integer() and total.is_integer()):
        raise ValueError("Invalid overall flare counts")
    if abs(percent - 100 * cases / total) > 1e-10 or not (0 <= lower <= percent <= upper <= 100):
        raise ValueError("Overall flare percentage or interval conflicts with its counts")
    if row["population"] != "Total cohort" or row["ci_method"] != "Clopper-Pearson exact binomial (95%)":
        raise ValueError("Overall flare frequency has an unsupported population or interval method")
    raw = {item["filename"]: item for item in manifest["aggregate_inputs"]}
    flow = input_rows(raw["flow.csv"])
    def stage_count(stage):
        matches = [item for item in flow if item["stage"] == stage]
        if len(matches) != 1:
            raise ValueError("Missing or duplicated cohort stage: " + stage)
        return float(matches[0]["courses"])
    if cases != stage_count("Clinical series after secondary review") or total != stage_count("Total cohort"):
        raise ValueError("Overall flare frequency conflicts with registered cohort-flow counts")
    result = copy.deepcopy(manifest)
    replaced = [item for item in result["aggregate_inputs"] if item["filename"] in {"incidence.csv", filename}]
    if len(replaced) != 1:
        raise ValueError("Expected one frequency object to replace")
    result["aggregate_inputs"] = [copy.deepcopy(frequency) if item["filename"] in {"incidence.csv", filename} else item for item in result["aggregate_inputs"]]
    figure = next(item for item in result["figures"] if item["label"] == "Figure 1")
    figure["aggregate_files"] = [filename if name == "incidence.csv" else name for name in figure["aggregate_files"]]
    for code in ("Publication/calculate_flare_frequency.R", "Publication/streamline_publication_manifest.py"):
        if code not in figure["code_files"]:
            figure["code_files"].append(code)
    figure["frequency_method"] = {"population": "Total cohort", "confidence_level": 0.95,
        "interval": "Clopper-Pearson exact binomial", "unit": "Treatment course",
        "calculation": "Base R stats::binom.test", "patient_clustering_accounted_for": False}
    return result


def register_figure2_densities(manifest, densities):
    """Register aggregate timing densities without changing other results."""
    filename = "Figure_2_Timing_Densities.csv"
    columns = ["measure", "day", "density", "denominator"]
    if densities.get("filename") != filename or densities.get("columns") != columns:
        raise ValueError("Figure 2 densities require the aggregate density-grid schema")
    raw = {item["filename"]: item for item in manifest["aggregate_inputs"]}
    summaries = {row["measure"]: row for row in input_rows(raw["Figure_2_Timing_Summaries.csv"])}
    measures = ["Onset", "Peak", "Symptom resolution"]
    rows = input_rows(densities)
    if len(rows) != 303 or set(row["measure"] for row in rows) != set(measures):
        raise ValueError("Figure 2 requires 101 density-grid values for each of three measures")
    for measure in measures:
        selected = [row for row in rows if row["measure"] == measure]
        days = [float(row["day"]) for row in selected]
        if days != list(range(101)):
            raise ValueError("Figure 2 densities require an ordered daily grid from 0 to 100")
        denominator = int(summaries[measure]["n"])
        if denominator <= 0 or any(int(row["denominator"]) != denominator for row in selected):
            raise ValueError("Figure 2 density denominators disagree with available timing summaries")
        values = [float(row["density"]) for row in selected]
        if any(not math.isfinite(value) or value < 0 for value in values):
            raise ValueError("Figure 2 densities must be finite and nonnegative")
    result = copy.deepcopy(manifest)
    result["aggregate_inputs"] = [item for item in result["aggregate_inputs"]
                                   if item["filename"] != "Figure_2_Timing_Distributions.csv"]
    previous = [index for index, item in enumerate(result["aggregate_inputs"]) if item["filename"] == filename]
    if len(previous) > 1:
        raise ValueError("Figure 2 density input is registered more than once")
    if previous:
        result["aggregate_inputs"][previous[0]] = copy.deepcopy(densities)
    else:
        result["aggregate_inputs"].append(copy.deepcopy(densities))
    figure = require_one(result["figures"], label="Figure 2")
    figure["aggregate_files"] = ["Figure_2_Onset_Bins.csv", "Figure_2_Timing_Summaries.csv", filename]
    figure["density_method"] = {"kernel": "Gaussian", "bandwidth_days": 5,
        "boundary_correction": "Reflection at zero", "evaluation_grid_days": 1,
        "display_range_days": [0, 100], "display_range_only": True,
        "renormalized_within_display": False}
    return result


def register_figure5_rain(manifest, content, production):
    """Register a proposed clinical framework without changing analytical inputs.

    The conceptual content is supplied as an aggregate/publication input in the
    paired HTML. Connections describe reading order and repeat assessment; they
    are not patient pathways or estimates.
    """
    filename = "Figure_5_RAIN_Content.csv"
    columns = ["stage", "element_id", "heading", "text"]
    if content.get("filename") != filename or content.get("columns") != columns:
        raise ValueError("RAIN content requires stage, element_id, heading, and text")
    rows = input_rows(content)
    if not rows or set(row["stage"] for row in rows) != {"R", "A", "I", "N"}:
        raise ValueError("RAIN content requires all four stages R, A, I, N")
    keys = [(row["stage"], row["element_id"]) for row in rows]
    if len(keys) != len(set(keys)) or any(not row["element_id"] or not (row["heading"] or row["text"]) for row in rows):
        raise ValueError("RAIN elements must be uniquely identified and contain text")
    if any(not isinstance(row[key], str) for row in rows for key in columns):
        raise ValueError("RAIN content must contain publication text only")
    if not isinstance(production, dict):
        raise ValueError("RAIN production metadata must be a mapping")
    result = copy.deepcopy(manifest)
    previous = [index for index, item in enumerate(result["aggregate_inputs"]) if item["filename"] == filename]
    if len(previous) > 1:
        raise ValueError("RAIN content is registered more than once")
    if previous:
        result["aggregate_inputs"][previous[0]] = copy.deepcopy(content)
    else:
        result["aggregate_inputs"].append(copy.deepcopy(content))
    figure = require_one(result["figures"], label="Figure 5")
    figure["aggregate_files"] = [filename]
    if "Publication/streamline_publication_manifest.py" not in figure["code_files"]:
        figure["code_files"].append("Publication/streamline_publication_manifest.py")
    figure["framework_registration"] = {
        "type": "Proposed clinical framework",
        "stages": ["R", "A", "I", "N"],
        "connections": [
            {"source": "R", "target": "A", "kind": "forward"},
            {"source": "A", "target": "I", "kind": "forward"},
            {"source": "I", "target": "N", "kind": "forward"},
            {"source": "N", "target": "I", "kind": "reassessment", "label": "Repeat assessment"},
        ],
        "urgent_complication_management": "Alongside diagnostic evaluation",
        "formal_consensus": False,
        "diagnostic_validation": False,
        "production": copy.deepcopy(production),
    }
    return result


def table_input(filename, panel):
    rows = []
    for row in panel["rows"]:
        cells = list(row["cells"])
        cells += [""] * (len(panel["headers"]) - len(cells))
        if row.get("kind") == "category":
            cells[0] = "  " + cells[0]
        rows.append(cells)
    return {"filename": filename, "columns": panel["headers"], "rows": rows}


def number(value):
    return f"{float(value):g}"


def count_cell(row):
    return f'{int(row["n"]):,}/{int(row["denominator"]):,} ({float(row["percent"]):.1f}%)'


def require_one(rows, **criteria):
    found = [row for row in rows if all(row.get(key) == value for key, value in criteria.items())]
    if len(found) != 1:
        raise ValueError(f"Expected one aggregate row for {criteria}; found {len(found)}")
    return found[0]


def grouped_table_rows(panel):
    groups, active = {}, None
    for row in panel["rows"]:
        if row.get("kind") == "group":
            active = row["cells"][0]
            groups[active] = []
        else:
            if active is None:
                raise ValueError("Expected a characteristic heading before comparative rows")
            groups[active].append(row)
    return groups


def apply_main_table_labels(table, selection):
    """Apply approved author labels without changing numerical cells."""
    updates = selection.get("main_table_label_updates", {}).get(table["label"], {})
    for panel in table["panels"]:
        for row in panel["rows"]:
            if row.get("kind") == "group" and row["cells"][0] in updates:
                row["cells"][0] = updates[row["cells"][0]]
    return table


def build_clinical_panels(full_manifest, selection):
    full_input = next(item for item in full_manifest["aggregate_inputs"]
                      if item["filename"] == "Table_S1_Aggregate.csv")
    raw = input_rows(full_input)
    groups = selection["groups"]
    totals = {group: {int(row["total_n"]) for row in raw if row["group"] == group} for group in groups}
    if any(len(values) != 1 for values in totals.values()):
        raise ValueError("Clinical confidence groups have inconsistent denominators")
    totals = {group: values.pop() for group, values in totals.items()}
    if totals[groups[0]] != sum(totals[group] for group in groups[1:]):
        raise ValueError("Clinical confidence groups do not conserve all cases")
    headers = ["Characteristic", f'All cases (N = {totals[groups[0]]})'] + [
        f"{group} (N = {totals[group]})" for group in groups[1:]]
    panels, selected_rows, selected_keys = [], [], set()
    for panel_spec in selection["clinical_panels"]:
        output_rows = []
        for section in panel_spec["sections"]:
            if section.get("heading"):
                output_rows.append({"kind": "group", "cells": [section["heading"]]})
            for spec in section["fields"]:
                field_rows = [row for row in raw if row["field"] == spec["field"]]
                if not field_rows:
                    raise ValueError(f'Missing clinical field: {spec["field"]}')
                categories = list(dict.fromkeys(row["category"] for row in field_rows))
                field = spec["field"]
                mode = spec["mode"]
                used = []
                if mode == "categorical":
                    output_rows.append({"kind": "group", "cells": [spec["label"]], "field": field})
                    for category in categories:
                        rows = [require_one(field_rows, group=group, category=category) for group in groups]
                        output_rows.append({"kind": "category", "cells": [category] + [count_cell(row) for row in rows], "field": field})
                        used += rows
                elif mode == "timing":
                    rows = [require_one(field_rows, group=group, category="Median (IQR)") for group in groups]
                    cells = [f'{number(row["median"])} ({number(row["q1"])}–{number(row["q3"])}); n = {int(row["available_n"])}' for row in rows]
                    output_rows.append({"kind": "row", "cells": [spec["label"]] + cells, "field": field})
                    used += rows
                elif mode in ("binary", "selected_category"):
                    category = "Yes" if mode == "binary" else spec["category"]
                    # Interval-only timing is displayed only when present. An
                    # explicitly assigned date removes that current category.
                    if mode == "selected_category" and category == "Interval only":
                        matches = [row for row in field_rows if row["category"] == category]
                        if not matches or not any(int(row["n"]) for row in matches):
                            continue
                    cells = []
                    for group in groups:
                        row = require_one(field_rows, group=group, category=category)
                        parts = [count_cell(row)]
                        used.append(row)
                        for missing in MISSING_STATES:
                            matching = [row for row in field_rows if row["group"] == group and row["category"] == missing]
                            if matching and int(matching[0]["n"]) > 0:
                                parts.append(f"{missing}: {count_cell(matching[0])}")
                                used.append(matching[0])
                        cells.append("\n".join(parts))
                    output_rows.append({"kind": "row", "cells": [spec["label"]] + cells, "field": field})
                else:
                    raise ValueError(f"Unsupported clinical presentation mode: {mode}")
                for row in used:
                    key = (row["field"], row["category"], row["group"])
                    if key not in selected_keys:
                        selected_rows.append(copy.deepcopy(row))
                        selected_keys.add(key)
        panels.append({"title": panel_spec["title"], "headers": headers, "rows": output_rows})
    return panels, input_object("Table_S1_Selected_Aggregates.csv", full_input["columns"], selected_rows)


def build_comparative_tables(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S3")
    grouped = grouped_table_rows(old["panels"][0])
    primary = grouped["Primary analysis — Best response distribution"]
    strict = grouped["Definite/Probable analysis — Best response distribution"]
    primary_thresholds = grouped["Primary analysis — Best response thresholds"]
    strict_thresholds = grouped["Definite/Probable analysis — Best response thresholds"]
    primary_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in primary], label="Unavailable")["cells"][1].split("/")[1].split()[0]
    strict_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in strict], label="Unavailable")["cells"][1].split("/")[1].split()[0]
    control_n = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in primary], label="Unavailable")["cells"][2].split("/")[1].split()[0]
    headers = ["Characteristic", f"Flare (N = {primary_n})", f"Definite/Probable flare (N = {strict_n})", f"No flare (N = {control_n})"]
    rows = []
    for title, p_rows, s_rows in [("Best response distribution", primary, strict), ("Best response thresholds", primary_thresholds, strict_thresholds)]:
        rows.append({"kind": "group", "cells": [title]})
        for p, s in zip(p_rows, s_rows):
            if p["cells"][0] != s["cells"][0] or p["cells"][2] != s["cells"][2]:
                raise ValueError("Comparative response categories or control cells disagree")
            label = p["cells"][0].replace(">=", "≥")
            rows.append({"kind": "category", "cells": [label, p["cells"][1], s["cells"][1], p["cells"][2]]})
    response_panel = {"title": "Panel A Best response to bispecific antibody treatment", "headers": headers, "rows": rows}
    immune_rows = grouped["Primary analysis — Post-treatment events"]
    immune_panel = {"title": "Panel B Immune toxicities and treatment tocilizumab", "headers": ["Characteristic", f"Flare (N = {primary_n})", f"No flare (N = {control_n})", "P value"], "rows": []}
    for label in selection["immune_characteristics"]:
        row = require_one([{"label": row["cells"][0], "cells": row["cells"]} for row in immune_rows], label=label)
        cells = row["cells"]
        immune_panel["rows"].append({"kind": "row", "cells": cells[:3] + [cells[3].split("\n")[0]]})
    return [response_panel, immune_panel]


def build_logistic_table(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S4")
    visible = {row["model_id"]: row for panel in old["panels"] for row in panel["rows"]}
    raw_input = next(item for item in full_manifest["aggregate_inputs"] if item["filename"] == "models.csv")
    raw = input_rows(raw_input)
    panels, selected = [], []
    headers = ["Model", "Courses / patients", "Flare courses / total outcomes\nOutcomes in flare courses", "Excluded for missing data", "OR (95% CI)", "P value"]
    for title, ids in selection["logistic_models"].items():
        output_rows = []
        for model_id in ids:
            row = copy.deepcopy(visible[model_id])
            original = require_one(raw, model_id=model_id)
            cells = row["cells"]
            label = cells[0]
            if model_id == "strict_true_emd":
                label += "\nDefinite/Probable cases"
            elif model_id == "without_dominant_site_true_emd":
                label += "\nLargest contributing site excluded"
            cells[0] = label
            cells[2] = cells[2].replace("Flare events", "Outcomes in flare courses")
            cells[5] = "<0.0001" if cells[5].split("\n")[0] == "0.0000" else cells[5].split("\n")[0]
            output_rows.append({"kind": "row", "cells": cells[:6], "model_id": model_id})
            selected.append(original)
        panel = {"title": title, "headers": headers, "rows": output_rows}
        if "Definite/Probable response" in title:
            panel["notes"] = ["The adjusted ≥PR model includes 11 flare courses, all with at least a partial response. Its large estimate (OR 12.71; 95% CI, 6.61–24.45) is sensitive to sparse outcomes and complete separation and does not establish a response benefit."]
        panels.append(panel)
    return panels, input_object("models.csv", raw_input["columns"], selected)


def build_survival_table(full_manifest, selection):
    old = next(table for table in full_manifest["tables"] if table["label"] == "Table S5")
    panels_by_title = {panel["title"]: panel for panel in old["panels"]}
    raw_input = next(item for item in full_manifest["aggregate_inputs"] if item["filename"] == "survival_models.csv")
    raw = input_rows(raw_input)
    panels, selected, landmark_rows = [], [], []
    headers = ["Endpoint and model", "Courses / patients", "Exposed courses / exposed events", "Total events / excluded for missing data", "HR (95% CI)", "P value", "PH global / flare P"]
    title_map = {"primary": "Primary analysis", "strict": "Definite/Probable analysis", "without_dominant_site": "Largest-site-exclusion analysis"}
    for spec in selection["survival_panels"]:
        rows = []
        source_panel = panels_by_title[title_map[spec["scenario"]]]
        for endpoint in ("PFS", "OS"):
            for model in spec["models"]:
                original = require_one(raw, scenario=spec["scenario"], endpoint=endpoint, model=model)
                match = [row for row in source_panel["rows"] if row["cells"][0].split("\n") == [endpoint, "Time-dependent exposure", model]]
                if len(match) != 1:
                    raise ValueError("Survival table does not match its registered aggregate row")
                cells = copy.deepcopy(match[0]["cells"])
                short = {"Unadjusted: all eligible": "Unadjusted, all eligible courses", "Unadjusted: adjusted subset": "Unadjusted, matched analysis population", "Adjusted: six baseline variables": "Adjusted for six baseline variables"}[model]
                cells[0] = endpoint + "\n" + short
                object_id = f'{spec["scenario"]}:{endpoint}:{model}'
                rows.append({"kind": "row", "cells": cells, "object_id": object_id})
                selected.append(original)
        panels.append({"title": spec["title"], "headers": headers, "rows": rows})
    landmark_source = panels_by_title[title_map[selection["landmark_scenario"]]]
    rows = []
    for row in landmark_source["rows"]:
        if "Landmark sensitivity" not in row["cells"][0]:
            continue
        cells = copy.deepcopy(row["cells"])
        endpoint, _, day = cells[0].split("\n")
        day = day.strip().removeprefix("day ")
        cells[0] = f"{endpoint}\nDay {day} landmark"
        # Missingness exclusions do not apply to the landmark population.
        cells[3] = cells[3].split("/")[0].strip()
        rows.append({"kind": "row", "cells": cells, "object_id": f'primary:{endpoint}:landmark:{day}'})
        landmark_rows.append({"scenario": "primary", "endpoint": endpoint, "landmark_day": day,
            "n_courses": cells[1].split("/")[0].strip(), "n_patient_clusters": cells[1].split("/")[1].strip(),
            "exposed_courses": cells[2].split("/")[0].strip(), "exposed_events": cells[2].split("/")[1].strip(),
            "events": cells[3], "hr_95ci": cells[4], "p_value": cells[5], "object_id": rows[-1]["object_id"]})
    landmark_headers = list(headers)
    landmark_headers[3] = "Total events"
    panels.append({"title": "Primary landmark analyses", "headers": landmark_headers, "rows": rows})
    return panels, input_object("survival_models.csv", raw_input["columns"], selected), input_object("Table_S4_Landmark_Models.csv", list(landmark_rows[0]), landmark_rows)


def _streamline_unconsolidated(full_manifest, selection, survival_availability_note=""):
    if full_manifest.get("schema") != "tumor-flare-aggregate-publication-v1":
        raise ValueError("Selection requires the complete aggregate publication manifest")
    result = copy.deepcopy(full_manifest)
    result["schema"] = selection["publication_schema"]
    tables = [apply_main_table_labels(copy.deepcopy(table), selection) for table in full_manifest["tables"][:2]]
    clinical_panels, clinical_input = build_clinical_panels(full_manifest, selection)
    tables.append({"label": "Table S1", "title": "Additional clinical characteristics", "caption": "Additional clinical characteristics are summarized for all 33 cases, Definite/Probable cases (N = 18), and Possible cases (N = 15). Categorical counts use the full confidence-group denominator. Binary rows show positive findings; nonzero Blank, Unknown, Not applicable, Not reported, or unavailable assessments appear on separate lines. Timing summaries report the available denominator for each measure. Dates may be recorded or estimated. Missing symptom-resolution dates do not establish persistent symptoms. Clinical features and concurrent events may overlap. Investigator confidence and competing explanations express clinical uncertainty. Later local assessments after radiation, salvage treatment, or CAR-T do not establish response to the bispecific antibody treatment being evaluated. Management and clinical outcomes are shown in Table 2. CRS, cytokine release syndrome; EMD, extramedullary disease; ICANS, immune effector cell-associated neurotoxicity syndrome; IQR, interquartile range.", "panels": clinical_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Publication/clinical_presentation_selection.json"]})
    comparison_panels = build_comparative_tables(full_manifest, selection)
    tables.append({"label": "Table S2", "title": "Comparative response and immune toxicities", "caption": "Best response to the bispecific antibody treatment being evaluated is shown for the primary comparative flare group, the Definite/Probable comparative flare group, and the no-flare group. Response categories and nested thresholds use evaluable denominators; unavailable responses use the full group denominator. The Definite/Probable comparison excludes Possible cases. CRS, ICANS, and treatment tocilizumab use evaluable denominators and two-sided Fisher exact tests in the primary population. These exploratory comparisons do not account for repeated courses within patients or establish temporal order or causation. CR, complete response; CRS, cytokine release syndrome; ICANS, immune effector cell-associated neurotoxicity syndrome; MR, minimal response; PD, progressive disease; PR, partial response; sCR, stringent complete response; SD, stable disease; VGPR, very good partial response.", "panels": comparison_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/summary_functions.R"]})
    logistic_panels, logistic_input = build_logistic_table(full_manifest, selection)
    tables.append({"label": "Table S3", "title": "Baseline and response associations", "caption": "Separate univariable Firth models assess six baseline associations with flare. Response models use flare alone or adjust for age, ECOG performance status, sex, prior treatment lines, high-risk cytogenetic abnormalities, and true extramedullary disease. Sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. Counts are specific to each model. Bootstrap inference uses 1,000 resamples of patients, including all eligible courses for each sampled patient, and requires at least 900 successful samples and valid variance. Outcomes in baseline models are flare; outcomes in response models are the stated response threshold. Sparse outcomes, including all 11 flare courses responding in the adjusted Definite/Probable ≥PR model, limit inference and do not establish a response benefit. CI, confidence interval; ECOG, Eastern Cooperative Oncology Group; EMD, extramedullary disease; HRCA, high-risk cytogenetic abnormality; OR, odds ratio; PR, partial response; VGPR, very good partial response.", "panels": logistic_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/analysis_functions.R"]})
    survival_panels, survival_input, landmark_input = build_survival_table(full_manifest, selection)
    tables.append({"label": "Table S4", "title": "Survival analyses", "caption": "Time-dependent Cox models compare time after flare onset with unexposed time, using Efron ties and robust standard errors for repeated courses within patients. Primary comparative models use all eligible courses, the population of the adjusted model without adjustment, or adjustment for six baseline variables. Adjusted sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. Landmark analyses begin follow-up at days 30 and 60 among eligible courses and fix flare status at each landmark. Counts and proportional-hazards diagnostics are specific to each model. Exposed events are events after flare onset or among the flare group at the landmark. The adjusted models did not fully satisfy proportional hazards, and several sensitivity estimates rely on few exposed events. A single HR across follow-up therefore requires cautious interpretation. CI, confidence interval; HR, hazard ratio; OS, overall survival; PFS, progression-free survival; PH, proportional hazards.", "panels": survival_panels, "code_files": ["Publication/streamline_publication_manifest.py", "Code/analysis_functions.R"]})
    if survival_availability_note:
        tables[-1]["panels"][0]["notes"] = [survival_availability_note]
    result["tables"] = tables
    inputs = []
    for table in tables:
        filenames = []
        for index, panel in enumerate(table["panels"]):
            filename = table["label"].replace(" ", "_") + (f"_Panel_{chr(65 + index)}" if len(table["panels"]) > 1 else "") + ".csv"
            inputs.append(table_input(filename, panel))
            filenames.append(filename)
        table["aggregate_files"] = filenames
    inputs += [clinical_input, logistic_input, survival_input, landmark_input]
    tables[2]["aggregate_files"].append(clinical_input["filename"])
    tables[4]["aggregate_files"].append(logistic_input["filename"])
    tables[5]["aggregate_files"] += [survival_input["filename"], landmark_input["filename"]]
    full_inputs = {item["filename"]: item for item in full_manifest["aggregate_inputs"]}
    for filename in selection["unchanged_aggregate_files"]:
        inputs.append(copy.deepcopy(full_inputs[filename]))
    figure_files = {"Figure 1": ["Figure_1_Full_Cohort_Links.csv", "Figure_1_Initial_Review_Links.csv", "Figure_1B_Disposition_Links.csv", "flow.csv", "incidence.csv"], "Figure 2": ["Figure_2_Onset_Bins.csv", "Figure_2_Timing_Summaries.csv", "Figure_2_Timing_Densities.csv"], "Figure 3": ["presentation.csv", "anatomy_binary.csv"], "Figure 4": ["models.csv", "survival_models.csv"], "Figure 5": [], "Figure S1": ["landmark_km_steps.csv", "landmark_risk_counts.csv"]}
    for figure in result["figures"]:
        figure["aggregate_files"] = figure_files[figure["label"]]
        if figure["label"] == "Figure S1":
            figure["caption"] = re.sub(r" Corresponding Cox HRs .*?These conditional comparisons", " These conditional comparisons", figure["caption"])
    result["aggregate_inputs"] = inputs
    result["presentation_selection"] = {"configuration_schema": selection["schema"], "configuration_sha256": digest(selection), "model_refitting": False}
    return result


def _verify_original_selection(full, compact, selection):
    checks = []
    def check(name, value):
        checks.append({"check": name, "passed": bool(value)})
        if not value:
            raise AssertionError(name)
    check("Six publication tables in approved order", [table["label"] for table in compact["tables"]] == ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"])
    for index in range(2):
        expected = apply_main_table_labels(copy.deepcopy(full["tables"][index]), selection)
        check(f"Main table {index + 1} unchanged except approved author labels", all(compact["tables"][index][key] == expected[key] for key in expected))
    for original, selected in zip(full["figures"], compact["figures"]):
        keys = [key for key in original if original["label"] != "Figure S1" or key != "caption"]
        check(original["label"] + " unchanged display object", all(selected[key] == original[key] for key in keys))
    check("Figure S1 caption omits duplicated HR estimates", "Corresponding Cox HRs" not in compact["figures"][-1]["caption"])
    filenames = [item["filename"] for item in compact["aggregate_inputs"]]
    check("Aggregate filenames unique", len(filenames) == len(set(filenames)))
    for display in compact["tables"] + compact["figures"]:
        check(display["label"] + " downloads resolve", all(filename in filenames for filename in display["aggregate_files"]))
    for table in compact["tables"]:
        for panel in table["panels"]:
            check(table["label"] + ": " + panel["title"] + " table widths", all(row.get("kind") == "group" or len(row["cells"]) == len(panel["headers"]) for row in panel["rows"]))
    selected_clinical = input_rows(next(item for item in compact["aggregate_inputs"] if item["filename"] == "Table_S1_Selected_Aggregates.csv"))
    original_clinical = input_rows(next(item for item in full["aggregate_inputs"] if item["filename"] == "Table_S1_Aggregate.csv"))
    for row in selected_clinical:
        check("Clinical aggregate unchanged: " + ":".join(row[key] for key in ["field", "category", "group"]), row in original_clinical)
    check("Clinical group sizes are 33/18/15", {group: {int(row["total_n"]) for row in selected_clinical if row["group"] == group} for group in selection["groups"]} == {"All": {33}, "Definite/Probable": {18}, "Possible": {15}})
    onset_counts = [int(require_one(selected_clinical, field="onset_days", group=group, category="Median (IQR)")["available_n"]) for group in selection["groups"]]
    onset_totals = [int(require_one(selected_clinical, field="onset_days", group=group, category="Median (IQR)")["total_n"]) for group in selection["groups"]]
    check("Onset denominators conserve confidence groups", onset_counts[0] == sum(onset_counts[1:]) and all(0 <= count <= total for count, total in zip(onset_counts, onset_totals)))
    check("No eligibility or onset windows in selected clinical table", not ({"bridging_any", "comparative_included", "later_bcma_exclusion", "onset_window"} & {row["field"] for row in selected_clinical}))
    check("No Table 2 duplicates in clinical table", not any(row["field"].startswith("management_") or row["field"] in {"resolution_status", "local_lesion_outcome", "first_postflare_response", "subsequent_response", "best_index_response", "improved_while_bsab_continued", "bsab_action"} for row in selected_clinical))
    check("No response-attribution checks in clinical table", not any(row["field"] in {"first_response_on_index", "subsequent_response_on_index", "later_local_separate_from_systemic_response"} for row in selected_clinical))
    for filename in ("models.csv", "survival_models.csv"):
        original = input_rows(next(item for item in full["aggregate_inputs"] if item["filename"] == filename))
        chosen = input_rows(next(item for item in compact["aggregate_inputs"] if item["filename"] == filename))
        for row in chosen:
            check("Unchanged analytical object: " + filename + ":" + row.get("model_id", row.get("scenario", "") + ":" + row.get("endpoint", "") + ":" + row.get("model", "")), row in original)
    ids = [row["model_id"] for panel in compact["tables"][4]["panels"] for row in panel["rows"]]
    check("Exact approved logistic model selection", ids == [model for models in selection["logistic_models"].values() for model in models])
    strict = next(row for panel in compact["tables"][4]["panels"] for row in panel["rows"] if row["model_id"] == "strict_response_pr_adjusted")
    check("Sparse strict response estimate is visible", strict["cells"][4] == "12.71 (6.61–24.45)" and "11 / 757" in strict["cells"][2] and "Outcomes in flare courses 11" in strict["cells"][2])
    check("Sparse strict response estimate is qualified", "all with at least a partial response" in compact["tables"][4]["panels"][3]["notes"][0])
    check("Survival has ten time-dependent and four landmark rows", sum(len(panel["rows"]) for panel in compact["tables"][5]["panels"]) == 14)
    check("No historical or duplicate follow-up panels", not re.search(r"historical|alternative.onset|descriptive OS follow.up", json.dumps(compact["tables"], ensure_ascii=False), re.I))
    for filename in selection["unchanged_aggregate_files"]:
        check("Figure aggregate unchanged: " + filename, next(item for item in compact["aggregate_inputs"] if item["filename"] == filename) == next(item for item in full["aggregate_inputs"] if item["filename"] == filename))
    check("No case identifiers in aggregate schemas", not any(re.search(r"^(case_id|case_label|patient_id|case_narrative)$", column) for item in compact["aggregate_inputs"] for column in item["columns"]))
    check("No case labels in reader-facing content", not re.search(r"\bTF\d{1,3}\b", json.dumps(compact["tables"], ensure_ascii=False)))
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def panel_input_names(table):
    """Names of display CSV objects, excluding registered analytical objects."""
    stem = table["label"].replace(" ", "_")
    return [stem + (f"_Panel_{chr(65 + i)}" if len(table["panels"]) > 1 else "") + ".csv"
            for i in range(len(table["panels"]))]


def integer_count(row, key):
    value = row[key]
    result = int(value)
    if result < 0 or float(value) != result:
        raise ValueError(f"Invalid nonnegative integer count: {key}")
    return result


def response_fractions(original):
    """Reconstruct both response groups from the registered aggregate 2×2 counts."""
    total = integer_count(original, "n_courses")
    flare = integer_count(original, "candidates")
    events = integer_count(original, "events")
    flare_events = integer_count(original, "candidate_events")
    comparison, comparison_events = total - flare, events - flare_events
    if not (0 <= flare_events <= flare <= total and 0 <= comparison_events <= comparison):
        raise ValueError("Response group counts do not form a valid 2×2 table")
    return f"{flare_events}/{flare}", f"{comparison_events}/{comparison}"


def validate_logistic_counts(display, original):
    cells = display["cells"]
    population = f'{integer_count(original, "n_courses")} / {integer_count(original, "n_patient_clusters")}'
    outcomes = (f'{integer_count(original, "candidates")} / {integer_count(original, "events")}\n'
                f'Outcomes in flare courses {integer_count(original, "candidate_events")}')
    if cells[1] != population or cells[2] != outcomes or cells[3] != original["excluded_missing"]:
        raise ValueError("Logistic display counts disagree with registered analytical counts")


def consolidate_manifest(selected, selection):
    """Change only presentation objects in an already selected aggregate manifest."""
    if selected.get("schema") != selection["publication_schema"]:
        raise ValueError("Consolidation requires a selected aggregate publication manifest")
    if selected.get("presentation_selection", {}).get("consolidation_schema"):
        raise ValueError("Manifest has already been consolidated")
    result = copy.deepcopy(selected)
    config = selection["consolidation"]
    source_tables = {table["label"]: table for table in selected["tables"]}
    tables = {table["label"]: table for table in result["tables"]}
    raw_inputs = {item["filename"]: item for item in selected["aggregate_inputs"]}
    models = input_rows(raw_inputs["models.csv"])

    clinical = source_tables["Table S1"]["panels"]
    if len(clinical) != len(config["clinical_domains"]):
        raise ValueError("Clinical domain selection does not match source panels")
    if any(panel["headers"] != clinical[0]["headers"] for panel in clinical):
        raise ValueError("Clinical domains have different populations or headers")
    rows = []
    for panel, domain in zip(clinical, config["clinical_domains"]):
        rows.append({"kind": "group", "cells": [domain["title"]], "group_type": "clinical_domain"})
        rows.extend(copy.deepcopy(row) for row in panel["rows"]
                    if not (row.get("kind") == "group" and row["cells"][0] in domain["omit_group_labels"]))
    tables["Table S1"]["panels"] = [{"title": config["clinical_title"],
        "headers": copy.deepcopy(clinical[0]["headers"]), "rows": rows}]

    logistic = source_tables["Table S3"]["panels"]
    visible = {row["model_id"]: row for panel in logistic for row in panel["rows"]}
    if len(visible) != len(models):
        raise ValueError("Logistic display and analytical model selections differ")
    baseline_rows = []
    for panel in logistic[:2]:
        for row in panel["rows"]:
            original = require_one(models, model_id=row["model_id"])
            validate_logistic_counts(row, original)
            flare = integer_count(original, "candidates")
            if integer_count(original, "events") != flare or integer_count(original, "candidate_events") != flare:
                raise ValueError("Baseline outcome counts are not redundant flare counts")
            cells = copy.deepcopy(row["cells"])
            cells[2] = str(flare)
            baseline_rows.append({"kind": "row", "cells": cells, "model_id": row["model_id"]})
    baseline_headers = copy.deepcopy(logistic[0]["headers"])
    baseline_headers[2] = "Flare courses, n"
    baseline_panel = {"title": config["baseline_title"], "headers": baseline_headers, "rows": baseline_rows}
    response_rows = []
    for group in config["response_groups"]:
        originals = [require_one(models, model_id=model_id) for model_id in group["model_ids"]]
        shared = {(row["n_courses"], row["n_patient_clusters"], row["excluded_missing"]) for row in originals}
        if len(shared) != 1:
            raise ValueError("Response thresholds have different population or exclusion counts")
        courses, patients, excluded = shared.pop()
        heading = (f'{group["title"]}\n{int(courses):,} courses / {int(patients):,} patients; '
                   f'{int(excluded):,} excluded for missing data')
        response_rows.append({"kind": "group", "cells": [heading], "group_type": "response_population",
            "model_ids": list(group["model_ids"]), "n_courses": courses,
            "n_patient_clusters": patients, "excluded_missing": excluded})
        for model_id, original in zip(group["model_ids"], originals):
            source = visible[model_id]
            validate_logistic_counts(source, original)
            flare_fraction, comparison_fraction = response_fractions(original)
            threshold = source["cells"][0].removeprefix("Response ").split(" (")[0]
            response_labels = {"response_pr": "≥PR", "response_vgpr": "≥VGPR", "response_cr": "CR/sCR"}
            if original.get("response") in response_labels and threshold != response_labels[original["response"]]:
                raise ValueError("Response threshold disagrees with registered outcome")
            response_rows.append({"kind": "row", "model_id": model_id,
                "cells": [threshold, flare_fraction, comparison_fraction] + copy.deepcopy(source["cells"][-2:])})
    response_notes = list(dict.fromkeys(note.replace("The adjusted ≥PR model", "The adjusted Definite/Probable ≥PR model")
        for panel in logistic[2:] for note in panel.get("notes", [])))
    response_panel = {"title": config["response_title"], "table_class": "response-models",
        "headers": ["Threshold", "Flare response, n/N", "No-flare response, n/N", "OR (95% CI)", "P value"],
        "rows": response_rows, "notes": response_notes}
    tables["Table S3"]["panels"] = [baseline_panel, response_panel]
    tables["Table S3"]["caption"] = (
        "Panel A shows separate univariable Firth models for six baseline associations with flare and two true-EMD sensitivity analyses. "
        "Panel B shows response models using flare alone or adjustment for age, ECOG performance status, sex, prior treatment lines, high-risk cytogenetic abnormalities, and true extramedullary disease. "
        "Sensitivity analyses restrict flare to Definite/Probable cases or exclude the largest contributing site. "
        "Response fractions use the evaluable flare and no-flare courses in each model; shared course, patient, and missing-data exclusion counts appear in group headings. "
        "Bootstrap inference uses 1,000 resamples of patients, including all eligible courses for each sampled patient, and requires at least 900 successful samples and valid variance. "
        "All analyses are exploratory, and sparse outcomes limit inference. CI, confidence interval; ECOG, Eastern Cooperative Oncology Group; EMD, extramedullary disease; HRCA, high-risk cytogenetic abnormality; OR, odds ratio; PR, partial response; VGPR, very good partial response.")

    survival = source_tables["Table S4"]["panels"]
    if len(survival) != 4:
        raise ValueError("Expected three time-dependent groups and one landmark panel")
    survival_raw = input_rows(raw_inputs["survival_models.csv"])
    time_rows, diagnostics = [], []
    for panel, title in zip(survival[:3], config["survival_groups"]):
        time_rows.append({"kind": "group", "cells": [title], "group_type": "survival_population"})
        group_pairs = []
        for row in panel["rows"]:
            copied = copy.deepcopy(row)
            scenario, endpoint, model = row["object_id"].split(":", 2)
            original = require_one(survival_raw, scenario=scenario, endpoint=endpoint, model=model)
            if row["cells"][-1] != "Unavailable / Unavailable":
                pair = " / ".join(f'{float(original[key]):.4f}' for key in ("ph_global_p", "ph_flare_p"))
                if pair != row["cells"][-1]:
                    raise ValueError("PH display disagrees with registered analytical diagnostics")
                group_pairs.append(f'{endpoint} {pair.replace(" / ", "/")}')
            copied["cells"] = copied["cells"][:-1]
            time_rows.append(copied)
        diagnostics.append(title + ": " + ", ".join(group_pairs))
    ph_note = "PH global/flare P values for adjusted models: " + "; ".join(diagnostics) + ". PH diagnostics were unavailable for the other models."
    inherited_notes = list(dict.fromkeys(note for panel in survival[:3] for note in panel.get("notes", [])))
    time_panel = {"title": config["time_dependent_title"], "headers": copy.deepcopy(survival[0]["headers"][:-1]),
        "rows": time_rows, "notes": [ph_note] + inherited_notes}
    landmark_panel = copy.deepcopy(survival[3])
    landmark_panel["title"] = config["landmark_title"]
    landmark_panel["headers"] = landmark_panel["headers"][:-1]
    landmark_panel["headers"][2] = "Flare by landmark: courses / events"
    for row in landmark_panel["rows"]:
        row["cells"] = row["cells"][:-1]
    tables["Table S4"]["panels"] = [time_panel, landmark_panel]

    old_display_names = {name for table in selected["tables"] for name in panel_input_names(table)}
    inputs = [copy.deepcopy(item) for item in selected["aggregate_inputs"] if item["filename"] not in old_display_names]
    for table in result["tables"]:
        new_names = panel_input_names(table)
        inputs.extend(table_input(name, panel) for name, panel in zip(new_names, table["panels"]))
        table["aggregate_files"] = new_names + [name for name in source_tables[table["label"]]["aggregate_files"] if name not in old_display_names]
    result["aggregate_inputs"] = inputs
    result["presentation_selection"] = {"configuration_schema": selection["schema"], "configuration_sha256": digest(selection),
        "consolidation_schema": config["schema"], "model_refitting": False}
    return result


def streamline(full_manifest, selection, survival_availability_note=""):
    selected = (copy.deepcopy(full_manifest) if full_manifest.get("schema") == selection["publication_schema"]
                else _streamline_unconsolidated(full_manifest, selection, survival_availability_note))
    result = consolidate_manifest(selected, selection)
    return apply_publication_metadata(result, selection)


def apply_supplementary_table_order(manifest, selection):
    """Assign publication numbers after legacy selection and consolidation."""
    result = copy.deepcopy(manifest)
    config = selection.get("supplementary_table_order")
    if not config or not {"Table S2", "Table S3"}.issubset({t["label"] for t in result.get("tables", [])}):
        return result
    records = config["tables"]
    if {r["content_id"] for r in records} != {"baseline_response_associations", "comparative_response_immune_toxicities"}:
        raise ValueError("Invalid supplementary table identities")
    state = result.setdefault("presentation_selection", {})
    already = state.get("supplementary_order_schema")
    if already and already != config["schema"]:
        raise ValueError("Unsupported supplementary table ordering")
    names = {}
    source_tables = {table["label"]: table for table in result["tables"]}
    for record in records:
        candidates = [t for t in result["tables"] if t.get("content_id") == record["content_id"]] if already else [source_tables[record["previous_label"]]]
        if len(candidates) != 1:
            raise ValueError("Supplementary table identity is missing or duplicated")
        table = candidates[0]
        if already and table["label"] != record["label"]:
            raise ValueError("Supplementary table identity and number disagree")
        old_names = panel_input_names(table)
        table["content_id"] = record["content_id"]
        table["label"] = record["label"]
        names.update(zip(old_names, panel_input_names(table)))
    for item in result["aggregate_inputs"]:
        item["filename"] = names.get(item["filename"], item["filename"])
    for display in result["tables"] + result["figures"]:
        display["aggregate_files"] = [names.get(name, name) for name in display.get("aggregate_files", [])]
    order = ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"]
    result["tables"].sort(key=lambda table: order.index(table["label"]))
    for table in result["tables"]:
        if table["label"] == "Table S4":
            for panel in table["panels"]:
                if "notes" in panel:
                    panel["notes"] = [note for note in panel["notes"] if not ("alternative" in note.lower() and "onset" in note.lower())]
    state["supplementary_order_schema"] = config["schema"]
    return result


def legacy_table_order(manifest, selection):
    """Normalize publication numbering only for legacy consolidation checks."""
    result = copy.deepcopy(manifest)
    if not result.get("presentation_selection", {}).get("supplementary_order_schema"):
        return result
    config = selection["supplementary_table_order"]
    names = {}
    for record in config["tables"]:
        table = require_one(result["tables"], content_id=record["content_id"])
        old_names = panel_input_names(table)
        table["label"] = record["previous_label"]
        table.pop("content_id")
        names.update(zip(old_names, panel_input_names(table)))
    for item in result["aggregate_inputs"]:
        item["filename"] = names.get(item["filename"], item["filename"])
    for display in result["tables"] + result["figures"]:
        display["aggregate_files"] = [names.get(name, name) for name in display.get("aggregate_files", [])]
    result["tables"].sort(key=lambda table: ["Table 1", "Table 2", "Table S1", "Table S2", "Table S3", "Table S4"].index(table["label"]))
    result["presentation_selection"].pop("supplementary_order_schema")
    return result


def apply_publication_metadata(manifest, selection):
    """Update publication text without repeating display selection or modeling."""
    result = copy.deepcopy(manifest)
    metadata = selection.get('publication_metadata', {})
    allowed = {'title', 'author', 'build_date', 'overview', 'shared_introduction', 'download_label'}
    if set(metadata) - allowed or any(not isinstance(value, str) for value in metadata.values()):
        raise ValueError('Publication metadata must contain approved text fields only')
    result.update(metadata)
    rain = selection.get('display_registration_updates', {}).get('figure5_rain', {})
    if 'caption' in rain:
        if not isinstance(rain['caption'], str) or not rain['caption'].strip():
            raise ValueError('Figure 5 caption must contain publication text')
        figure = require_one(result['figures'], label='Figure 5')
        figure['caption'] = rain['caption']
        figure.setdefault('framework_registration', {})['caption'] = rain['caption']
        if 'title' in rain:
            if not isinstance(rain['title'], str) or not rain['title'].strip():
                raise ValueError('Figure 5 title must contain publication text')
            figure['title'] = rain['title']
    result.setdefault('presentation_selection', {})['configuration_sha256'] = digest(selection)
    return apply_supplementary_table_order(result, selection)


def verify_consolidation(before, after, selection):
    after = legacy_table_order(after, selection)
    checks = []
    def check(name, condition):
        checks.append({"check": name, "passed": bool(condition)})
        if not condition:
            raise AssertionError(name)
    old = {table["label"]: table for table in before["tables"]}
    new = {table["label"]: table for table in after["tables"]}
    check("Four numbered supplementary tables and seven physical tables", [len(new[label]["panels"]) for label in ("Table S1", "Table S2", "Table S3", "Table S4")] == [1, 2, 2, 2])
    for label in ("Table 1", "Table 2", "Table S2"):
        check(label + " unchanged", old[label] == new[label])
    expected_figures = apply_publication_metadata(before, selection)["figures"]
    check("All figure objects unchanged except a registered publication caption",
          after["figures"] == before["figures"] or after["figures"] == expected_figures)
    old_clinical = [row for panel in old["Table S1"]["panels"] for row in panel["rows"] if row["kind"] != "group"]
    new_clinical = [row for panel in new["Table S1"]["panels"] for row in panel["rows"] if row["kind"] != "group"]
    check("All clinical values and missing states unchanged", old_clinical == new_clinical)
    old_display_names = {name for table in before["tables"] for name in panel_input_names(table)}
    new_inputs = {item["filename"]: item for item in after["aggregate_inputs"]}
    for item in before["aggregate_inputs"]:
        if item["filename"] not in old_display_names:
            check("Analytical aggregate object unchanged: " + item["filename"], new_inputs.get(item["filename"]) == item)
    models = input_rows(new_inputs["models.csv"])
    old_models = {row["model_id"]: row for panel in old["Table S3"]["panels"] for row in panel["rows"]}
    new_models = {row["model_id"]: row for panel in new["Table S3"]["panels"] for row in panel["rows"] if row.get("model_id")}
    check("All twenty logistic model IDs retained exactly once", len(new_models) == 20 and set(new_models) == set(old_models) and sum(bool(row.get("model_id")) for panel in new["Table S3"]["panels"] for row in panel["rows"]) == 20)
    for model_id, row in new_models.items():
        original = require_one(models, model_id=model_id)
        if "response_" in model_id:
            check("Exact registered response fractions: " + model_id, tuple(row["cells"][1:3]) == response_fractions(original))
            check("Response OR and P unchanged: " + model_id, row["cells"][-2:] == old_models[model_id]["cells"][-2:])
        else:
            expected = copy.deepcopy(old_models[model_id]["cells"])
            expected[2] = original["candidates"]
            check("Baseline cells unchanged except redundant count: " + model_id, row["cells"] == expected)
    for row in new["Table S3"]["panels"][1]["rows"]:
        if row["kind"] == "group":
            raw = [require_one(models, model_id=model_id) for model_id in row["model_ids"]]
            check("Response population shared across thresholds: " + row["cells"][0].split("\n")[0], all(tuple(item[key] for key in ("n_courses", "n_patient_clusters", "excluded_missing")) == tuple(row[key] for key in ("n_courses", "n_patient_clusters", "excluded_missing")) for item in raw))
    check("Sparse strict response qualification retained", any("all with at least a partial response" in note and "does not establish a response benefit" in note for note in new["Table S3"]["panels"][1].get("notes", [])))
    old_survival = {row["object_id"]: row for panel in old["Table S4"]["panels"] for row in panel["rows"]}
    new_survival = {row["object_id"]: row for panel in new["Table S4"]["panels"] for row in panel["rows"] if row.get("object_id")}
    check("All fourteen survival IDs retained exactly once", len(new_survival) == 14 and set(old_survival) == set(new_survival) and sum(bool(row.get("object_id")) for panel in new["Table S4"]["panels"] for row in panel["rows"]) == 14)
    for object_id, row in new_survival.items():
        check("Survival counts and estimates unchanged: " + object_id, row["cells"] == old_survival[object_id]["cells"][:-1])
    ph_note = new["Table S4"]["panels"][0]["notes"][0]
    for row in old_survival.values():
        if row["cells"][-1] != "Unavailable / Unavailable":
            check("PH pair retained: " + row["object_id"], row["cells"][-1].replace(" / ", "/") in ph_note)
    check("Other PH diagnostics explicitly unavailable", "PH diagnostics were unavailable for the other models." in ph_note)
    for table in after["tables"]:
        for panel in table["panels"]:
            check(table["label"] + ": " + panel["title"] + " widths", all(row["kind"] == "group" or len(row["cells"]) == len(panel["headers"]) for row in panel["rows"]))
        check(table["label"] + " registered inputs resolve", all(name in new_inputs for name in table["aggregate_files"]))
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def verify_selection(full, compact, selection):
    if full.get("schema") == selection["publication_schema"]:
        return verify_consolidation(full, compact, selection)
    selected = _streamline_unconsolidated(full, selection)
    old_checks = _verify_original_selection(full, selected, selection)
    new_checks = verify_consolidation(selected, compact, selection)
    checks = old_checks["checks"] + new_checks["checks"]
    return {"passed": True, "checks_count": len(checks), "checks": checks}


def write_outputs(full, compact, selection, output_directory):
    output = Path(output_directory)
    output.mkdir(parents=True, exist_ok=True)
    aggregate_directory = output / "Aggregate_Inputs"
    aggregate_directory.mkdir(exist_ok=True)
    (output / "aggregate_publication_manifest.json").write_text(json.dumps(compact, ensure_ascii=False, indent=2) + "\n")
    for item in compact["aggregate_inputs"]:
        with (aggregate_directory / item["filename"]).open("w", newline="", encoding="utf-8") as stream:
            writer = csv.writer(stream)
            writer.writerow(item["columns"])
            writer.writerows(item["rows"])
    checks = verify_selection(full, compact, selection)
    (output / "streamlining_acceptance_checks.json").write_text(json.dumps(checks, indent=2) + "\n")
    registry = {"schema": "tumor-flare-streamlined-display-registry-v1", "full_manifest_sha256": digest(full), "selected_manifest_sha256": digest(compact), "selection_sha256": digest(selection), "model_refitting": False, "displays": [{"label": display["label"], "caption": display["caption"], "aggregate_files": display["aggregate_files"], "executable_source": display["code_files"]} for display in compact["tables"] + compact["figures"]], "aggregate_files": [{"filename": item["filename"], "rows": len(item["rows"]), "sha256": hashlib.sha256((aggregate_directory / item["filename"]).read_bytes()).hexdigest()} for item in compact["aggregate_inputs"]]}
    (output / "streamlining_display_registry.json").write_text(json.dumps(registry, ensure_ascii=False, indent=2) + "\n")
    return checks


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("full_manifest", type=Path)
    parser.add_argument("output_directory", type=Path)
    parser.add_argument("--selection", type=Path, default=Path(__file__).with_name("clinical_presentation_selection.json"))
    parser.add_argument("--survival-availability-note", default="", help="Verified aggregate availability note supplied separately from generic code")
    args = parser.parse_args()
    full = json.loads(args.full_manifest.read_text())
    selection = json.loads(args.selection.read_text())
    compact = streamline(full, selection, args.survival_availability_note)
    checks = write_outputs(full, compact, selection, args.output_directory)
    print(f'Selected {len(compact["tables"])} tables, {len(compact["figures"])} figures, and {len(compact["aggregate_inputs"])} aggregate inputs; {checks["checks_count"]} checks passed.')


if __name__ == "__main__":
    main()
