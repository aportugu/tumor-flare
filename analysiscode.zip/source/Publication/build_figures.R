#!/usr/bin/env Rscript
# Publication figures from the canonical, reconciled tumor-flare analysis.
# This file uses relative paths and contains no patient identifiers or dates.
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
})
args <- commandArgs(trailingOnly = TRUE)
input_dir <- if (length(args) >= 1L) args[1] else "analysis"
output_dir <- if (length(args) >= 2L) args[2] else "publication"
framework_only <- "--framework-only" %in% args
dir.create(file.path(output_dir, "Figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Display_data"), recursive = TRUE, showWarnings = FALSE)
font_family <- "Helvetica"
colours <- c("Yes" = "#1B5678", "No" = "#D6DCE0", "Unknown" = "#BB9153", "Not applicable" = "#A9A6B8")
theme_paper <- function(size = 10) {
  theme_classic(base_size = size, base_family = font_family) +
    theme(plot.title = element_text(face = "bold", size = size + 1, hjust = 0),
          plot.subtitle = element_text(size = size - 1, lineheight = 1.1),
          axis.title = element_text(size = size), axis.text = element_text(colour = "#222222"),
          legend.position = "bottom", legend.title = element_blank(),
          plot.margin = margin(8, 10, 8, 8))
}
read_input <- function(name, required = character()) {
  path <- file.path(input_dir, paste0(name, ".csv"))
  if (!file.exists(path)) stop("Missing canonical output: ", path)
  x <- read_csv(path, show_col_types = FALSE, progress = FALSE)
  x <- x %>% mutate(across(where(is.character), ~gsub("\u2265", ">=", gsub("\u2013|\u2014|\u2212", "-", .x))))
  missing <- setdiff(required, names(x))
  if (length(missing)) stop(name, " lacks required columns: ", paste(missing, collapse = ", "))

  x
}
save_display_data <- function(x, name) {
  stopifnot(!any(grepl("(^|_)(course_id|patient_id|mrn|source_reference|narrative|calendar_date|start_date)$", names(x))))
  write_csv(x, file.path(output_dir, "Display_data", paste0(name, ".csv")), na = "")
}
# Use a font-embedding PDF device on each platform.
embedded_pdf <- function(filename, width, height, family, bg, ...) {
  if (Sys.info()[["sysname"]] == "Darwin") {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = family, bg = bg)
  } else {
    grDevices::cairo_pdf(filename = filename, width = width,
                        height = height, family = family, bg = bg)
  }
}
save_figure <- function(p, name, width, height) {
  pdf_path <- file.path(output_dir, "Figures", paste0(name, ".pdf"))
  png_path <- file.path(output_dir, "Figures", paste0(name, ".png"))
  ggsave(pdf_path, p, device = embedded_pdf, width = width, height = height,
         units = "in", family = font_family, bg = "white")
  ggsave(png_path, p, device = ragg::agg_png, width = width, height = height,
         units = "in", dpi = 320, bg = "white")
}
panel_title <- function(letter, title) paste0(letter, "  ", title)
box_layer <- function(x, y, w, h, label, fill = "#EEF2F4", size = 3.4) {
  list(annotate("rect", xmin = x - w/2, xmax = x + w/2, ymin = y - h/2,
                ymax = y + h/2, fill = fill, colour = "#34424B", linewidth = 0.45),
       annotate("text", x = x, y = y, label = label, family = font_family,
                size = size, lineheight = 1.1))
}
arrow_layer <- function(x, y, xend, yend, colour = "#34424B") {
  annotate("segment", x = x, y = y, xend = xend, yend = yend, colour = colour,
           linewidth = .55, arrow = grid::arrow(length = grid::unit(2.5, "mm")))
}

# DISPLAY Figure5 START
recognition_framework <- function() {
  ggplot() +
    box_layer(4.7, 9.2, 8.0, 1.05,
              "New focal pain, swelling, or apparent lesion worsening\nafter bispecific antibody initiation") +
    arrow_layer(4.7, 8.67, 4.7, 8.18) +
    box_layer(4.7, 7.55, 8.0, 1.25,
              "Assess immediately for urgent complications\nNeurological compromise, cord compression, fracture,\norgan dysfunction, or hemodynamic instability", "#FAECEA") +
    arrow_layer(4.7, 6.92, 4.7, 6.42) +
    box_layer(4.7, 5.73, 8.0, 1.35,
              "Evaluate competing explanations\nTrue progression, infection, CRS or ICANS, structural injury,\nand other treatment-related or unrelated causes") +
    arrow_layer(4.7, 5.05, 4.7, 4.52) +
    box_layer(4.7, 3.80, 8.0, 1.4,
              "Integrate evidence and individualize treatment\nClinical course, biochemical trajectory, imaging, and biopsy when feasible\nAddress complications and symptoms; reassess the risks and benefits\nof continuing, interrupting, or changing therapy") +
    arrow_layer(4.7, 3.09, 4.7, 2.55) +
    box_layer(4.7, 1.78, 8.0, 1.5,
              "Reassess over time\nDocument symptom recovery, local lesion outcome, and systemic response\nseparately; record treatment changes and unresolved attribution\nRevise the working diagnosis as evidence develops", "#EAF2F5") +
    annotate("text", x = 4.7, y = .38,
             label = "Proposed clinical framework; diagnostic criteria and treatment decisions require prospective validation.",
             family = font_family, size = 3.1, colour = "#333333") +
    coord_cartesian(xlim = c(.2, 9.2), ylim = c(0, 10), expand = FALSE) +
    theme_void(base_family = font_family) + theme(plot.margin = margin(12, 10, 10, 10))
}
save_figure(recognition_framework(), "Figure_5_Recognition_framework", 8.5, 9.0)
save_display_data(data.frame(step = 1:5,
  action = c("Recognize new focal symptoms or apparent lesion worsening", "Assess urgent complications",
             "Evaluate competing explanations", "Integrate evidence and individualize treatment",
             "Reassess over time"), validation = "Proposed framework"), "Figure_5")
# DISPLAY Figure5 END
if (framework_only) quit(save = "no", status = 0L)



# DISPLAY Figure2 START
# Only aggregate inputs enter these figures. Recorded and explicitly estimated
# dates enter the numerical summaries; unavailable dates do not.
onset <- read_input("Figure_2_Onset_Bins", c("window", "lower_day", "upper_day", "n", "denominator", "percent"))
timing <- read_input("Figure_2_Timing_Summaries", c("measure", "n", "total_n", "median", "q1", "q3"))
ridges <- read_input("Figure_2_Timing_Distributions", c("measure", "lower_day", "upper_day", "n", "denominator", "percent"))
stopifnot(nrow(onset) == 4L, length(unique(onset$denominator)) == 1L,
          all(onset$denominator > 0), sum(onset$n) == onset$denominator[1],
          all(abs(onset$percent - 100*onset$n/onset$denominator) < 1e-10),
          timing$n[timing$measure == "Onset"] == onset$denominator[1],
          length(unique(timing$total_n)) == 1L, all(timing$n <= timing$total_n),
          all(timing$q1 <= timing$median),
          all(timing$median <= timing$q3))
measure_order <- c("Onset", "Peak", "Symptom resolution")
stopifnot(nrow(ridges) == 60L, setequal(unique(ridges$measure), measure_order),
          !anyDuplicated(ridges[c("measure", "lower_day", "upper_day")]),
          all(ridges$n >= 0 & ridges$n == floor(ridges$n)),
          all(is.finite(ridges$percent)), all(ridges$denominator > 0),
          all(abs(ridges$percent - 100*ridges$n/ridges$denominator) < 1e-10))
for (measure_name in measure_order) {
  z <- ridges %>% filter(measure == measure_name) %>% arrange(lower_day)
  expected_n <- timing$n[timing$measure == measure_name]
  stopifnot(nrow(z) == 20L, identical(z$lower_day, as.numeric(seq(1, 96, 5))),
            identical(z$upper_day, as.numeric(seq(5, 100, 5))),
            all(z$denominator == expected_n), sum(z$n) == expected_n,
            abs(sum(z$percent) - 100) < 1e-10)
}
onset <- onset %>% mutate(window = factor(window, levels = window),
                         value_label = sprintf("%d (%.1f%%)", n, percent))
p_a <- ggplot(onset, aes(window, n)) +
  geom_col(fill = "#1B5678", width = .62) +
  geom_text(aes(label = value_label), vjust = -.6, family = font_family, size = 3.35) +
  scale_y_continuous(limits = c(0, 33), breaks = c(0, 10, 20, 30),
                     expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("A", "Onset timing"),
       x = "Days after first step-up dose", y = "Cases") +
  theme_paper(10) + theme(axis.line.x = element_blank(), axis.ticks.x = element_blank(),
                          axis.text = element_text(size = 9.2),
                          axis.title.y = element_text(margin = margin(r = 6)))
row_baselines <- setNames(c(3.0, 1.8, .6), measure_order)
timing <- timing %>% mutate(baseline = unname(row_baselines[measure]),
                           n_label = paste0(measure, " (n = ", n, ")"),
                           label = sprintf("%g (%g-%g) days", median, q1, q3))
# A common linear height scale preserves the percentage in each five-day bin.
# The largest bin is 0.65 plot units high; no row-specific peak normalization.
ridge_height_scale <- .65 / max(ridges$percent)
ridge_polygons <- bind_rows(lapply(measure_order, function(measure_name) {
  z <- ridges %>% filter(measure == measure_name) %>% arrange(lower_day)
  baseline <- unname(row_baselines[measure_name])
  boundaries <- c(z$lower_day[1] - 1, z$upper_day)
  vertices <- data.frame(x = c(boundaries[1], as.vector(rbind(boundaries[-length(boundaries)], boundaries[-1])),
                                tail(boundaries, 1)),
                         y = c(baseline, rep(baseline + z$percent * ridge_height_scale, each = 2), baseline),
                         measure = measure_name)
  vertices
}))
ridge_colours <- c(Onset = "#1B5678", Peak = "#9B6A2D", "Symptom resolution" = "#547761")
p_b <- ggplot() +
  geom_polygon(data = ridge_polygons, aes(x, y, group = measure, fill = measure, colour = measure),
               linewidth = .35, alpha = .68) +
  geom_segment(data = timing, aes(x = 0, xend = 100, y = baseline, yend = baseline),
               colour = "#849098", linewidth = .25) +
  geom_segment(data = timing, aes(x = q1, xend = q3, y = baseline - .14, yend = baseline - .14,
                                 colour = measure), linewidth = 1.15, lineend = "butt") +
  geom_point(data = timing, aes(x = median, y = baseline - .14, colour = measure), size = 2.3) +
  geom_text(data = timing, aes(x = 0, y = baseline + .82, label = n_label), hjust = 0,
            family = font_family, size = 3.35, colour = "#222222") +
  geom_text(data = timing, aes(x = 100, y = baseline + .82, label = label), hjust = 1,
            family = font_family, size = 3.2, colour = "#222222") +
  scale_colour_manual(values = ridge_colours, guide = "none") +
  scale_fill_manual(values = ridge_colours, guide = "none") +
  scale_y_continuous(limits = c(.25, 4.05), breaks = NULL, expand = expansion(mult = c(0, 0))) +
  scale_x_continuous(breaks = seq(0, 100, 20), limits = c(0, 100), expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("B", "Timing distributions"),
       x = "Days after first step-up dose", y = NULL) +
  theme_paper(10) + theme(axis.line.y = element_blank(), axis.ticks.y = element_blank(),
                          axis.text = element_text(size = 9.2),
                          axis.text.y = element_blank())
save_figure(p_a / p_b + plot_layout(heights = c(1, 1.2)), "Figure_2_Aggregate_timing", 7.2, 6.2)
save_display_data(onset %>% select(-value_label), "Figure_2_Onset_Bins")
save_display_data(timing %>% select(measure, n, total_n, median, q1, q3), "Figure_2_Timing_Summaries")
save_display_data(ridges %>% select(measure, lower_day, upper_day, n, denominator, percent), "Figure_2_Timing_Distributions")
# DISPLAY Figure2 END

# DISPLAY Figure3 START
status_bars <- function(x, title) {
  stopifnot(all(c("label", "category", "n", "denominator") %in% names(x)))
  x <- x %>% mutate(category = ifelse(is.na(category) | category == "", "Unknown", category))
  if (!all(x$category %in% names(colours))) stop("Unexpected clinical status category")
  labels <- unique(x$label)
  x <- x %>% mutate(label = factor(label, levels = rev(labels)), category = factor(category, levels = names(colours)), proportion = n/denominator)
  yes <- x %>% filter(category == "Yes")
  ggplot(x, aes(proportion, label, fill = category)) + geom_col(width = .64, position = position_stack(reverse = TRUE), colour = "white", linewidth = .25, show.legend = TRUE) +
    geom_text(data = yes, aes(x = 1.02, y = label, label = paste0(n, "/", denominator)), inherit.aes = FALSE,
              hjust = 0, size = 3.0, family = font_family) +
    scale_fill_manual(values = colours, drop = FALSE) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1), breaks = c(0, .25, .5, .75, 1), expand = expansion(mult = c(0, 0))) +
    coord_cartesian(xlim = c(0, 1.14), clip = "off") +
    labs(title = title, x = "Proportion of tumor flare cases", y = NULL) + theme_paper(9.5) +
    theme(axis.line.y = element_blank(), axis.ticks.y = element_blank())
}
presentation <- read_input("presentation", c("field", "label", "panel", "category", "n", "denominator"))
anatomy <- read_input("anatomy_binary", c("field", "label", "category", "n", "denominator"))
presentation <- presentation %>% mutate(label = case_when(
  field == "flare_hospitalization" ~ "Admission attributed to flare",
  field == "icu_due_to_flare" ~ "ICU care attributed to flare",
  TRUE ~ label))
true_emd <- anatomy %>% filter(field == "true_emd_any")
stopifnot(sum(true_emd$n) == 33,
          all(c("No", "Yes", "Unknown", "Not applicable") %in% true_emd$category),
          true_emd$n[true_emd$category == "Unknown"] == 6,
          true_emd$n[true_emd$category == "Not applicable"] == 1)
manifest <- presentation %>% filter(field %in% c("pain_flare", "palpable_enlargement", "imaging_worsening", "new_lesion", "neurologic_cns", "biochemical_or_organ"))
impact <- presentation %>% filter(field %in% c("organ_dysfunction", "flare_hospitalization", "neurologic_deficit", "pathologic_fracture", "cord_compression", "icu_due_to_flare"))
site <- anatomy %>% filter(field %in% c("true_emd_any", "paraskeletal_involvement", "spinal_involvement", "cns_involvement"))
save_figure((status_bars(manifest, panel_title("A", "Clinical manifestations")) /
             status_bars(impact, panel_title("B", "Clinical impact")) /
             status_bars(site, panel_title("C", "Anatomical involvement during flare"))) + plot_layout(guides = "collect") & theme(legend.position = "bottom"),
            "Figure_3_Clinical_spectrum", 9.5, 10)
save_display_data(bind_rows(manifest, impact, site), "Figure_3")
# DISPLAY Figure3 END

# DISPLAY Figure4 START
forest <- function(x, title, metric) {
  stopifnot(all(c("label", "estimate", "conf_low", "conf_high", "n_courses", "candidates") %in% names(x)))
  x <- x %>% mutate(row = rev(row_number()))
  rng <- range(c(x$conf_low, x$conf_high, 1), na.rm = TRUE)
  rng <- c(max(.01, rng[1] * .8), rng[2] * 1.2)
  labels <- ggplot(x, aes(y = row)) + geom_text(aes(x = 0, label = label), hjust = 0, family = font_family, size = 3.0) +
    coord_cartesian(xlim = c(0, 1), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  values <- x %>% mutate(value = ifelse(is.finite(estimate), sprintf("%.2f (%.2f-%.2f)", estimate, conf_low, conf_high), "Not estimated"),
    population = paste0("N=", format(n_courses, big.mark = ","), "; flare=", candidates))
  right <- ggplot(values, aes(y = row)) + geom_text(aes(x = 0, label = value), hjust = 0, family = font_family, size = 3.0) +
    geom_text(aes(x = .60, label = population), hjust = 0, family = font_family, size = 2.75) +
    coord_cartesian(xlim = c(0, 1.35), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  center <- ggplot(x, aes(estimate, row)) + geom_vline(xintercept = 1, linetype = "dashed", colour = "#89949C", linewidth = .4) +
    geom_errorbar(aes(xmin = conf_low, xmax = conf_high), orientation = "y", width = .12, linewidth = .55, na.rm = TRUE) +
    geom_point(size = 2.1, colour = "#1B5678", na.rm = TRUE) + scale_x_log10(limits = rng) +
    coord_cartesian(ylim = c(.35, nrow(x) + .65)) + labs(x = paste0(metric, " (95% CI)"), y = NULL) + theme_paper(8.5) +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(), axis.line.y = element_blank(),
          plot.margin = margin(4, 4, 4, 4))
  (labels + center + right + plot_layout(widths = c(1.05, 1.0, 1.55))) +
    plot_annotation(title = title, theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 11)))
}
models <- read_input("models", c("scenario", "family", "label", "estimate", "conf_low", "conf_high", "n_courses", "candidates"))
survival <- read_input("survival_models", c("scenario", "model", "endpoint", "estimate", "conf_low", "conf_high", "n_courses", "exposed_courses"))
baseline <- models %>% filter(scenario == "primary", family == "Baseline")
responses <- models %>% filter(scenario == "primary", family == "Response", !is.na(adjustment), adjustment != "")
surv_primary <- survival %>% filter(scenario == "primary", grepl("Adjusted", model)) %>%
  mutate(label = endpoint, candidates = exposed_courses)
if (nrow(baseline) != 6L || nrow(responses) != 3L || nrow(surv_primary) != 2L) stop("Figure4 model selection is not 6 baseline/3 response/2 survival models")
save_figure(wrap_plots(list(
              wrap_elements(full = forest(baseline, panel_title("A", "Baseline associations with tumor flare"), "OR")),
              wrap_elements(full = forest(responses, panel_title("B", "Adjusted best-response associations"), "OR")),
              wrap_elements(full = forest(surv_primary, panel_title("C", "Adjusted time-dependent survival associations"), "HR"))),
              ncol = 1, heights = c(6, 3.3, 2.6)), "Figure_4_Association_models", 12, 9)
save_display_data(bind_rows(baseline, responses, surv_primary) %>% select(any_of(c("scenario", "family", "model", "label", "endpoint", "estimate", "conf_low", "conf_high", "p_value", "n_courses", "n_patient_clusters", "candidates", "events", "adjustment", "bootstrap_successes", "bootstrap_requested", "model_status"))), "Figure_4")
# DISPLAY Figure4 END

# DISPLAY FigureS1 START
km <- read_input("landmark_km_steps", c("endpoint", "landmark_day", "group", "time", "survival", "lower", "upper"))
risk <- read_input("landmark_risk_counts", c("endpoint", "landmark_day", "group", "time", "n_risk"))
group_label <- function(x) ifelse(as.character(x) == "0", "No flare by landmark", ifelse(as.character(x) == "1", "Flare by landmark", as.character(x)))
km <- km %>% mutate(group = group_label(group))
risk <- risk %>% mutate(group = group_label(group))
group_colours <- c("No flare by landmark" = "#65747E", "Flare by landmark" = "#1B5678")
landmark_panel <- function(endpoint_value, day_value, letter) {
  x <- km %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  r <- risk %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  stopifnot(nrow(x) > 0, nrow(r) > 0)
  xmax <- max(r$time)
  x <- x %>% arrange(group, time)
  step_band <- x %>% group_by(group) %>% mutate(next_time = lead(time)) %>% ungroup()
  step_band <- bind_rows(step_band %>% mutate(order = 1), step_band %>% filter(is.finite(next_time)) %>% mutate(time = next_time, order = 0)) %>% arrange(group, time, order)
  # Canonical landmark KM and risk-count time fields are elapsed months.
  p <- ggplot(x, aes(time, survival, colour = group, fill = group)) +
    geom_ribbon(data = step_band, aes(ymin = lower, ymax = upper), alpha = .12, colour = NA) + geom_step(linewidth = .65) +
    scale_colour_manual(values = group_colours) + scale_fill_manual(values = group_colours) +
    scale_y_continuous(limits = c(0, 1), labels = scales::label_percent(accuracy = 1)) +
    scale_x_continuous(breaks = sort(unique(r$time)), labels = scales::label_number(accuracy = 1)) + coord_cartesian(xlim = c(0, xmax)) +
    labs(title = panel_title(letter, paste0(endpoint_value, " at day ", day_value)), x = "Months after landmark", y = paste0(endpoint_value, " probability")) +
    theme_paper(9) + theme(legend.position = "bottom")
  groups <- c("Flare by landmark", "No flare by landmark")
  r <- r %>% mutate(row = match(group, rev(groups)))
  rt <- ggplot(r, aes(time, row, label = n_risk, colour = group)) + geom_text(family = font_family, size = 2.7) +
    scale_colour_manual(values = group_colours) + scale_x_continuous(breaks = sort(unique(r$time))) +
    scale_y_continuous(breaks = 1:2, labels = rev(groups)) + coord_cartesian(xlim = c(0, xmax), ylim = c(.4, 2.6), clip = "off") +
    labs(x = NULL, y = NULL, title = "Number at risk") + theme_void(base_family = font_family) +
    theme(axis.text.y = element_text(size = 7, hjust = 1), plot.title = element_text(size = 8.5, hjust = 0),
          plot.margin = margin(3, 10, 3, 8), legend.position = "none")
  p / rt + plot_layout(heights = c(4.2, 1))
}
save_figure(wrap_plots(list(
              wrap_elements(full = landmark_panel("PFS", 30, "A")),
              wrap_elements(full = landmark_panel("OS", 30, "B")),
              wrap_elements(full = landmark_panel("PFS", 60, "C")),
              wrap_elements(full = landmark_panel("OS", 60, "D"))), ncol = 2, nrow = 2),
            "Figure_S1_Landmark_survival", 12, 9.5)
save_display_data(km, "Figure_S1_KM")
save_display_data(risk, "Figure_S1_Risk")
# DISPLAY FigureS1 END
cat("Publication figures exported from", normalizePath(input_dir), "\n")
