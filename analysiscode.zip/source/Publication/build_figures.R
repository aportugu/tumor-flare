#!/usr/bin/env Rscript
# Publication figures from the canonical, reconciled tumor-flare analysis.
# This file uses relative paths and contains no patient identifiers or dates.
suppressPackageStartupMessages({
  library(ggplot2)
  library(dplyr)
  library(tidyr)
  library(readr)
  library(patchwork)
})
args <- commandArgs(trailingOnly = TRUE)
input_dir <- if (length(args) >= 1L) args[1] else "analysis"
output_dir <- if (length(args) >= 2L) args[2] else "publication"
framework_only <- "--framework-only" %in% args
dir.create(file.path(output_dir, "Figures"), recursive = TRUE, showWarnings = FALSE)
dir.create(file.path(output_dir, "Display_data"), recursive = TRUE, showWarnings = FALSE)
font_family <- "Helvetica"
colours <- c("Yes" = "#1B5678", "No" = "#D6DCE0", "Unknown" = "#BB9153", "Not applicable" = "#A9A6B8")
theme_paper <- function(size = 10) {
  theme_classic(base_size = size, base_family = font_family) +
    theme(plot.title = element_text(face = "bold", size = size + 1, hjust = 0),
          plot.subtitle = element_text(size = size - 1, lineheight = 1.1),
          axis.title = element_text(size = size), axis.text = element_text(colour = "#222222"),
          legend.position = "bottom", legend.title = element_blank(),
          plot.margin = margin(8, 10, 8, 8))
}
read_input <- function(name, required = character()) {
  path <- file.path(input_dir, paste0(name, ".csv"))
  if (!file.exists(path)) stop("Missing canonical output: ", path)
  x <- read_csv(path, show_col_types = FALSE, progress = FALSE)
  x <- x %>% mutate(across(where(is.character), ~gsub("\u2265", ">=", gsub("\u2013|\u2014|\u2212", "-", .x))))
  missing <- setdiff(required, names(x))
  if (length(missing)) stop(name, " lacks required columns: ", paste(missing, collapse = ", "))

  x
}
save_display_data <- function(x, name) {
  stopifnot(!any(grepl("(^|_)(course_id|patient_id|mrn|source_reference|narrative|calendar_date|start_date)$", names(x))))
  write_csv(x, file.path(output_dir, "Display_data", paste0(name, ".csv")), na = "")
}
# Use a font-embedding PDF device on each platform.
embedded_pdf <- function(filename, width, height, family, bg, ...) {
  if (Sys.info()[["sysname"]] == "Darwin") {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = family, bg = bg)
  } else {
    grDevices::cairo_pdf(filename = filename, width = width,
                        height = height, family = family, bg = bg)
  }
}
save_figure <- function(p, name, width, height) {
  pdf_path <- file.path(output_dir, "Figures", paste0(name, ".pdf"))
  png_path <- file.path(output_dir, "Figures", paste0(name, ".png"))
  ggsave(pdf_path, p, device = embedded_pdf, width = width, height = height,
         units = "in", family = font_family, bg = "white")
  ggsave(png_path, p, device = ragg::agg_png, width = width, height = height,
         units = "in", dpi = 320, bg = "white")
}
panel_title <- function(letter, title) paste0(letter, "  ", title)
box_layer <- function(x, y, w, h, label, fill = "#EEF2F4", size = 3.4) {
  list(annotate("rect", xmin = x - w/2, xmax = x + w/2, ymin = y - h/2,
                ymax = y + h/2, fill = fill, colour = "#34424B", linewidth = 0.45),
       annotate("text", x = x, y = y, label = label, family = font_family,
                size = size, lineheight = 1.1))
}
arrow_layer <- function(x, y, xend, yend, colour = "#34424B") {
  annotate("segment", x = x, y = y, xend = xend, yend = yend, colour = colour,
           linewidth = .55, arrow = grid::arrow(length = grid::unit(2.5, "mm")))
}

# DISPLAY Figure5 START
# RAIN is a proposed clinical framework. All visible text is registered as
# aggregate content; no individual records enter this renderer.
rain_content <- read_csv(file.path(input_dir, "Figure_5_RAIN_Content.csv"),
                         show_col_types = FALSE, progress = FALSE, na = character())
stopifnot(identical(names(rain_content), c("stage", "element_id", "heading", "text")),
          !anyDuplicated(rain_content$element_id),
          identical(unique(rain_content$stage), c("R", "A", "I", "N")))
rain_text <- function(id, field = "text") {
  value <- rain_content[[field]][rain_content$element_id == id]
  if (length(value) != 1L || is.na(value)) stop("Missing RAIN content: ", id)
  value
}
rain_connections <- data.frame(
  source = c("R", "A", "I", "N"), target = c("A", "I", "N", "I"),
  kind = c("forward", "forward", "forward", "reassessment"),
  label = c("", "", "", gsub("\n", " ", rain_text("feedback"))),
  stringsAsFactors = FALSE)
rain_framework <- function(family = "Helvetica") {
  ink <- "#173247"; blue <- "#315F7C"; red <- "#A3464A"; teal <- "#2A6A66"
  stroke <- "#CED8DE"; arrow_colour <- "#7D919E"
  # Coordinates are inches, so gutters, radius, and padding remain physical
  # dimensions on both raster and vector devices.
  rounded <- function(x0, x1, y0, y1, fill, border = stroke, radius = .065, lw = .65) {
    annotation_custom(grid::roundrectGrob(
      r = grid::unit(radius, "in"), gp = grid::gpar(fill = fill, col = border, lwd = lw)),
      xmin = x0, xmax = x1, ymin = y0, ymax = y1)
  }
  text_layer <- function(id, x, y, field = "text", size = 4.265,
                         colour = ink, face = "plain", hjust = 0, vjust = .5, lineheight = 1.12) {
    annotate("text", x = x, y = y, label = rain_text(id, field),
             family = family, size = size, colour = colour, fontface = face,
             hjust = hjust, vjust = vjust, lineheight = lineheight)
  }
  badge <- function(id, y, fill) {
    list(annotation_custom(grid::circleGrob(
        gp = grid::gpar(fill = fill, col = NA)), xmin = .19, xmax = .89,
        ymin = y - .35, ymax = y + .35),
      text_layer(id, .54, y - .005, field = "heading", size = 7.86,
                 colour = "white", face = "bold", hjust = .5))
  }
  stage_heading <- function(id, y, colour) text_layer(id, 1.23, y,
                                field = "heading", size = 5.075,
                                colour = colour, face = "bold")
  forward <- function(y0, y1) annotate("segment", x = .54, y = y0,
    xend = .54, yend = y1, colour = arrow_colour, linewidth = .52,
    arrow = grid::arrow(length = grid::unit(.075, "in"), type = "closed"))
  p <- ggplot() +
    # The shared rail establishes a single, unambiguous reading sequence.
    forward(6.54, 6.35) + forward(5.55, 4.30) + forward(3.53, 1.88) +
    # R: compact recognition strip.
    rounded(1.03, 7.18, 6.35, 7.20, "#EEF4F8", "#D4E0E8") +
    badge("r_badge", 6.94, blue) + stage_heading("r_heading", 6.96, blue) +
    text_layer("recognition", 1.23, 6.69, face = "bold") +
    text_layer("recognition_timing", 1.23, 6.47) +
    # A: urgency and competing causes are evaluated alongside one another.
    rounded(1.03, 7.18, 4.37, 6.12, "#FBF1F0", "#E7CDCF") +
    badge("a_badge", 5.95, red) + stage_heading("a_heading", 5.92, red) +
    text_layer("urgent_heading", 1.23, 5.60, field = "heading", face = "bold", colour = red) +
    text_layer("urgent_complications", 1.23, 5.25) +
    annotate("segment", x = 1.23, xend = 6.98, y = 4.94, yend = 4.94,
             linewidth = .33, colour = "#E5C8CA") +
    text_layer("competing_heading", 1.23, 4.75, field = "heading", face = "bold") +
    text_layer("competing_causes", 1.23, 4.52) +
    # I: three balanced evidence cards, with the same interior padding.
    badge("i_badge", 3.90, blue) + stage_heading("i_heading", 3.91, blue) +
    rounded(1.03, 3.003, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    rounded(3.118, 5.092, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    rounded(5.207, 7.18, 1.82, 3.73, "#F0F5F8", "#D0DEE6") +
    text_layer("symptoms", 1.185, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("markers", 3.273, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("imaging", 5.362, 3.59, field = "heading", size = 4.69, face = "bold", vjust = 1) +
    text_layer("symptoms", 1.185, 3.02, vjust = 1) +
    text_layer("markers", 3.273, 3.02, vjust = 1) +
    text_layer("imaging", 5.362, 3.02, vjust = 1) +
    # N: decisions and the three distinct clinical outcomes.
    rounded(1.03, 7.18, .14, 1.66, "#EDF5F3", "#CDDEDA") +
    badge("n_badge", 1.48, teal) + stage_heading("n_heading", 1.45, teal) +
    text_layer("treatment", 1.23, 1.16, face = "bold") +
    text_layer("reassessment_heading", 1.23, .88, field = "heading", colour = teal, face = "bold") +
    rounded(1.23, 3.067, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    rounded(3.186, 5.023, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    rounded(5.142, 6.98, .27, .70, "white", "#CFDFDA", radius = .04, lw = .5) +
    text_layer("symptom_outcome", 2.1485, .495, size = 3.95, hjust = .5) +
    text_layer("local_outcome", 4.1045, .495, size = 3.95, hjust = .5) +
    text_layer("systemic_outcome", 6.061, .495, size = 3.95, hjust = .5) +
    # Dedicated feedback lane: horizontal label, outside every content card.
    annotate("segment", x = 7.18, xend = 8.08, y = 1.45, yend = 1.45,
             colour = teal, linewidth = .58) +
    annotate("segment", x = 8.08, xend = 8.08, y = 1.45, yend = 3.91,
             colour = teal, linewidth = .58) +
    annotate("segment", x = 8.08, xend = 7.24, y = 3.91, yend = 3.91,
             colour = teal, linewidth = .58,
             arrow = grid::arrow(length = grid::unit(.085, "in"), type = "closed")) +
    rounded(7.24, 8.42, 2.32, 3.10, "white", "white", radius = .04, lw = 0) +
    text_layer("feedback", 7.83, 2.71, colour = teal, size = 3.95, face = "bold", hjust = .5) +
    coord_fixed(ratio = 1, xlim = c(0, 8.5), ylim = c(0, 7.45),
                expand = FALSE, clip = "off") +
    theme_void(base_family = family) + theme(plot.margin = margin(0, 0, 0, 0))
  p
}
rain_pdf_path <- file.path(output_dir, "Figures", "Figure_5_Recognition_framework.pdf")
rain_png_path <- file.path(output_dir, "Figures", "Figure_5_Recognition_framework.png")
if (Sys.info()[["sysname"]] == "Darwin") {
  # Named Quartz registration prevents its implicit Arial substitution and
  # embeds true Helvetica subsets; it does not change other figures' families.
  grDevices::quartzFonts(RAINHelvetica = grDevices::quartzFont(c(
    "Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique")))
  rain_pdf_device <- function(filename, width, height, bg, ...) {
    grDevices::quartz(type = "pdf", file = filename, width = width,
                     height = height, family = "RAINHelvetica", bg = bg)
  }
  ggsave(rain_pdf_path, rain_framework("RAINHelvetica"), device = rain_pdf_device,
         width = 8.5, height = 7.45, units = "in", bg = "white")
} else {
  ggsave(rain_pdf_path, rain_framework("Helvetica"), device = grDevices::cairo_pdf,
         width = 8.5, height = 7.45, units = "in", family = "Helvetica", bg = "white")
}
ggsave(rain_png_path, rain_framework("Helvetica"), device = ragg::agg_png,
       width = 8.5, height = 7.45, units = "in", dpi = 600, bg = "white")
save_display_data(rain_content, "Figure_5_RAIN_Content")
save_display_data(rain_connections, "Figure_5_RAIN_Connections")
# DISPLAY Figure5 END
if (framework_only) quit(save = "no", status = 0L)



# DISPLAY Figure2 START
# Only aggregate inputs enter these figures. Recorded and explicitly estimated
# dates enter the numerical summaries; unavailable dates do not.
onset <- read_input("Figure_2_Onset_Bins", c("window", "lower_day", "upper_day", "n", "denominator", "percent"))
timing <- read_input("Figure_2_Timing_Summaries", c("measure", "n", "total_n", "median", "q1", "q3"))
densities <- read_input("Figure_2_Timing_Densities", c("measure", "day", "density", "denominator"))
stopifnot(nrow(onset) == 4L, length(unique(onset$denominator)) == 1L,
          all(onset$denominator > 0), sum(onset$n) == onset$denominator[1],
          all(abs(onset$percent - 100*onset$n/onset$denominator) < 1e-10),
          timing$n[timing$measure == "Onset"] == onset$denominator[1],
          length(unique(timing$total_n)) == 1L, all(timing$n <= timing$total_n),
          all(timing$q1 <= timing$median),
          all(timing$median <= timing$q3))
measure_order <- c("Onset", "Peak", "Symptom resolution")
stopifnot(nrow(densities) == 303L, setequal(unique(densities$measure), measure_order),
          !anyDuplicated(densities[c("measure", "day")]),
          all(is.finite(densities$density)), all(densities$density >= 0),
          all(densities$density < .12), all(densities$denominator > 0))
for (measure_name in measure_order) {
  z <- densities %>% filter(measure == measure_name) %>% arrange(day)
  expected_n <- timing$n[timing$measure == measure_name]
  stopifnot(nrow(z) == 101L, identical(z$day, as.numeric(0:100)),
            all(z$denominator == expected_n))
}
onset <- onset %>% mutate(window = factor(window, levels = window),
                         value_label = sprintf("%d (%.1f%%)", n, percent))
p_a <- ggplot(onset, aes(window, n)) +
  geom_col(fill = "#1B5678", width = .62) +
  geom_text(aes(label = value_label), vjust = -.6, family = font_family, size = 3.35) +
  scale_y_continuous(limits = c(0, 33), breaks = c(0, 10, 20, 30),
                     expand = expansion(mult = c(0, 0))) +
  labs(title = panel_title("A", "Onset timing"),
       x = "Days after first step-up dose", y = "Cases") +
  theme_paper(10) + theme(axis.line.x = element_blank(), axis.ticks.x = element_blank(),
                          axis.text = element_text(size = 9.2),
                          axis.title.y = element_text(margin = margin(r = 6)))
timing <- timing %>% mutate(n_label = paste0(measure, " (n = ", n, ")"),
                           label = sprintf("Median %g days; IQR %g-%g", median, q1, q3))
density_colours <- c(Onset = "#1B5678", Peak = "#9B6A2D", "Symptom resolution" = "#547761")
# Curves are evaluated from the original elapsed times upstream, using a
# Gaussian kernel with bandwidth 5 days and reflection at zero only. The
# renderer consumes aggregate grid values; it never reads individual timings.
# Empirical medians and quartiles come from the separate registered summaries.
density_panels <- lapply(seq_along(measure_order), function(index) {
  measure_name <- measure_order[index]
  z <- densities %>% filter(measure == measure_name) %>% arrange(day)
  s <- timing %>% filter(measure == measure_name)
  colour <- unname(density_colours[measure_name])
  iqr_days <- sort(unique(c(s$q1, z$day[z$day > s$q1 & z$day < s$q3], s$q3)))
  iqr_curve <- data.frame(day = iqr_days, density = approx(z$day, z$density, xout = iqr_days)$y)
  median_height <- approx(z$day, z$density, xout = s$median)$y
  p <- ggplot(z, aes(day, density)) +
    geom_area(fill = colour, alpha = .25) +
    geom_area(data = iqr_curve, fill = colour, alpha = .65) +
    geom_line(colour = colour, linewidth = .45) +
    annotate("segment", x = s$median, xend = s$median, y = 0, yend = median_height,
             colour = colour, linewidth = .6) +
    annotate("text", x = 0, y = .12, label = s$n_label, hjust = 0, vjust = -1,
             family = font_family, size = 3.55, colour = "#222222") +
    annotate("text", x = 100, y = .12, label = s$label, hjust = 1, vjust = -1,
             family = font_family, size = 3.35, colour = "#222222") +
    scale_y_continuous(limits = c(0, .12), breaks = c(0, .04, .08, .12),
                       labels = function(x) sprintf("%.2f", x), expand = expansion(mult = c(0, 0))) +
    scale_x_continuous(limits = c(0, 100), breaks = seq(0, 100, 20),
                       expand = expansion(mult = c(0, 0))) +
    coord_cartesian(clip = "off") +
    labs(x = if (index == 3L) "Days after first step-up dose" else NULL,
         y = if (index == 2L) "Density (per day)" else NULL) +
    theme_paper(10) +
    theme(axis.text = element_text(size = 9.2),
          axis.title.y = element_text(margin = margin(r = 6)),
          plot.margin = margin(17, 10, if (index == 3L) 8 else 3, 8))
  if (index < 3L) p <- p + theme(axis.text.x = element_blank(), axis.ticks.x = element_blank())
  p
})
p_b <- wrap_plots(density_panels, ncol = 1, heights = c(1, 1, 1)) +
  plot_annotation(title = panel_title("B", "Timing distributions"),
                  theme = theme(plot.title = element_text(face = "bold", family = font_family,
                                                         size = 11, hjust = 0, margin = margin(l = 30)),
                                plot.margin = margin(0, 0, 0, 0)))
save_figure(p_a / wrap_elements(full = p_b) + plot_layout(heights = c(1, 1.5)),
            "Figure_2_Aggregate_timing", 7.2, 6.2)
save_display_data(onset %>% select(-value_label), "Figure_2_Onset_Bins")
save_display_data(timing %>% select(measure, n, total_n, median, q1, q3), "Figure_2_Timing_Summaries")
save_display_data(densities %>% select(measure, day, density, denominator), "Figure_2_Timing_Densities")
# DISPLAY Figure2 END

# DISPLAY Figure3 START
status_bars <- function(x, title) {
  stopifnot(all(c("label", "category", "n", "denominator") %in% names(x)))
  x <- x %>% mutate(category = ifelse(is.na(category) | category == "", "Unknown", category))
  if (!all(x$category %in% names(colours))) stop("Unexpected clinical status category")
  labels <- unique(x$label)
  x <- x %>% mutate(label = factor(label, levels = rev(labels)), category = factor(category, levels = names(colours)), proportion = n/denominator)
  yes <- x %>% filter(category == "Yes")
  ggplot(x, aes(proportion, label, fill = category)) + geom_col(width = .64, position = position_stack(reverse = TRUE), colour = "white", linewidth = .25, show.legend = TRUE) +
    geom_text(data = yes, aes(x = 1.02, y = label, label = paste0(n, "/", denominator)), inherit.aes = FALSE,
              hjust = 0, size = 3.0, family = font_family) +
    scale_fill_manual(values = colours, drop = FALSE) +
    scale_x_continuous(labels = scales::label_percent(accuracy = 1), breaks = c(0, .25, .5, .75, 1), expand = expansion(mult = c(0, 0))) +
    coord_cartesian(xlim = c(0, 1.14), clip = "off") +
    labs(title = title, x = "Proportion of tumor flare cases", y = NULL) + theme_paper(9.5) +
    theme(axis.line.y = element_blank(), axis.ticks.y = element_blank())
}
presentation <- read_input("presentation", c("field", "label", "panel", "category", "n", "denominator"))
anatomy <- read_input("anatomy_binary", c("field", "label", "category", "n", "denominator"))
presentation <- presentation %>% mutate(label = case_when(
  field == "flare_hospitalization" ~ "Admission attributed to flare",
  field == "icu_due_to_flare" ~ "ICU care attributed to flare",
  TRUE ~ label))
true_emd <- anatomy %>% filter(field == "true_emd_any")
stopifnot(sum(true_emd$n) == 33,
          all(c("No", "Yes", "Unknown", "Not applicable") %in% true_emd$category),
          true_emd$n[true_emd$category == "Unknown"] == 6,
          true_emd$n[true_emd$category == "Not applicable"] == 1)
manifest <- presentation %>% filter(field %in% c("pain_flare", "palpable_enlargement", "imaging_worsening", "new_lesion", "neurologic_cns", "biochemical_or_organ"))
impact <- presentation %>% filter(field %in% c("organ_dysfunction", "flare_hospitalization", "neurologic_deficit", "pathologic_fracture", "cord_compression", "icu_due_to_flare"))
site <- anatomy %>% filter(field %in% c("true_emd_any", "paraskeletal_involvement", "spinal_involvement", "cns_involvement"))
save_figure((status_bars(manifest, panel_title("A", "Clinical manifestations")) /
             status_bars(impact, panel_title("B", "Clinical impact")) /
             status_bars(site, panel_title("C", "Anatomical involvement during flare"))) + plot_layout(guides = "collect") & theme(legend.position = "bottom"),
            "Figure_3_Clinical_spectrum", 9.5, 10)
save_display_data(bind_rows(manifest, impact, site), "Figure_3")
# DISPLAY Figure3 END

# DISPLAY Figure4 START
forest <- function(x, title, metric, x_limits = NULL, x_breaks = NULL) {
  stopifnot(all(c("label", "estimate", "conf_low", "conf_high", "n_courses", "candidates") %in% names(x)))
  x <- x %>% mutate(row = rev(row_number()))
  if (is.null(x_limits)) {
    rng <- range(c(x$conf_low, x$conf_high, 1), na.rm = TRUE)
    rng <- c(max(.01, rng[1] * .8), rng[2] * 1.2)
  } else {
    rng <- x_limits
    stopifnot(length(rng) == 2L, all(is.finite(rng)), 0 < rng[1], rng[1] < rng[2],
              all(x$conf_low >= rng[1]), all(x$conf_high <= rng[2]))
  }
  # Keep analytical labels unchanged; use the clinical threshold glyph in the figure.
  x <- x %>% mutate(display_label = gsub(">=", "\u2265", label, fixed = TRUE))
  labels <- ggplot(x, aes(y = row)) + geom_text(aes(x = 0, label = display_label), hjust = 0, family = font_family, size = 3.0) +
    coord_cartesian(xlim = c(0, 1), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  values <- x %>% mutate(value = ifelse(is.finite(estimate), sprintf("%.2f (%.2f-%.2f)", estimate, conf_low, conf_high), "Not estimated"),
    population = paste0("N=", format(n_courses, big.mark = ","), "; flare=", candidates))
  right <- ggplot(values, aes(y = row)) + geom_text(aes(x = 0, label = value), hjust = 0, family = font_family, size = 3.0) +
    geom_text(aes(x = .60, label = population), hjust = 0, family = font_family, size = 2.75) +
    coord_cartesian(xlim = c(0, 1.35), ylim = c(.35, nrow(x) + .65), clip = "off") + theme_void() + theme(plot.margin = margin(4, 2, 4, 2))
  x_scale <- if (is.null(x_breaks)) scale_x_log10(limits = rng) else
    scale_x_log10(limits = rng, breaks = x_breaks,
      labels = function(value) vapply(value, function(v) format(v, scientific = FALSE, trim = TRUE), character(1)),
      expand = expansion(mult = c(0, 0)))
  center <- ggplot(x, aes(estimate, row)) + geom_vline(xintercept = 1, linetype = "dashed", colour = "#89949C", linewidth = .4) +
    geom_errorbar(aes(xmin = conf_low, xmax = conf_high), orientation = "y", width = .12, linewidth = .55, na.rm = TRUE) +
    geom_point(size = 2.1, colour = "#1B5678", na.rm = TRUE) + x_scale +
    coord_cartesian(ylim = c(.35, nrow(x) + .65)) + labs(x = paste0(metric, " (95% CI)"), y = NULL) + theme_paper(8.5) +
    theme(axis.text.y = element_blank(), axis.ticks.y = element_blank(), axis.line.y = element_blank(),
          plot.margin = margin(4, 4, 4, 4))
  (labels + center + right + plot_layout(widths = c(1.05, 1.0, 1.55))) +
    plot_annotation(title = title, theme = theme(plot.title = element_text(family = font_family, face = "bold", size = 11)))
}
models <- read_input("models", c("scenario", "family", "label", "estimate", "conf_low", "conf_high", "n_courses", "candidates"))
survival <- read_input("survival_models", c("scenario", "model", "endpoint", "estimate", "conf_low", "conf_high", "n_courses", "exposed_courses"))
baseline <- models %>% filter(scenario == "primary", family == "Baseline")
responses <- models %>% filter(scenario == "primary", family == "Response", !is.na(adjustment), adjustment != "")
surv_primary <- survival %>% filter(scenario == "primary", grepl("Adjusted", model)) %>%
  mutate(label = endpoint, candidates = exposed_courses)
if (nrow(baseline) != 6L || nrow(responses) != 3L || nrow(surv_primary) != 2L) stop("Figure4 model selection is not 6 baseline/3 response/2 survival models")
shared_or_limits <- c(0.1, 10)
shared_or_breaks <- c(0.1, 0.3, 1, 3, 10)
save_figure(wrap_plots(list(
              wrap_elements(full = forest(baseline, panel_title("A", "Baseline associations with tumor flare"), "OR", shared_or_limits, shared_or_breaks)),
              wrap_elements(full = forest(responses, panel_title("B", "Adjusted best-response associations"), "OR", shared_or_limits, shared_or_breaks)),
              wrap_elements(full = forest(surv_primary, panel_title("C", "Adjusted time-dependent survival associations"), "HR"))),
              ncol = 1, heights = c(6, 3.3, 2.6)), "Figure_4_Association_models", 12, 9)
save_display_data(bind_rows(baseline, responses, surv_primary) %>% select(any_of(c("scenario", "family", "model", "label", "endpoint", "estimate", "conf_low", "conf_high", "p_value", "n_courses", "n_patient_clusters", "candidates", "events", "adjustment", "bootstrap_successes", "bootstrap_requested", "model_status"))), "Figure_4")
# DISPLAY Figure4 END

# DISPLAY FigureS1 START
km <- read_input("landmark_km_steps", c("endpoint", "landmark_day", "group", "time", "survival", "lower", "upper"))
risk <- read_input("landmark_risk_counts", c("endpoint", "landmark_day", "group", "time", "n_risk"))
group_label <- function(x) ifelse(as.character(x) == "0", "No flare by landmark", ifelse(as.character(x) == "1", "Flare by landmark", as.character(x)))
km <- km %>% mutate(group = group_label(group))
risk <- risk %>% mutate(group = group_label(group))
group_colours <- c("No flare by landmark" = "#65747E", "Flare by landmark" = "#1B5678")
landmark_panel <- function(endpoint_value, day_value, letter) {
  x <- km %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  r <- risk %>% filter(endpoint == endpoint_value, landmark_day == day_value)
  stopifnot(nrow(x) > 0, nrow(r) > 0)
  xmax <- max(r$time)
  x <- x %>% arrange(group, time)
  step_band <- x %>% group_by(group) %>% mutate(next_time = lead(time)) %>% ungroup()
  step_band <- bind_rows(step_band %>% mutate(order = 1), step_band %>% filter(is.finite(next_time)) %>% mutate(time = next_time, order = 0)) %>% arrange(group, time, order)
  # Canonical landmark KM and risk-count time fields are elapsed months.
  p <- ggplot(x, aes(time, survival, colour = group, fill = group)) +
    geom_ribbon(data = step_band, aes(ymin = lower, ymax = upper), alpha = .12, colour = NA) + geom_step(linewidth = .65) +
    scale_colour_manual(values = group_colours) + scale_fill_manual(values = group_colours) +
    scale_y_continuous(limits = c(0, 1), labels = scales::label_percent(accuracy = 1)) +
    scale_x_continuous(breaks = sort(unique(r$time)), labels = scales::label_number(accuracy = 1)) + coord_cartesian(xlim = c(0, xmax)) +
    labs(title = panel_title(letter, paste0(endpoint_value, " at day ", day_value)), x = "Months after landmark", y = paste0(endpoint_value, " probability")) +
    theme_paper(9) + theme(legend.position = "bottom")
  groups <- c("Flare by landmark", "No flare by landmark")
  r <- r %>% mutate(row = match(group, rev(groups)))
  rt <- ggplot(r, aes(time, row, label = n_risk, colour = group)) + geom_text(family = font_family, size = 2.7) +
    scale_colour_manual(values = group_colours) + scale_x_continuous(breaks = sort(unique(r$time))) +
    scale_y_continuous(breaks = 1:2, labels = rev(groups)) + coord_cartesian(xlim = c(0, xmax), ylim = c(.4, 2.6), clip = "off") +
    labs(x = NULL, y = NULL, title = "Number at risk") + theme_void(base_family = font_family) +
    theme(axis.text.y = element_text(size = 7, hjust = 1), plot.title = element_text(size = 8.5, hjust = 0),
          plot.margin = margin(3, 10, 3, 8), legend.position = "none")
  p / rt + plot_layout(heights = c(4.2, 1))
}
save_figure(wrap_plots(list(
              wrap_elements(full = landmark_panel("PFS", 30, "A")),
              wrap_elements(full = landmark_panel("OS", 30, "B")),
              wrap_elements(full = landmark_panel("PFS", 60, "C")),
              wrap_elements(full = landmark_panel("OS", 60, "D"))), ncol = 2, nrow = 2),
            "Figure_S1_Landmark_survival", 12, 9.5)
save_display_data(km, "Figure_S1_KM")
save_display_data(risk, "Figure_S1_Risk")
# DISPLAY FigureS1 END
cat("Publication figures exported from", normalizePath(input_dir), "\n")
