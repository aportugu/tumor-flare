"""Synthetic checks of main-table denominators, category handling, and replay."""
import unittest
from compact_main_tables import compact_table, display, count

def fixture(rows):
    table={'label':'Table 2','caption':'Interventions may overlap. Assessments are separate.',
        'title':'Synthetic table','panels':[],'aggregate_files':[],'code_files':[]}
    item={'filename':'Table_2.csv','columns':['Characteristic','All','Definite/Probable','Possible'],
          'rows':rows}
    return table,item

def value(n,N):return f'{n}/{N} (0.0%)'  # Rounded inputs are deliberately uninformative.

class CompactTests(unittest.TestCase):
    def test_binary_missing_denominators(self):
        table,item=fixture([['Intervention','','',''],['  No',value(1,6),value(1,4),value(0,2)],
          ['  Yes',value(2,6),value(2,4),value(0,2)],['  Blank',value(1,6),value(1,4),value(0,2)],
          ['  Unknown',value(1,6),value(0,4),value(1,2)],['  Not applicable',value(1,6),value(0,4),value(1,2)]])
        out,registration=compact_table(table,item)
        rows=out['panels'][0]['rows']
        self.assertEqual(rows[0]['cells'],['Intervention','2 (66.7%)','2 (66.7%)','—'])
        self.assertEqual([r['cells'][0] for r in rows],['Intervention','Not applicable'])
        self.assertEqual(rows[-1]['cells'][1:],['1','0','1'])
        self.assertNotIn('No',[r['cells'][0] for r in rows])
        self.assertTrue(any(r[2]=='No' and r[7] is False for r in registration['rows']))

    def test_response_and_local_unknown(self):
        labels=['Unknown','PD','CR','Not applicable','NE','PR','Not reassessed','Blank','VGPR','MR','SD']
        rows=[['First postflare systemic assessment','','','']]
        rows += [['  '+label,*[value(1,11),value(1,11),value(1,11)]] for label in labels]
        out,registration=compact_table(*fixture(rows))
        expected=['First postflare systemic assessment','CR','VGPR','PR','MR','SD','PD','Not applicable']
        self.assertEqual([r['cells'][0] for r in out['panels'][0]['rows']],expected)
        self.assertEqual(out['panels'][0]['rows'][1]['cells'][1],'1 (16.7%)')
        unknown = [r for r in registration['rows'] if r[2]=='Unknown']
        self.assertEqual(len(unknown),3)
        self.assertTrue(all(r[4]==4 and r[7] is False for r in unknown))
        self.assertEqual({r[5] for r in registration['rows']},{6})

    def test_continuous_precision_and_zero_missing_rows(self):
        table,item=fixture([['Age','','',''],['  Median (IQR)','60.0 (50.2, 70.0); available n=2',
            '61.0 (51.0, 71.0); available n=2','62.0 (52.0, 72.0); available n=2'],
            ['  Blank',value(0,2),value(0,2),value(0,2)]])
        out,_=compact_table(table,item)
        self.assertEqual(len(out['panels'][0]['rows']),1)
        self.assertEqual(out['panels'][0]['rows'][0]['cells'][1],'60.0 (50.2, 70.0)')

    def test_reject_nonconserving_counts(self):
        with self.assertRaises(ValueError):compact_table(*fixture([['Test','','',''],
            ['  Yes',value(2,5),value(2,5),value(2,5)],['  No',value(2,5),value(2,5),value(2,5)]]))

    def test_rounding_and_malformed_input(self):
        self.assertEqual(display(21,31),'21 (67.7%)')
        self.assertEqual(display(0,2),'0 (0.0%)')
        self.assertEqual(display(1,16),'1 (6.3%)')
        with self.assertRaises(ValueError):count('50%')

if __name__=='__main__':unittest.main()
