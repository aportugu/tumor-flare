#!/usr/bin/env Rscript
args<-commandArgs(trailingOnly=TRUE)
root<-if(length(args))args[1]else "."
runtime<-Sys.getenv("TF_R_LIBRARY","")
if(nzchar(runtime)).libPaths(c(normalizePath(runtime,mustWork=TRUE),.libPaths()))
source(file.path(root,"Code/model_functions.R"))
checks<-0L
check<-function(value){stopifnot(isTRUE(value));checks<<-checks+1L}
close<-function(a,b) isTRUE(all.equal(unname(a),unname(b),tolerance=1e-9))
d<-data.frame(y=c(rep(0,20),rep(1,20)),v=c(rep(0,20),rep(1,20)))
f<-tf_ash_firth_fit(d,"y","v","v")
ref<-logistf::logistf(y~v,data=d,pl=TRUE,plconf=2,control=logistf::logistf.control(
  maxit=200,lconv=1e-7,gconv=1e-7,xconv=1e-7),plcontrol=logistf::logistpl.control(maxit=200,lconv=1e-7,xconv=1e-7))
check(f$converged&&f$inference_available)
check(close(f$coefficient,ref$coefficients["v"]))
check(close(f$log_ci_low,ref$ci.lower["v"]))
check(close(f$log_ci_high,ref$ci.upper["v"]))
check(close(f$p_value,ref$prob["v"]))
check(close(f$p_value,logistf::logistftest(ref,test=2)$prob))
check(close(f$p_value,pchisq(f$plr_statistic,1,lower.tail=FALSE)))
check(f$log_ci_low<f$coefficient&&f$coefficient<f$log_ci_high)
check(abs((f$coefficient-f$log_ci_low)-(f$log_ci_high-f$coefficient))>.5)
check(!f$retry_used&&f$attempts==1L)
retry<-tf_ash_firth_fit(d,"y","v","v",initial_maxit=1L,retry_maxit=200L)
check(retry$retry_used&&retry$attempts==2L&&retry$inference_available)
check(close(retry$coefficient,f$coefficient)&&close(retry$p_value,f$p_value))
failed<-tf_ash_firth_fit(d,"y","v","v",initial_maxit=1L,retry_maxit=1L)
check(!failed$converged&&!failed$inference_available&&is.na(failed$p_value))
no_y<-d;no_y$y<-0L
check(!tf_ash_firth_fit(no_y,"y","v","v")$inference_available)
no_x<-d;no_x$v<-0L
check(!tf_ash_firth_fit(no_x,"y","v","v")$inference_available)
d$course_id<-paste0("S",seq_len(nrow(d)));d$patient_cluster_id<-rep(paste0("P",1:20),each=2)
d$flare<-d$y;d$v[1]<-NA
m<-tf_ash_firth_profile(d,"y","v","v","Synthetic","Baseline","primary","synthetic",progress=FALSE)
check(m$table$n_courses==39&&m$table$n_patient_clusters==20&&m$table$excluded_missing==1)
check(!m$membership$included[1]&&all(m$membership$included[-1]))
check(m$membership$exclusion_reason[1]=="v")
check(m$table$inference_method=="Firth profile penalized likelihood")
check(!any(grepl("bootstrap|seed|draw",names(m$table))))
check(m$table$point_converged&&m$table$profile_converged&&m$table$plr_converged)
check(close(log(m$table$conf_low),m$table$log_ci_low))
# Adjusted reference and coefficient-specific restricted LR testing.
e<-data.frame(y=rep(c(0,0,1,1,0,1,1,1),10),v=rep(c(0,0,0,0,1,1,1,1),10),age=rep(seq(-2,2,length.out=8),10))
a<-tf_ash_firth_fit(e,"y",c("v","age"),"v")
b<-logistf::logistf(y~v+age,data=e,pl=TRUE,plconf=2,control=logistf::logistf.control(maxit=200,lconv=1e-7,gconv=1e-7,xconv=1e-7),plcontrol=logistf::logistpl.control(maxit=200,lconv=1e-7,xconv=1e-7))
check(a$inference_available&&close(a$coefficient,b$coefficients["v"]))
check(close(a$log_ci_low,b$ci.lower["v"])&&close(a$log_ci_high,b$ci.upper["v"]))
check(close(a$p_value,logistf::logistftest(b,test=2)$prob))
# A failed profile must never fall back to a model-based Wald interval or P value.
original<-tf_ash_firth_attempt
assign("tf_ash_firth_attempt",function(...){x<-original(...);x$profile_converged<-FALSE;
  x$inference_available<-FALSE;x$log_ci_low<-x$log_ci_high<-x$p_value<-NA_real_;x},envir=.GlobalEnv)
limited<-tf_ash_firth_fit(e,"y",c("v","age"),"v")
check(limited$converged&&!limited$inference_available&&is.na(limited$log_ci_low)&&is.na(limited$p_value))
assign("tf_ash_firth_attempt",original,envir=.GlobalEnv)
# Invalid inference outputs suppress CI and P immediately; iterations cannot fix them.
fixture<-data.frame(y=rep(0:1,each=20),v=rep(0:1,each=20))
base<-f$fit;restricted<-f$restricted_fit
invalid_cases<-list()
bad<-base;bad$method.ci[2]<-"Wald";invalid_cases$method<-bad
bad<-base;bad$prob["v"]<-1.1;invalid_cases$p_value<-bad
bad<-base;bad$ci.lower["v"]<-base$ci.upper["v"];bad$ci.upper["v"]<-base$ci.lower["v"];invalid_cases$order<-bad
bad<-base;bad$ci.upper["v"]<-1000;invalid_cases$overflow<-bad
bad<-base;bad$pl.iter<-matrix(0,1,3);invalid_cases$malformed_diagnostics<-bad
for(case in names(invalid_cases)) {
  assessed<-tf_ash_firth_assess(invalid_cases[[case]],restricted,"v",2L,200L)
  check(assessed$converged&&!assessed$inference_available&&!assessed$retry_eligible)
  calls<-0L
  assign("tf_ash_firth_attempt",function(...){calls<<-calls+1L;assessed},envir=.GlobalEnv)
  result<-tf_ash_firth_fit(fixture,"y","v","v")
  check(calls==1L&&result$attempts==1L&&!result$retry_used)
  check(close(result$coefficient,f$coefficient)&&is.na(result$log_ci_low)&&is.na(result$log_ci_high)&&is.na(result$p_value))
}
assign("tf_ash_firth_attempt",original,envir=.GlobalEnv)
structural<-tf_ash_firth_assess(NULL,NULL,"v",2L,200L,failure="Singular model matrix")
check(!structural$converged&&!structural$retry_eligible)
restricted_invalid<-tf_ash_firth_assess(base,NULL,"v",2L,200L,restricted_failure="Singular restricted matrix")
check(restricted_invalid$converged&&!restricted_invalid$inference_available&&!restricted_invalid$retry_eligible)
# A finite, correctly formed profile that has not reached tolerance is retryable.
nonconverged<-base;nonconverged$pl.conv[1,"upper, beta"]<-1e-3
check(tf_ash_firth_assess(nonconverged,restricted,"v",2L,200L)$retry_eligible)
nonconverged<-base;nonconverged$pl.iter[2,"Upper"]<-200L
check(tf_ash_firth_assess(nonconverged,restricted,"v",2L,200L)$retry_eligible)
# Invalid output must block retry even if an iteration failure occurs concurrently.
bad<-base;bad$prob["v"]<-1.1;bad$pl.iter[2,"Upper"]<-200L
check(!tf_ash_firth_assess(bad,restricted,"v",2L,200L)$retry_eligible)
# The diagnostic output contract includes the explicitly named Firth export.
source(file.path(root,"Code/summary_functions.R"))
output<-tempfile("firth-diagnostics-export-");dir.create(output)
tf_export_firth_diagnostics(m$diagnostics,output)
check(file.exists(file.path(output,"firth_diagnostics.csv")))
exported<-read.csv(file.path(output,"firth_diagnostics.csv"),stringsAsFactors=FALSE)
check(isTRUE(all.equal(exported,m$diagnostics,check.attributes=FALSE,tolerance=1e-12)))
unlink(output,recursive=TRUE)
cat(checks,"Firth profile, penalized LR, separation, missingness, convergence-only retry and named diagnostic export checks passed\n")
