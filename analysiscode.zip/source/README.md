# Tumor flare analysis code

This archive contains executable analysis and display code, the input dictionary, dependency specifications, model-specific seeds, file hashes, and synthetic fixtures. Clinical study records and patient-level derived data are excluded. All files in `Demo/` are invented test data, as described in `Demo/SYNTHETIC.txt`.

The clinical assessments replace discordant earlier values before cohort construction. Blank and Unknown assessments remain unavailable. Responses after another treatment cannot improve the response attributed to the original bispecific antibody course. Symptom recovery, local-lesion outcomes, systemic response, and survival follow-up are analyzed separately.

## Recreate the aggregate supplement

The paired self-contained HTML contains the published aggregate presentation manifest and figure inputs. Extract them, then rebuild the HTML from this source directory:

```sh
python3 Publication/extract_aggregate_inputs.py SUPPLEMENT.html aggregate_inputs
python3 Publication/build_publication.py aggregate_inputs/publication_manifest.json reproduced.html --archive-link analysiscode.zip
Rscript --no-restore Publication/build_figures_Figure1_Total_Cohort_Sankey.R aggregate_inputs reproduced_figures --figure1-only
Rscript --no-restore Publication/build_figures.R aggregate_inputs reproduced_figures
```

The manifest contains Tables 1–2 and S1–S4, captions, and all six figure images. The extractor writes only the selected aggregate CSV inputs and presentation manifest. The figure renderers use these aggregate inputs; they do not accept individual clinical display records. No clinical input files or rendered study images are included in this ZIP.

The clinical display selections are recorded in `Publication/clinical_presentation_selection.json` and applied by `Publication/streamline_publication_manifest.py`. They select existing aggregate results without refitting models. The paired HTML includes the aggregate data downloads associated with each displayed table and figure.

## Synthetic execution

Install the versions recorded in `renv.lock`, or select a compatible R library with `TF_R_LIBRARY`. Run:

```sh
Rscript --no-restore Code/run_analysis.R Demo demo_results 20
python3 Publication/test_publication.py
python3 Publication/test_streamline_publication_manifest.py
python3 Publication/test_aggregate_clinical_displays.py
python3 Code/Figure1_Total_Cohort_Sankey/test_extraction.py --output-dir extraction_checks
Rscript --no-restore Code/Figure1_Total_Cohort_Sankey/test_figure1_total_cohort_sankey.R Publication/build_figures_Figure1_Total_Cohort_Sankey.R sankey_checks.csv
Rscript --no-restore Code/Drafting/reverse_km_global_os_followup.R Demo/global_os_endpoint_audit_synthetic.csv followup_checks
python3 Code/Drafting/verify_reverse_km_independently.py Demo/global_os_endpoint_audit_synthetic.csv followup_checks
```

The 20-draw demonstration checks execution and does not reproduce study estimates. Logistic inference in the study requested 1,000 patient bootstrap draws per model and required at least 900 successful draws. Each sampled patient contributes all eligible courses. Seeds are recorded in `Code/model_seed_manifest.csv`.

## Reanalyze the clinical cohort

With approved access to controlled clinical inputs, run:

```sh
Rscript --no-restore Code/run_analysis.R INPUT_DIRECTORY OUTPUT_DIRECTORY 1000
python3 Publication/aggregate_clinical_displays.py OUTPUT_DIRECTORY AGGREGATE_DIRECTORY
```

The analytical pipeline produces private reconciliation, provenance, and model-membership files for verification. These files must stay within the controlled study environment. The publication layer accepts aggregate inputs only. Packaging uses the explicit `archive_allowlist.json`; clinical records, analysis outputs, audit exports, figures, and correspondence cannot enter the archive through directory-wide inclusion.
