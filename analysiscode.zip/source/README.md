# Tumor flare during bispecific antibody therapy for multiple myeloma: a multicenter study

Analysis code

This archive contains executable analysis and display code, the input dictionary, dependency specifications, model-inference specifications, file hashes, and synthetic fixtures. Clinical study records and patient-level derived data are excluded. All files in `Demo/` are invented test data, as described in `Demo/SYNTHETIC.txt`.

The clinical assessments replace discordant earlier values before cohort construction. Blank and Unknown assessments remain unavailable. Recorded and estimated dates enter timing analyses; other missing dates remain unavailable. Responses after another treatment cannot improve the response attributed to the original bispecific antibody course. Symptom recovery, local-lesion outcomes, systemic response, and survival follow-up are analyzed separately.

## Recreate the aggregate supplement

The paired self-contained HTML contains the published aggregate presentation manifest and figure inputs. Extract them, then rebuild the HTML from this source directory:

```sh
python3 Publication/extract_aggregate_inputs.py SUPPLEMENT.html aggregate_inputs
python3 Publication/compact_main_tables.py aggregate_inputs/publication_manifest.json compact_manifest.json --aggregate-directory compact_tables
Rscript --no-restore Publication/calculate_flare_frequency.R aggregate_inputs/flow.csv recalculated_frequency.csv
python3 Publication/build_publication.py aggregate_inputs/publication_manifest.json reproduced.html --archive-link analysiscode.zip
Rscript --no-restore Publication/build_figures_Figure1_Total_Cohort_Sankey.R aggregate_inputs reproduced_figures --figure1-only
Rscript --no-restore Publication/build_figures.R aggregate_inputs reproduced_figures
Rscript --no-restore Publication/plot_smith_zee.R aggregate_inputs/Figure_S1_Smith_Zee_Predictions.csv reproduced_figures
Rscript --no-restore Publication/plot_survival_sensitivity.R aggregate_inputs/Figure_S3_Survival_Sensitivity.csv reproduced_figures
```

The manifest contains Tables 1–2 and S1–S5, captions, and all eight figures. The extractor writes only the selected aggregate CSV inputs and presentation manifest. The figure renderers use these aggregate inputs; they do not accept individual clinical display records. No clinical input files or rendered study images are included in this ZIP.

The clinical display selections are recorded in `Publication/clinical_presentation_selection.json` and applied by `Publication/streamline_publication_manifest.py`. They select existing aggregate results without refitting models. The HTML embeds the aggregate inputs needed to reproduce its tables and figures. Figure S1 provides direct downloads of the figure PDF and the aggregate prediction CSV.

Tables 1 and 2 use `Publication/compact_main_tables.py` to read the original registered aggregate counts and produce their compact views. Group totals appear in column headers; clinical percentages exclude Unknown and Not applicable, which are shown as counts only. Blank and unavailable assessment labels are combined as Unknown for display. Original categories remain unchanged in the analytical records and original aggregate inputs. The two presentation registrations record exact counts, evaluable denominators, original category labels, and whether a row is displayed. Running the compact-table command on an extracted current manifest reproduces its main tables without changing other displays or fitting models.

The overall observed flare frequency divides the secondary-review case count by all treatment courses in `flow.csv`. Base R `binom.test` calculates its exact 95% binomial interval. This course-based interval does not account for repeated courses within patients. The Figure 1 renderer recalculates and verifies the registered frequency before drawing the unchanged cohort flow.

Figure 5 presents RAIN (Recognize, Assess, Integrate, Next steps), a proposed clinical framework. Its text is registered in `Figure_5_RAIN_Content.csv`; the presentation manifest records the forward connections and the repeat-assessment loop. `Publication/build_figures.R` reads this conceptual content and renders the vector figure. The publication caption is supplied by the Figure 5 registration in `Publication/clinical_presentation_selection.json` and applied by the presentation assembly code. The framework has not undergone formal consensus development or diagnostic validation. Its content describes clinical assessment rather than patient pathways or analytical estimates.

Figure S1 shows model-based PFS and OS under two hypothetical flare histories. The downloadable prediction CSV contains the time grid, model-based survival estimates, and model-based pointwise confidence limits used by `Publication/plot_smith_zee.R`. The CSV gives model predictions at two-day intervals, the original weekly checkpoints, and the display endpoint. The renderer draws those steps from the CSV alone, at 6.5 inches wide. It creates a vector PDF and uses Poppler (pdftocairo) for the outlined SVG and the 600 dpi PNG fallback. `Code/landmark_smith_zee.R` defines the prediction under both time-dependent exposure histories and the adjusted landmark analyses. `Code/run_landmark_smith_zee.R` runs those analyses with controlled access, including the support checks and private verification outputs. Table S5 reports the adjusted day-30 and day-60 landmark results. The landmark models compare post-landmark outcomes by flare status at that day. The curves summarize the primary time-dependent models from the first step-up dose for the same fixed baseline profile in both histories. The caption identifies that profile, and the display registry specifies the Cox prediction method and log-scale confidence intervals.

Figure S2 shows best documented response to the index bispecific antibody by
investigator confidence. The clinical display exporter groups the reconciled
cases and checks their response categories against Table 2. The HTML embeds
`Figure_S2_Response_by_Confidence.csv` so the figure builder can generate the
plot with aggregate counts alone. Percentages use all cases in each confidence
group. The SD, PD, or NA category includes stable disease, progressive disease,
unknown or unevaluable response, and minimal response. The figure builder
exports a vector PDF and a 300 dpi PNG at 6.5 inches wide.

To register a regenerated Figure S2 in an existing selected publication manifest,
run the figure builder first and pass its PNG along with the extracted aggregate:

```sh
python3 Publication/streamline_publication_manifest.py aggregate_inputs/publication_manifest.json registered \
  --figure-s2-aggregate aggregate_inputs/Figure_S2_Response_by_Confidence.csv \
  --figure-s2-png reproduced_figures/Figures/Figure_S2_Best_Systemic_Response_by_Flare_Confidence.png
python3 Publication/build_publication.py registered/aggregate_publication_manifest.json reproduced.html
```

Figure S3 shows five adjusted survival estimates per endpoint from Table S5. The plot uses the downloaded aggregate CSV. To recreate the CSV from the extracted source exports, run the selector below. The R renderer exports a vector PDF and uses Poppler (pdftocairo) to create an outlined SVG and a 600 dpi PNG fallback.

```sh
python3 Publication/select_survival_sensitivity.py aggregate_inputs Figure_S3_Survival_Sensitivity.csv
```

## Synthetic execution

Install the versions recorded in `renv.lock`, or select a compatible R library with `TF_R_LIBRARY`. Run:

```sh
Rscript --no-restore Code/run_analysis.R Demo demo_results
python3 Publication/test_publication.py
python3 Publication/test_streamline_publication_manifest.py
python3 Publication/test_aggregate_clinical_displays.py
python3 Publication/test_compact_main_tables.py
Rscript --no-restore Publication/test_flare_frequency.R
python3 Code/Figure1_Total_Cohort_Sankey/test_extraction.py --output-dir extraction_checks
Rscript --no-restore Code/Figure1_Total_Cohort_Sankey/test_figure1_total_cohort_sankey.R Publication/build_figures_Figure1_Total_Cohort_Sankey.R sankey_checks.csv
Rscript --no-restore Code/Drafting/reverse_km_global_os_followup.R Demo/global_os_endpoint_audit_synthetic.csv followup_checks
python3 Code/Drafting/verify_reverse_km_independently.py Demo/global_os_endpoint_audit_synthetic.csv followup_checks
```

The synthetic demonstration checks execution and does not reproduce study estimates. Logistic models use Firth bias-reduced point estimates, 95% profile penalized-likelihood confidence intervals, and two-sided penalized likelihood-ratio P values for the coefficient of interest. All eligible treatment courses are included and treated as independent; logistic inference does not adjust for repeated courses within patients. Point fitting, profile limits, and the constrained null fit must converge. The pipeline retries a convergence failure once with a larger iteration limit. Structural or invalid inference results are suppressed without a retry, and unavailable inference is never replaced by Wald or another method.

Additional synthetic validation commands are:

```sh
Rscript --vanilla Code/test_firth_profile.R .
Rscript --vanilla Code/test_landmark_smith_zee.R
Rscript --vanilla Publication/test_table_s3_immune.R .
python3 Publication/test_firth_profile_publication.py
```


## Reanalyze the clinical cohort

With approved access to controlled clinical inputs, run:

```sh
Rscript --no-restore Code/run_analysis.R INPUT_DIRECTORY OUTPUT_DIRECTORY
python3 Publication/aggregate_clinical_displays.py OUTPUT_DIRECTORY AGGREGATE_DIRECTORY
```

The analytical pipeline produces private reconciliation, provenance, and model-membership files for verification. These files must stay within the controlled study environment. The publication layer accepts aggregate inputs only. Packaging uses the explicit `archive_allowlist.json`; clinical records, analysis outputs, audit exports, figures, and correspondence cannot enter the archive through directory-wide inclusion.


## Supplementary tables

Table S1 summarizes clinical characteristics. Table S2 reports baseline
associations with tumor flare. Table S3 reports associations between tumor
flare and systemic response. Table S4 gives comparative response and immune
toxicity results. Table S5 reports survival analyses, with proportional-hazards
notes for the time-dependent models.

To split the association models in an earlier selected manifest, run:

```sh
python3 Publication/streamline_publication_manifest.py aggregate_inputs/publication_manifest.json registered \
  --split-association-tables
python3 Publication/build_publication.py registered/aggregate_publication_manifest.json reproduced.html
```

The transformation runs after model and diagnostics registration. It preserves
estimates and denominators and writes one display CSV per numbered table.


## Figure 3 presentation categories

Figure 3 combines Not applicable with Unknown before plotting, using a dedicated Figure_3_Statuses.csv aggregate. Yes and No counts and the full denominator of 33 are preserved. The grouping is idempotent and is limited to this figure; original clinical categories, shared inputs, and table categories are unchanged. The registration and renderer use the same Yes, No, Unknown categories.


## Table S3 immune associations

Panel B uses three unadjusted Firth models with flare as the predictor and CRS, ICANS, or treatment tocilizumab as the outcome. Odds ratios have 95% profile penalized-likelihood confidence intervals and two-sided penalized likelihood-ratio P values. Courses are treated as independent; inference does not adjust for repeated treatment courses within patients. These exploratory associations do not establish temporal order or causation.

To fit these models with authorized restricted course data, run `Rscript --vanilla Publication/calculate_table_s3_immune.R canonical_courses_restricted.csv new-output-directory`. Select compatible dependencies with TF_R_LIBRARY when needed. Clinical records, fitted objects, caches, and model membership remain private. The public aggregate registration includes event counts, denominators, coefficients, profile bounds, full and constrained-null penalized log likelihoods, likelihood-ratio statistics, confidence intervals, P values, and convergence diagnostics. The presentation validates exponentiation of the registered profile bounds and the one-degree-of-freedom penalized likelihood-ratio P value; it does not reconstruct profile confidence limits from standard errors or marginal counts.

## Firth inference registration

The `tumor-flare-firth-profile-inference-v1` contract identifies the confidence level, interval and test methods, and independent observation unit. The generic `register_firth_profile_models` function in `Publication/streamline_publication_manifest.py` accepts the current manifest, a full-precision `models.csv` aggregate object, and the registered inference configuration. It validates unchanged existing model definitions, point estimates and populations, registers the new inference, and updates Table S2 and the Figure 4 caption. The immune registration uses the same statistical contract. `register_table_s3_immune` accepts the corresponding three aggregate model rows. The final manifest embeds all 51 core logistic models and three immune models, while displayed selections follow the manuscript. The paired HTML and source archive reproduce the registered displays in a clean session.

Updated November 18, 2026.


## Diagnostic exports

The clinical and synthetic core pipelines explicitly export `firth_diagnostics.csv` with one row per core Firth model. The separate immune entry point exports the same named diagnostic file for its three models. `model_diagnostics.csv` is kept as an identical compatibility alias. Diagnostic rows contain model identifiers and aggregate convergence/inference checks; patient-level memberships and fitted objects remain private.


## Figure 3 and Figure 4 presentation

Figure 3 and Figure 4 use the existing registered aggregate results. No models
are refitted for this presentation update. Figure 4 shows six separate baseline
models in panel A, the existing unadjusted CRS and ICANS models in panel B, three
adjusted response models in panel C, and two adjusted time-dependent Cox models
in panel D. The Cox model IDs in the figure display export are display-only
identifiers derived from the unchanged primary scenario, endpoint, and adjusted
model. All three OR panels share the logarithmic axis; the HR panel keeps its
existing scale. Tocilizumab remains in Table S3.

At the manuscript's 6.5-inch display width, Figures 3 and 4 match Figure 2 by
font role. Native font sizes are multiplied by export width divided by Figure 2's
7.2-inch width. Reference roles are 11-point panel titles, 9.2-point labels,
10-point axis titles, and 3.35-mm numeric annotations. Figure 3 is 9.5 by 10
inches with panel heights 6/6/4; Figure 4 is 12 by 11 inches with panel heights
6/2.6/3.3/2.6. Long labels wrap for display only. Figure 2 remains unchanged.
The registered configuration is in Publication/clinical_presentation_selection.json.


## Proportional-hazards diagnostics

The clinical PH diagnostic export contains 18 models across the primary,
Definite/Probable, and largest-site-exclusion scenarios: unadjusted models in all
eligible courses, unadjusted models in the adjusted-model populations, and
adjusted models, for PFS and OS. The selected survival association export remains
10 models and the displayed Table S4 remains 10 time-dependent plus four
landmark rows. The PH sidecar contains counts and global/flare score statistics,
degrees of freedom, P values, method and status fields. It contains no
association estimates for unselected models and no individual identifiers.

The existing Cox fits supply model-based Schoenfeld-residual score diagnostics
with the Kaplan-Meier transformation of treatment time. The PH tests use
model-based information; HR confidence intervals and association P values use
patient-cluster robust variance. Single-predictor global and flare tests
coincide. Non-significant PH tests do not establish proportional hazards,
especially for flare effects with few events during exposed time.

The clinical cox_ph_diagnostics.csv is embedded in the HTML aggregate manifest
and is exported by Publication/extract_aggregate_inputs.py alongside the
selected survival_models.csv. Study aggregate CSVs are excluded from this
generic source archive. Clinical records, fitted objects, memberships and
caches remain private. Code/summary_functions.R exports the aggregate sidecar
from the clinical model summaries; Code/model_functions.R computes diagnostics
on existing Cox fits. No additional clinical fits are needed to assemble the
registered publication.

Publication/streamline_publication_manifest.py accepts the approved diagnostic
sidecar through --cox-ph-diagnostics, validates the full 18-row schema, and
registers the Table S4 notes from full-precision values. The paired HTML and
generic source archive reproduce these registered displays after aggregate
extraction, without clinical records or model fitting.
